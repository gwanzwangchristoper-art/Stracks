# Pilot plan (draft)
Gate 0 (blockers): licensed issuer partner + legal sign-off (CBN limits, escrow, NDPA), trademark clearance, external security review.
Pilot: 200-500 users, one market + one transport route, Tier 1 only, offline wallet cap N20,000 -> start at N5,000, per-payment N1,000, certificate life 3 days.
Monitoring: double-spend rate, rejected-settlement rate, escrow vs ledger reconciliation (daily), time-to-settle, sealed-record lock events, attestation failures.
Kill switch: server-side freeze + blocklist push; stop loads; refund-expired job.
Exit criteria: zero unreconciled escrow, double-spend loss < agreed cap, payment verify < 1 s on 2 GB device, 95% settle within 24 h of reconnect.
