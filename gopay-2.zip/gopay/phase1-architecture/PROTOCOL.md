# gOpay offline protocol v1 (byte-level)

Reference implementations: `phase2-backend/src/protocol.ts` (TypeScript) and `phase3-mobile-core/lib/src/protocol.dart` (Dart).
Cross-checked with `test-vectors/vectors.json`. All amounts are integer **kobo**. All times are Unix seconds (UTC).

## Encoding
Canonical CBOR subset (RFC 8949): unsigned ints, byte strings, text strings, arrays, maps with unsigned-int keys.
Heads use the shortest form, map keys are ascending and unique, no indefinite lengths, no trailing bytes.
Decoders **reject** anything else, so each object has exactly one byte form. Limits: depth 8, 64 items per array or map.
Over QR: Base45 (RFC 9285). Over NFC: raw bytes in APDUs. **Both carry identical token bytes.**

## Signatures
ECDSA P-256 over SHA-256, signature = raw `r || s` (64 bytes, IEEE P1363). Public keys = uncompressed point (65 bytes, `04 || X || Y`).
Platform keystores return DER; the mobile core converts DER to raw (see `der.dart`).
Domain-separation prefixes (ASCII): `GOPAY1-CERT`, `GOPAY1-TOKEN`, `GOPAY1-RECEIPT`.

## Certificate (issuer to wallet), CBOR map
| key | field | type | note |
|---|---|---|---|
| 1 | version | uint | 1 |
| 2 | walletId | tstr | UUID. One wallet per (user, device, load cycle) |
| 3 | devicePubKey | bstr(65) | hardware key, registered at onboarding |
| 4 | attestationRef | tstr | server reference to Play Integrity / App Attest result |
| 5 | currency | tstr | "NGN" |
| 6 | spendCeiling | uint | lifetime total loaded to this wallet (kobo) |
| 7 | perTxMax | uint | per-payment limit (tier, reduced during 72h cooling) |
| 8 | expiresAt | uint | issuedAt + 3 to 7 days |
| 9 | issuerKeyId | tstr | first 16 hex of SHA-256(issuer pubkey) |
| 10 | issuedAt | uint | |
| 11 | maxUnsynced | uint | max offline payments between syncs |

`certBlob = CBOR[ certBytes(bstr), issuerSig(bstr 64) ]`, `issuerSig = ECDSA(SHA256("GOPAY1-CERT" || certBytes))`.

## Payment request (receiver to payer, QR or NFC), CBOR map
`1 version, 2 receiverRef(tstr, walletId), 3 amount(uint, 0 = payer chooses), 4 currency, 5 nonce(bstr 8), 6 expiresAt`. Not signed; the token binds `receiverRef` and the receiver re-checks on receipt.

## Token (payer to receiver)
Payload map: `1 version, 2 txId(bstr16), 3 walletId, 4 receiverRef, 5 amount, 6 counter, 7 cumulativeSpent, 8 createdAt, 9 expiresAt, 10 nonce(bstr8), 11 currency`.
`token = CBOR[ certBlob(bstr), payloadBytes(bstr), payerSig(bstr 64) ]`
`payerSig = ECDSA_devicekey(SHA256("GOPAY1-TOKEN" || certBlob || payloadBytes))`.
Typical size: about 450 bytes, about 675 Base45 characters.
Rules: `counter` strictly increases by exactly 1 per payment; `cumulativeSpent = previous + amount`; `expiresAt - createdAt <= 900`.

## Receipt (receiver to payer)
`receipt = CBOR[ receiptBytes, receiverSig, receiverCertBlob ]`, receiptBytes map: `1 version, 2 txId, 3 receiverWalletId, 4 amount, 5 receivedAt`.
`receiverSig = ECDSA(SHA256("GOPAY1-RECEIPT" || receiptBytes))`. The payer verifies the receiver certificate against trusted issuer keys, then the signature, then txId, receiver and amount.

## Receiver verification order (all offline; stop at first failure)
1 structure, 2 issuer key trusted, 3 issuer signature, 4 certificate time window, 5 not on blocklist, 6 payer signature, 7 bound to me and currency,
8 token time window, 9 amount <= perTxMax, 10 cumulativeSpent <= spendCeiling, 11 txId and (walletId, counter) unseen, 12 within my max-accept and pending cap.
On pass: persist token in encrypted storage as **Pending**, then return the signed receipt.

## Server settlement (additional checks)
Idempotency by txId + token hash. Wallet/device binding. Settlement window (cert expiry + 7 days grace). `(walletId, counter)` uniqueness (DB unique index) means double-spend: reject, freeze, blocklist, open dispute.
Cumulative must be strictly monotone in counter. Escrow must cover the amount. Then post `escrow:payer -> available:receiver`.

## QR chunking (phase4)
Frame = Base45( `ver(1)=1 | msgId(3) | total(1) | index(1) | chunk` ), msgId = first 3 bytes of SHA-256(message). About 200 payload bytes per frame, 3 frames for a token. The receiver reassembles in any order, ignores duplicates, and checks the hash.

## NFC APDUs (phase4)
AID `F0 47 4F 50 41 59` ("\xF0GOPAY"). `SELECT`; `80 10 P1P2=offset` PUT_REQUEST chunks; `80 20 P1P2=offset` GET_TOKEN (SW `6985` = not ready, poll); `80 30` PUT_RECEIPT.
