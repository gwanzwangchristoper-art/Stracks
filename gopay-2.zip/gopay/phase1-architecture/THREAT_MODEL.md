# gOpay threat model

Principle: the **receiver bears double-spend loss**, so we shrink it (small caps, escrow, hardware keys, anti-rollback, fast blocklist) and tell users plainly.
Every "Test" cell points to a test that tries to break it. "Phase 7" items need real devices.

| # | Threat | Mitigation | Test |
|---|---|---|---|
| 1 | Replay (same token twice) | txId + (walletId, counter) seen-sets on receiver; server idempotency + unique index | `protocol.test: replay *`, `settlement.test: idempotent`, `copied token` |
| 2 | Token copy to a second receiver | token bound to `receiverRef`; wrong uploader rejected | `wrong receiver` (both layers) |
| 3 | Tampered amount | payer signature covers exact payload bytes | `tampered amount`, `tampered token bytes` |
| 4 | Wrong receiver | check 7 offline; server `wrong_receiver` | same as 2 |
| 5 | Cloned app data | hardware key non-exportable; sealed state tied to Keystore generation keys; server catches counter reuse | `sealed_ledger_test` (Dart), `double-spend` |
| 6 | Rolled-back device (backup restore) | generation-key scheme: restored blob has no key, wallet locks; backups disabled | `sealed_ledger_test: rollback`, Phase 7 device lab |
| 7 | Stolen phone | PIN (3 tries then server-side unlock), biometrics per payment, remote freeze, short cert life, per-tx cap | `pin_guard_test`, `frozen wallet` |
| 8 | Rooted / emulated / tampered device | Play Integrity + App Attest at register, load, refresh, settle | `rooted phones are refused` (mock); real verifiers are Phase 7 |
| 9 | Forged certificate | issuer signature + trusted key list; unknown key id rejected | `forged certificate` (both layers) |
| 10 | Clock manipulation | trusted clock: never goes backward, flags wall-clock rollback, blocks signing until sync; receiver compares to its own trusted time | `trusted_clock_test`, `expired certificate` |
| 11 | MITM on NFC/QR | token is signed and receiver-bound; nothing secret is on the wire; altering bytes breaks signature | `tampered` tests |
| 12 | Malicious receiver | receiver only gets one amount-bound token; cannot reuse it elsewhere | `wrong receiver` |
| 13 | Offline fraud ring (many clones, fast spend) | escrow cap, cooling caps, per-tx cap, `maxUnsynced`, blocklist push, freeze, held escrow | `clone spends beyond escrow` |
| 14 | Issuer / settlement abuse | idempotent postings, append-only ledger, balanced postings, admin key, audit log | `ledger.test` incl. property test |
| 15 | Payer lies about a lost transfer | counter consumed before token is released; token can only be re-shown (same bytes) | `token_builder_test` |

Residual risk (cannot be eliminated offline): a cloned or rooted device spending its remaining ceiling to several receivers before sync. Loss is bounded by the cap and borne by the receivers that settle late. This is why the risk notice is mandatory.
**Needs legal review:** CBN limits, who bears loss, dispute process, KYC data handling (NDPA), SMS/OTP rules, trademark of "gOpay".
