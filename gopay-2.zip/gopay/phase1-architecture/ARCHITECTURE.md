# gOpay architecture (Phase 1)
Status: brand name "gOpay" is provisional (trademark search in Nigeria, OAPI, ARIPO + legal review pending).
Legal review also needed: CBN tier limits, escrow / e-money licensing, NDPA consent, BVN/NIN handling.

Money flow: issuer debit -> escrow ledger (double-entry, append-only) -> issuer-signed certificate -> offline tokens
-> receiver uploads batch -> idempotent settlement (escrow -> receiver) -> expiry refund to linked account.
The receiver bears double-spend loss; caps and receiver-side checks limit exposure.

See PROTOCOL.md (byte layouts), THREAT_MODEL.md, test-vectors/vectors.json (shared by TS and Dart).
