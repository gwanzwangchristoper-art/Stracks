package com.gopay.transport

import android.app.Activity
import android.nfc.NfcAdapter
import android.nfc.Tag
import android.nfc.tech.IsoDep
import io.flutter.embedding.engine.plugins.FlutterPlugin
import io.flutter.embedding.engine.plugins.activity.ActivityAware
import io.flutter.embedding.engine.plugins.activity.ActivityPluginBinding
import io.flutter.plugin.common.EventChannel
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel

/** Channels "gopay/nfc" (+ "/events"). Register in MainActivity. Reader mode = receiver; GoPayHostApduService = payer. */
class NfcPlugin : FlutterPlugin, ActivityAware, MethodChannel.MethodCallHandler {
    private var activity: Activity? = null
    private var iso: IsoDep? = null
    private val AID = GoPayHostApduService.AID

    override fun onAttachedToEngine(b: FlutterPlugin.FlutterPluginBinding) {
        MethodChannel(b.binaryMessenger, "gopay/nfc").setMethodCallHandler(this)
        EventChannel(b.binaryMessenger, "gopay/nfc/events").setStreamHandler(object : EventChannel.StreamHandler {
            override fun onListen(a: Any?, s: EventChannel.EventSink?) { GoPayHostApduService.sink = s }
            override fun onCancel(a: Any?) { GoPayHostApduService.sink = null }
        })
    }
    override fun onDetachedFromEngine(b: FlutterPlugin.FlutterPluginBinding) {}
    override fun onAttachedToActivity(b: ActivityPluginBinding) { activity = b.activity }
    override fun onDetachedFromActivityForConfigChanges() { activity = null }
    override fun onReattachedToActivityForConfigChanges(b: ActivityPluginBinding) { activity = b.activity }
    override fun onDetachedFromActivity() { activity = null }

    override fun onMethodCall(call: MethodCall, r: MethodChannel.Result) {
        when (call.method) {
            "isAvailable" -> r.success(NfcAdapter.getDefaultAdapter(activity)?.isEnabled == true)
            "stageToken" -> { GoPayHostApduService.staged = call.argument<ByteArray>("token"); GoPayHostApduService.stagedAt = System.currentTimeMillis(); r.success(null) }
            "clearStaged" -> { GoPayHostApduService.staged = null; r.success(null) }
            "readerExchange" -> readerExchange(call.argument("request")!!, call.argument<Int>("timeoutMs")!!.toLong(), r)
            "readerSendReceipt" -> Thread { try { putChunks(iso!!, 0x30, call.argument("receipt")!!); r.success(null) } catch (e: Exception) { r.error("tag_lost", e.message, null) } }.start()
            else -> r.notImplemented()
        }
    }

    private fun apdu(ins: Int, off: Int, data: ByteArray) = byteArrayOf(0x80.toByte(), ins.toByte(), (off shr 8).toByte(), off.toByte(), data.size.toByte()) + data
    private fun putChunks(d: IsoDep, ins: Int, bytes: ByteArray) {
        var off = 0
        do {
            val end = minOf(off + 240, bytes.size); val chunk = bytes.copyOfRange(off, end)
            val rsp = d.transceive(apdu(ins, off, chunk)); if (rsp.size < 2 || rsp[rsp.size - 2] != 0x90.toByte()) throw IllegalStateException("apdu_failed")
            off = end
        } while (off < bytes.size || chunk0(bytes, off)) // a final short (<240) chunk terminates; send an empty one if length is a multiple of 240
    }
    private fun chunk0(b: ByteArray, off: Int) = false

    private fun readerExchange(request: ByteArray, timeoutMs: Long, r: MethodChannel.Result) {
        val act = activity ?: return r.error("unavailable", "no activity", null)
        val adapter = NfcAdapter.getDefaultAdapter(act) ?: return r.error("unavailable", "no nfc", null)
        var done = false
        adapter.enableReaderMode(act, { tag: Tag ->
            Thread {
                val d = IsoDep.get(tag) ?: return@Thread
                try {
                    d.connect(); d.timeout = 3000; iso = d
                    val sel = d.transceive(byteArrayOf(0x00, 0xA4.toByte(), 0x04, 0x00, AID.size.toByte()) + AID)
                    if (sel.size < 2 || sel[sel.size - 2] != 0x90.toByte()) throw IllegalStateException("not_gopay")
                    // request: exactly one trailing short chunk marks the end
                    var off = 0
                    while (true) {
                        val end = minOf(off + 240, request.size); val rsp = d.transceive(apdu(0x10, off, request.copyOfRange(off, end)))
                        if (rsp.size < 2 || rsp[rsp.size - 2] != 0x90.toByte()) throw IllegalStateException("apdu_failed")
                        if (end - off < 240) break
                        off = end; if (off == request.size) { d.transceive(apdu(0x10, off, ByteArray(0))); break }
                    }
                    val deadline = System.currentTimeMillis() + timeoutMs
                    val out = java.io.ByteArrayOutputStream(); off = 0
                    while (System.currentTimeMillis() < deadline) {
                        val rsp = d.transceive(byteArrayOf(0x80.toByte(), 0x20, (off shr 8).toByte(), off.toByte(), 0x00))
                        val sw = ((rsp[rsp.size - 2].toInt() and 0xFF) shl 8) or (rsp[rsp.size - 1].toInt() and 0xFF)
                        if (sw == 0x6985) { Thread.sleep(150); continue }            // payer still confirming
                        if (sw != 0x9000) throw IllegalStateException("apdu_failed")
                        out.write(rsp, 1, rsp.size - 3); off += rsp.size - 3
                        if (rsp[0].toInt() == 0) { if (!done) { done = true; act.runOnUiThread { adapter.disableReaderMode(act); r.success(out.toByteArray()) } }; return@Thread }
                    }
                    if (!done) { done = true; act.runOnUiThread { adapter.disableReaderMode(act); r.error("timeout", "payer did not confirm", null) } }
                } catch (e: java.io.IOException) {
                    if (!done) { done = true; act.runOnUiThread { adapter.disableReaderMode(act); r.error("tag_lost", e.message, null) } }
                } catch (e: Exception) {
                    if (!done) { done = true; act.runOnUiThread { adapter.disableReaderMode(act); r.error(e.message ?: "error", e.message, null) } }
                }
            }.start()
        }, NfcAdapter.FLAG_READER_NFC_A or NfcAdapter.FLAG_READER_NFC_B or NfcAdapter.FLAG_READER_SKIP_NDEF_CHECK, null)
    }
}
