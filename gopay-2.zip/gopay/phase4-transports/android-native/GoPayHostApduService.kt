package com.gopay.transport

import android.nfc.cardemulation.HostApduService
import android.os.Bundle
import io.flutter.plugin.common.EventChannel

/**
 * Payer side. Android routes APDUs for AID F0474F504159 here (see res/xml/apdu_service.xml).
 * State is process-wide so the Flutter side (NfcPlugin) can stage a token after the user confirms.
 */
class GoPayHostApduService : HostApduService() {
    companion object {
        val AID = byteArrayOf(0xF0.toByte(), 0x47, 0x4F, 0x50, 0x41, 0x59)
        @Volatile var sink: EventChannel.EventSink? = null
        @Volatile var staged: ByteArray? = null
        @Volatile var stagedAt = 0L
        private val reqBuf = java.io.ByteArrayOutputStream()
        private val rcptBuf = java.io.ByteArrayOutputStream()
        private val OK = byteArrayOf(0x90.toByte(), 0x00)
        private val NOT_READY = byteArrayOf(0x69, 0x85.toByte())
        private val BAD = byteArrayOf(0x6A, 0x80.toByte())
        private const val CHUNK = 240
    }

    override fun processCommandApdu(c: ByteArray, extras: Bundle?): ByteArray {
        if (c.size < 4) return BAD
        val ins = c[1].toInt() and 0xFF
        val off = ((c[2].toInt() and 0xFF) shl 8) or (c[3].toInt() and 0xFF)
        // SELECT
        if (c[0] == 0x00.toByte() && ins == 0xA4) {
            val lc = c[4].toInt() and 0xFF
            if (lc == AID.size && c.copyOfRange(5, 5 + lc).contentEquals(AID)) { reqBuf.reset(); rcptBuf.reset(); return OK }
            return byteArrayOf(0x6A, 0x82.toByte())
        }
        if (c[0] != 0x80.toByte()) return BAD
        val lc = if (c.size > 4) c[4].toInt() and 0xFF else 0
        return when (ins) {
            0x10 -> { // PUT_REQUEST: chunks must arrive in order
                if (off == 0) reqBuf.reset()
                if (off != reqBuf.size() || reqBuf.size() + lc > 1024) return BAD
                reqBuf.write(c, 5, lc)
                if (lc < CHUNK) { val data = reqBuf.toByteArray(); android.os.Handler(mainLooper).post { sink?.success(mapOf("type" to "request", "data" to data)) } }
                OK
            }
            0x20 -> { // GET_TOKEN
                val t = staged
                if (t == null || System.currentTimeMillis() - stagedAt > 60_000) return NOT_READY
                if (off >= t.size) return BAD
                val end = minOf(off + CHUNK, t.size)
                byteArrayOf(if (end < t.size) 1 else 0) + t.copyOfRange(off, end) + OK
            }
            0x30 -> { // PUT_RECEIPT
                if (off == 0) rcptBuf.reset()
                if (off != rcptBuf.size() || rcptBuf.size() + lc > 2048) return BAD
                rcptBuf.write(c, 5, lc)
                if (lc < CHUNK) { val data = rcptBuf.toByteArray(); staged = null; android.os.Handler(mainLooper).post { sink?.success(mapOf("type" to "receipt", "data" to data)) } }
                OK
            }
            else -> byteArrayOf(0x6D, 0x00)
        }
    }
    override fun onDeactivated(reason: Int) {}
}
