// Receiver -> payer request (QR or NFC). Unsigned: the token binds receiverRef and the receiver re-checks everything.
import 'dart:math';
import 'dart:typed_data';
import 'package:gopay_core/gopay_core.dart';

class PaymentRequest {
  final String receiverRef, currency;
  final int amount;      // kobo; 0 = payer chooses
  final int expiresAt;
  final Uint8List nonce;
  PaymentRequest({required this.receiverRef, required this.amount, required this.expiresAt, Uint8List? nonce, this.currency = 'NGN'})
      : nonce = nonce ?? Uint8List.fromList(List.generate(8, (_) => Random.secure().nextInt(256)));

  Uint8List encode() => cborEncode(<int, Object?>{1: 1, 2: receiverRef, 3: amount, 4: currency, 5: nonce, 6: expiresAt});

  static PaymentRequest decode(Uint8List b) {
    final m = cborDecode(b);
    if (m is! Map<int, Object?> || m[1] != 1 || m[2] is! String || m[3] is! int || m[4] is! String || m[5] is! Uint8List || m[6] is! int) {
      throw const FormatException('bad payment request');
    }
    return PaymentRequest(receiverRef: m[2] as String, amount: m[3] as int, currency: m[4] as String, nonce: m[5] as Uint8List, expiresAt: m[6] as int);
  }
}
