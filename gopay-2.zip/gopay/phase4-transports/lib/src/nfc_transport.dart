// NFC transport. Android payer = Host Card Emulation service; receiver (Android or iOS) = reader.
// Both carry the SAME token bytes as QR. iPhones cannot emulate cards, so an iPhone payer uses QR; an iPhone can still RECEIVE by reading.
//
// APDUs (AID F0 47 4F 50 41 59):
//   SELECT                       00 A4 04 00 06 <AID>                       -> 9000
//   PUT_REQUEST  (reader->payer) 80 10 P1P2=offset Lc=<chunk>               -> 9000   (request bytes, <=240 per APDU)
//   GET_TOKEN    (reader<-payer) 80 20 P1P2=offset Le                       -> [more(1) | chunk] 9000 | 6985 not ready
//   PUT_RECEIPT  (reader->payer) 80 30 P1P2=offset Lc=<chunk>               -> 9000
// "Not ready" lets the payer confirm amount + PIN/biometric after the first tap; the receiver keeps polling (or the user taps again).
import 'dart:async';
import 'dart:typed_data';
import 'package:flutter/services.dart';

class NfcException implements Exception {
  final String code;
  NfcException(this.code);
  @override
  String toString() => 'nfc: $code';
}

class NfcTransport {
  static const _ch = MethodChannel('gopay/nfc');
  static const _events = EventChannel('gopay/nfc/events');

  Future<bool> isAvailable() async => (await _ch.invokeMethod<bool>('isAvailable')) ?? false;

  // ---------- Payer (Android HCE) ----------
  /// Arms the HCE service. Emits the receiver's request bytes when a reader taps (payer then shows the confirm sheet).
  Stream<Uint8List> incomingRequests() => _events.receiveBroadcastStream().where((e) => e is Map && e['type'] == 'request').map((e) => (e as Map)['data'] as Uint8List);
  /// Hands the signed token to the HCE service. The reader fetches it with GET_TOKEN (retained 60s for re-tap).
  Future<void> stageToken(Uint8List token) => _ch.invokeMethod('stageToken', {'token': token});
  Future<void> clearStaged() => _ch.invokeMethod('clearStaged');
  /// Receipt pushed by the reader after it stored the token.
  Stream<Uint8List> incomingReceipts() => _events.receiveBroadcastStream().where((e) => e is Map && e['type'] == 'receipt').map((e) => (e as Map)['data'] as Uint8List);

  // ---------- Receiver (Android reader mode / iOS CoreNFC) ----------
  /// One full exchange: SELECT, send request, poll for the token until [timeout], return token bytes.
  /// [onToken] must verify + store the token and return the signed receipt, which is then sent back to the payer.
  Future<Uint8List> receive({required Uint8List request, required Future<Uint8List> Function(Uint8List token) onToken, Duration timeout = const Duration(seconds: 45)}) async {
    try {
      final token = await _ch.invokeMethod<Uint8List>('readerExchange', {'request': request, 'timeoutMs': timeout.inMilliseconds});
      if (token == null) throw NfcException('no_token');
      final receipt = await onToken(token);
      try { await _ch.invokeMethod('readerSendReceipt', {'receipt': receipt}); } on PlatformException { /* payer can still be settled later; receipt is a convenience */ }
      return token;
    } on PlatformException catch (e) {
      throw NfcException(e.code); // tag_lost, timeout, unavailable, cancelled
    }
  }
}
