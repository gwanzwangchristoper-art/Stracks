// Chunked animated QR. Any message (request, token, receipt) becomes N frames; the scanner can read them in any order, with repeats and gaps.
// Frame text = "GP1:" + Base45( ver(1) | msgId(3) | total(1) | index(1) | chunk ). msgId = first 3 bytes of SHA-256(message).
// Prefix "GP1:" lets the scanner ignore foreign QR codes. Base45 keeps frames in QR alphanumeric mode (denser, easier to scan in sunlight).
import 'dart:typed_data';
import 'package:gopay_core/gopay_core.dart';

const qrPrefix = 'GP1:';
const defaultChunkBytes = 180; // ~ 3 frames for a 450-byte token; small frames scan fast on cheap cameras
const maxFrames = 12;

List<String> qrEncode(Uint8List message, {int chunkBytes = defaultChunkBytes}) {
  if (message.isEmpty) throw ArgumentError('empty message');
  final total = (message.length + chunkBytes - 1) ~/ chunkBytes;
  if (total > maxFrames) throw ArgumentError('message too large for QR');
  final id = sha256(message).sublist(0, 3);
  return [
    for (var i = 0; i < total; i++)
      qrPrefix + base45Encode(Uint8List.fromList([1, ...id, total, i, ...message.sublist(i * chunkBytes, (i + 1) * chunkBytes > message.length ? message.length : (i + 1) * chunkBytes)]))
  ];
}

enum FrameResult { accepted, duplicate, foreign, wrongMessage, malformed, complete }

class QrAssembler {
  String? _id;
  int _total = 0;
  final Map<int, Uint8List> _parts = {};
  Uint8List? message;

  int get total => _total;
  int get received => _parts.length;
  double get progress => _total == 0 ? 0 : _parts.length / _total;
  List<int> get missing => [for (var i = 0; i < _total; i++) if (!_parts.containsKey(i)) i];

  void reset() { _id = null; _total = 0; _parts.clear(); message = null; }

  /// Feed every scanned QR string. Safe against garbage, repeats, and a different message appearing mid-scan.
  FrameResult add(String frame) {
    if (!frame.startsWith(qrPrefix)) return FrameResult.foreign;
    Uint8List raw;
    try { raw = base45Decode(frame.substring(qrPrefix.length)); } catch (_) { return FrameResult.malformed; }
    if (raw.length < 7 || raw[0] != 1) return FrameResult.malformed;
    final id = hexOf(raw.sublist(1, 4)), total = raw[4], idx = raw[5];
    if (total < 1 || total > maxFrames || idx >= total) return FrameResult.malformed;
    if (message != null) return FrameResult.duplicate;
    if (_id == null) { _id = id; _total = total; }
    if (id != _id || total != _total) return FrameResult.wrongMessage;   // caller may reset() and restart if the user moved to another code
    if (_parts.containsKey(idx)) return FrameResult.duplicate;
    _parts[idx] = raw.sublist(6);
    if (_parts.length < _total) return FrameResult.accepted;
    final out = Uint8List.fromList([for (var i = 0; i < _total; i++) ..._parts[i]!]);
    if (hexOf(sha256(out).sublist(0, 3)) != _id) { reset(); return FrameResult.malformed; }   // corrupted: start over
    message = out;
    return FrameResult.complete;
  }
}
