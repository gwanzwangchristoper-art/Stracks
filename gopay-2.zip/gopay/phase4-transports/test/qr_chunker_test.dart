import 'dart:math';
import 'dart:typed_data';
import 'package:flutter_test/flutter_test.dart';
import 'package:gopay_transport/gopay_transport.dart';

Uint8List msg(int n, [int seed = 1]) { final r = Random(seed); return Uint8List.fromList(List.generate(n, (_) => r.nextInt(256))); }

void main() {
  test('450-byte token -> 3 frames -> reassembles identically', () {
    final m = msg(450);
    final frames = qrEncode(m);
    expect(frames.length, 3);
    final a = QrAssembler();
    for (final f in frames) { a.add(f); }
    expect(a.message, m);
  });

  test('any order, duplicates, and foreign QR codes in between', () {
    final m = msg(450, 7);
    final f = qrEncode(m);
    final a = QrAssembler();
    expect(a.add('https://example.com'), FrameResult.foreign);
    expect(a.add(f[2]), FrameResult.accepted);
    expect(a.add(f[2]), FrameResult.duplicate);
    expect(a.add(f[0]), FrameResult.accepted);
    expect(a.missing, [1]);
    expect(a.add(f[1]), FrameResult.complete);
    expect(a.message, m);
  });

  test('a frame from a different message is flagged, not mixed in', () {
    final a = QrAssembler();
    final f1 = qrEncode(msg(450, 1)), f2 = qrEncode(msg(450, 2));
    a.add(f1[0]);
    expect(a.add(f2[1]), FrameResult.wrongMessage);
    expect(a.received, 1);
  });

  test('corrupted frame content is caught by the message hash', () {
    final f = qrEncode(msg(450, 3));
    final bad = List<String>.from(f)..[1] = f[1].substring(0, f[1].length - 2) + (f[1].endsWith('AA') ? 'BB' : 'AA');
    final a = QrAssembler();
    var last = FrameResult.accepted;
    for (final x in bad) { last = a.add(x); }
    expect(last, anyOf(FrameResult.malformed, FrameResult.accepted));
    expect(a.message, isNull);
  });

  test('garbage and truncated frames are malformed', () {
    final a = QrAssembler();
    expect(a.add('GP1:!!!'), FrameResult.malformed);
    expect(a.add('GP1:AB'), FrameResult.malformed);
  });

  test('single-frame messages (payment request) and size limit', () {
    final m = msg(60);
    expect(qrEncode(m).length, 1);
    final a = QrAssembler();
    expect(a.add(qrEncode(m).single), FrameResult.complete);
    expect(() => qrEncode(msg(5000)), throwsArgumentError);
  });

  test('payment request round trip', () {
    final r = PaymentRequest(receiverRef: '22222222-2222-4222-8222-222222222222', amount: 150000, expiresAt: 1800000600);
    final d = PaymentRequest.decode(r.encode());
    expect(d.amount, 150000); expect(d.receiverRef, r.receiverRef);
    expect(() => PaymentRequest.decode(Uint8List.fromList([1, 2, 3])), throwsA(anything));
  });
}
