import CoreNFC
import Flutter

/// iOS receiver: reads from an Android HCE payer. Needs entitlement NFC Tag Reading + Info.plist
/// `com.apple.developer.nfc.readersession.iso7816.select-identifiers` = ["F0474F504159"] and NFCReaderUsageDescription.
/// iPhones cannot act as the payer over NFC (no HCE for third parties in NG): they pay by QR.
final class NfcReader: NSObject, NFCTagReaderSessionDelegate {
  private var session: NFCTagReaderSession?
  private var request = Data()
  private var timeout: TimeInterval = 45
  private var completion: FlutterResult?
  private var tag: NFCISO7816Tag?
  private let aid = Data([0xF0, 0x47, 0x4F, 0x50, 0x41, 0x59])

  func exchange(request: Data, timeoutMs: Int, result: @escaping FlutterResult) {
    guard NFCTagReaderSession.readingAvailable else { return result(FlutterError(code: "unavailable", message: nil, details: nil)) }
    self.request = request; self.timeout = Double(timeoutMs) / 1000; self.completion = result
    session = NFCTagReaderSession(pollingOption: .iso14443, delegate: self)
    session?.alertMessage = "Hold your phone near the payer's phone"
    session?.begin()
  }
  func tagReaderSessionDidBecomeActive(_ s: NFCTagReaderSession) {}
  func tagReaderSession(_ s: NFCTagReaderSession, didInvalidateWithError e: Error) { finish(error: "cancelled") }
  func tagReaderSession(_ s: NFCTagReaderSession, didDetect tags: [NFCTag]) {
    guard case .iso7816(let t) = tags.first else { return s.invalidate(errorMessage: "Not a gOpay phone") }
    s.connect(to: tags.first!) { err in
      if err != nil { return s.invalidate(errorMessage: "Try again") }
      self.tag = t
      Task { await self.run(t, s) }
    }
  }
  private func apdu(_ ins: UInt8, _ off: Int, _ d: Data, le: Int = -1) -> NFCISO7816APDU {
    NFCISO7816APDU(instructionClass: 0x80, instructionCode: ins, p1Parameter: UInt8(off >> 8), p2Parameter: UInt8(off & 255), data: d, expectedResponseLength: le)
  }
  private func run(_ t: NFCISO7816Tag, _ s: NFCTagReaderSession) async {
    do {
      let sel = NFCISO7816APDU(instructionClass: 0, instructionCode: 0xA4, p1Parameter: 4, p2Parameter: 0, data: aid, expectedResponseLength: -1)
      let (_, s1, s2) = try await t.sendCommand(apdu: sel); guard s1 == 0x90 else { throw NSError(domain: "nfc", code: 1) }; _ = s2
      var off = 0
      while true {
        let end = min(off + 240, request.count); let chunk = request.subdata(in: off..<end)
        let (_, a, _) = try await t.sendCommand(apdu: apdu(0x10, off, chunk)); guard a == 0x90 else { throw NSError(domain: "nfc", code: 2) }
        if chunk.count < 240 { break }; off = end; if off == request.count { _ = try await t.sendCommand(apdu: apdu(0x10, off, Data())); break }
      }
      let deadline = Date().addingTimeInterval(timeout); var out = Data(); off = 0
      while Date() < deadline {
        let (d, a, b) = try await t.sendCommand(apdu: NFCISO7816APDU(instructionClass: 0x80, instructionCode: 0x20, p1Parameter: UInt8(off >> 8), p2Parameter: UInt8(off & 255), data: Data(), expectedResponseLength: 256))
        if a == 0x69 && b == 0x85 { try await Task.sleep(nanoseconds: 150_000_000); continue }
        guard a == 0x90 else { throw NSError(domain: "nfc", code: 3) }
        out.append(d.dropFirst()); off += d.count - 1
        if d.first == 0 { s.alertMessage = "Done"; s.invalidate(); completion?(FlutterStandardTypedData(bytes: out)); completion = nil; return }
      }
      throw NSError(domain: "nfc", code: 4)
    } catch { s.invalidate(errorMessage: "Try again"); finish(error: "tag_lost") }
  }
  private func finish(error: String) { completion?(FlutterError(code: error, message: nil, details: nil)); completion = nil }
}
