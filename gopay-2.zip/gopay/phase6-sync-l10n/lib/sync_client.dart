import 'dart:math';

/// Uploads items in batches; safe to retry because the server settles idempotently by txId.
/// `send` returns one result map per item (status settled|rejected, reason). Throws on network failure.
class SyncClient<T> {
  final Future<List<Map<String, Object?>>> Function(List<T> batch) send;
  final int batchSize, maxAttempts;
  SyncClient(this.send, {this.batchSize = 20, this.maxAttempts = 5});

  static Duration backoff(int attempt, Random r) =>
      Duration(milliseconds: min(30000, 500 * (1 << attempt)) + r.nextInt(300)); // exponential + jitter

  Future<List<Map<String, Object?>>> run(List<T> items, {Random? rng, Future<void> Function(Duration)? sleep}) async {
    final out = <Map<String, Object?>>[]; final r = rng ?? Random(); final wait = sleep ?? Future.delayed;
    for (var i = 0; i < items.length; i += batchSize) {
      final batch = items.sublist(i, min(i + batchSize, items.length));
      for (var a = 0;; a++) {
        try { out.addAll(await send(batch)); break; }
        catch (_) { if (a + 1 >= maxAttempts) rethrow; await wait(backoff(a, r)); }
      }
    }
    return out;
  }
}
