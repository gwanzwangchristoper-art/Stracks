// Short, plain strings. en is the source of truth; others fall back to en for missing keys.
// NOTE: ha/yo/ig/pcm are first drafts. They MUST be reviewed by native speakers before pilot. fr: add later.
const supportedLocales = ['en', 'pcm', 'ha', 'yo', 'ig'];
const _s = <String, Map<String, String>>{
  'en':  {'paid': 'Paid', 'waiting': 'Waiting for network', 'pending': 'Pending', 'available': 'Available', 'load': 'Load', 'pay': 'Pay', 'receive': 'Receive', 'history': 'History',
          'now_available': '{amount} is now available', 'rejected': 'Payment rejected. {reason}', 'risk': 'Offline payments can fail. If the sender spent the same money twice, you may lose it. Keep amounts small.'},
  'pcm': {'paid': 'E don pay', 'waiting': 'Dey wait for network', 'pending': 'Dey wait', 'available': 'Money wey dey', 'load': 'Load', 'pay': 'Pay', 'receive': 'Collect', 'history': 'History'},
  'ha':  {'paid': 'An biya', 'waiting': 'Ana jiran hanyar sadarwa', 'pending': 'Ana jira', 'available': 'Akwai', 'load': 'Saka kuɗi', 'pay': 'Biya', 'receive': 'Karɓa', 'history': 'Tarihi'},
  'yo':  {'paid': 'A ti san', 'waiting': 'A n dúró de nẹtiwọki', 'pending': 'Ń dúró', 'available': 'Tó wà', 'load': 'Fi owó sí', 'pay': 'Sanwó', 'receive': 'Gba', 'history': 'Ìtàn'},
  'ig':  {'paid': 'Akwụọla', 'waiting': 'Na-echere netwọk', 'pending': 'Na-eche', 'available': 'Dị', 'load': 'Tinye ego', 'pay': 'Kwụọ', 'receive': 'Nata', 'history': 'Akụkọ'},
};
String tr(String locale, String key, [Map<String, String> args = const {}]) {
  var s = _s[locale]?[key] ?? _s['en']![key] ?? key;
  args.forEach((k, v) => s = s.replaceAll('{$k}', v));
  return s;
}
