import 'package:flutter/material.dart';
import 'app_state.dart';
import 'brand/brand.dart';
import 'screens/flows.dart';
import 'screens/home.dart';
import 'screens/onboarding.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await app.init();
  runApp(const GoPayApp());
}

class GoPayApp extends StatelessWidget {
  const GoPayApp({super.key});
  @override Widget build(BuildContext c) => MaterialApp(title: Brand.appName, theme: Brand.theme(), debugShowCheckedModeBanner: false,
    home: ListenableBuilder(listenable: app, builder: (ctx, _) => app.onboarded ? const Shell() : const Onboarding()));
}

class Shell extends StatefulWidget { const Shell({super.key}); @override State<Shell> createState() => _Sh(); }
class _Sh extends State<Shell> {
  int tab = 0;
  @override Widget build(BuildContext c) => Scaffold(
    body: ListenableBuilder(listenable: app, builder: (ctx, _) => [
      HomeScreen(onLoad: () => startLoad(c), onPay: () => startPay(c),
        onReceive: () => Navigator.push(c, MaterialPageRoute(builder: (_) => const ReceiveScreen())),
        onHistory: () => setState(() => tab = 1)),
      HistoryScreen(), MeScreen(),
    ][tab]),
    bottomNavigationBar: NavigationBar(selectedIndex: tab, onDestinationSelected: (i) => setState(() => tab = i), destinations: const [
      NavigationDestination(icon: Icon(Icons.home_outlined), label: 'Home'),
      NavigationDestination(icon: Icon(Icons.history), label: 'History'),
      NavigationDestination(icon: Icon(Icons.person_outline), label: 'Me')]));
}
