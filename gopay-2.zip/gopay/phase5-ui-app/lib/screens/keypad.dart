import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

/// Numeric keypad used for amount and PIN. Large targets, haptic on each tap.
class Keypad extends StatelessWidget {
  final void Function(String key) onKey; const Keypad({super.key, required this.onKey});
  @override Widget build(BuildContext c) => GridView.count(crossAxisCount: 3, shrinkWrap: true, childAspectRatio: 1.7, physics: const NeverScrollableScrollPhysics(),
    children: [for (final k in ['1','2','3','4','5','6','7','8','9','','0','⌫']) k.isEmpty ? const SizedBox() :
      Semantics(button: true, label: k == '⌫' ? 'Delete' : k, child: InkWell(onTap: () { HapticFeedback.selectionClick(); onKey(k); },
        child: Center(child: Text(k, style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w600)))))]);
}

/// Amount entry in whole naira (kobo = value*100). Receive flow: type amount -> QR in 3 taps or fewer.
class AmountScreen extends StatefulWidget {
  final String title, cta; final int maxKobo; final void Function(int kobo) onDone;
  const AmountScreen({super.key, required this.title, required this.cta, required this.maxKobo, required this.onDone});
  @override State<AmountScreen> createState() => _A();
}
class _A extends State<AmountScreen> {
  String v = '';
  int get kobo => (int.tryParse(v) ?? 0) * 100;
  @override Widget build(BuildContext c) => Scaffold(appBar: AppBar(title: Text(widget.title)), body: SafeArea(child: Padding(padding: const EdgeInsets.all(16), child: Column(children: [
    const Spacer(), FittedBox(child: Text('₦${v.isEmpty ? '0' : v}', style: const TextStyle(fontSize: 56, fontWeight: FontWeight.w700))),
    if (kobo > widget.maxKobo) Text('Too high. Max is ₦${widget.maxKobo ~/ 100}.', style: const TextStyle(color: Color(0xFFD92D20))),
    const Spacer(),
    Keypad(onKey: (k) => setState(() { if (k == '⌫') { if (v.isNotEmpty) v = v.substring(0, v.length - 1); } else if (v.length < 7) v += k; })),
    const SizedBox(height: 12),
    FilledButton(onPressed: kobo > 0 && kobo <= widget.maxKobo ? () => widget.onDone(kobo) : null, child: Text(widget.cta)),
  ]))));
}
