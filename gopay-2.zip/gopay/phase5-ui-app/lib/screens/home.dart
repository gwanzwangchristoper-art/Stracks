import 'package:flutter/material.dart';
import 'package:gopay_sync/gopay_sync.dart';
import '../app_state.dart';
import '../brand/brand.dart';

String statusLabel(String s) => switch (s) {
  'pending' => 'Pending', 'waiting' => 'Waiting to settle', 'settled' => 'Settled', _ => 'Failed' };
IconData statusIcon(String s) => switch (s) {
  'pending' || 'waiting' => Icons.schedule, 'settled' => Icons.check_circle_outline, _ => Icons.error_outline };

class TxTile extends StatelessWidget {
  final Tx t; final VoidCallback? onTap; const TxTile(this.t, {super.key, this.onTap});
  @override Widget build(BuildContext c) {
    final title = switch (t.kind) { 'load' => 'Loaded', 'sent' => 'Paid ${t.peer}', _ => 'From ${t.peer}' };
    final sign = t.kind == 'sent' ? '-' : '+';
    return ListTile(onTap: onTap, contentPadding: EdgeInsets.zero,
      leading: CircleAvatar(backgroundColor: Colors.white, child: Icon(t.kind == 'sent' ? Icons.north_east : t.kind == 'load' ? Icons.add : Icons.south_west, color: Brand.green)),
      title: Text(title), subtitle: Row(children: [Icon(statusIcon(t.status), size: 14), const SizedBox(width: 4), Text(statusLabel(t.status))]),
      trailing: Text('$sign${naira(t.amount)}', style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 16)));
  }
}

class HomeScreen extends StatefulWidget {
  final VoidCallback onLoad, onPay, onReceive, onHistory;
  const HomeScreen({super.key, required this.onLoad, required this.onPay, required this.onReceive, required this.onHistory});
  @override State<HomeScreen> createState() => _S();
}
class _S extends State<HomeScreen> {
  bool hide = false;
  String m(int v) => hide ? '••••' : naira(v);
  void toggleOnline() {
    final msg = app.setOnline(!app.online);
    if (msg != null) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
  }
  @override Widget build(BuildContext c) {
    final l = app.locale;
    return SafeArea(child: ListView(padding: const EdgeInsets.all(16), children: [
      Row(children: [const LogoMark(size: 36), const SizedBox(width: 10), const Text('Hi', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w600)), const Spacer(),
        ActionChip(onPressed: toggleOnline, avatar: Icon(app.online ? Icons.wifi : Icons.wifi_off, size: 18), label: Text(app.online ? 'Online' : tr(l, 'waiting')))]),
      const SizedBox(height: 16),
      ClipRRect(borderRadius: BorderRadius.circular(Brand.radius), child: RingOverlay(child: Container(color: Brand.green, padding: const EdgeInsets.all(20),
        width: double.infinity, child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [Text(tr(l, 'available'), style: const TextStyle(color: Colors.white)), const Spacer(),
            IconButton(tooltip: hide ? 'Show balance' : 'Hide balance', icon: Icon(hide ? Icons.visibility_off : Icons.visibility, color: Colors.white), onPressed: () => setState(() => hide = !hide))]),
          FittedBox(child: Text(m(app.available), style: const TextStyle(fontSize: 44, fontWeight: FontWeight.w700, color: Colors.white))),
          const SizedBox(height: 12),
          Text('Offline Wallet  ${m(app.offlineWallet)}', style: const TextStyle(color: Brand.yellow, fontSize: 18, fontWeight: FontWeight.w600)),
          const SizedBox(height: 8),
          Chip(avatar: const Icon(Icons.schedule, size: 16), label: Text('${tr(l, 'pending')} ${m(app.pending)}')),
        ])))),
      const SizedBox(height: 20),
      Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
        _Q(Icons.add_circle_outline, tr(l, 'load'), widget.onLoad), _Q(Icons.north_east, tr(l, 'pay'), widget.onPay),
        _Q(Icons.south_west, tr(l, 'receive'), widget.onReceive), _Q(Icons.history, tr(l, 'history'), widget.onHistory)]),
      const SizedBox(height: 24), const Text('Recent', style: TextStyle(fontWeight: FontWeight.w600)),
      const SizedBox(height: 8),
      if (app.txs.isEmpty) const Text('No activity yet. Tap Load to add money.'),
      for (final t in app.txs.take(5)) TxTile(t),
    ]));
  }
}
class _Q extends StatelessWidget {
  final IconData i; final String t; final VoidCallback f; const _Q(this.i, this.t, this.f);
  @override Widget build(BuildContext c) => Semantics(button: true, label: t, child: InkWell(onTap: f, borderRadius: BorderRadius.circular(40),
    child: SizedBox(width: 76, child: Column(children: [CircleAvatar(radius: 28, backgroundColor: Colors.white, child: Icon(i, color: Brand.green)), const SizedBox(height: 6), Text(t, textAlign: TextAlign.center)]))));
}
