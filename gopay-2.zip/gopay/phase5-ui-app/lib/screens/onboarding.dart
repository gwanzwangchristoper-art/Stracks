import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../app_state.dart';
import '../brand/brand.dart';
import 'keypad.dart';

const _langs = {'en': 'English', 'pcm': 'Pidgin', 'ha': 'Hausa', 'yo': 'Yoruba', 'ig': 'Igbo'};
const riskText = 'Offline payments can fail. If a sender spends the same money twice, you may lose what you received. '
    'Keep amounts small. Money you receive stays Pending until you go online.';

class Onboarding extends StatefulWidget { const Onboarding({super.key}); @override State<Onboarding> createState() => _O(); }

class _O extends State<Onboarding> {
  int step = 0; // 0 welcome, 1 phone, 2 otp, 3 pin, 4 confirm pin, 5 kyc, 6 risk
  String lang = 'en', pinIn = '', firstPin = '', err = '';
  bool agreed = false;
  final phone = TextEditingController(), otp = TextEditingController(), bvn = TextEditingController();

  void next() => setState(() { step++; err = ''; });

  Widget field(TextEditingController c, String label, int max) => TextField(
    controller: c, keyboardType: TextInputType.number, maxLength: max, onChanged: (_) => setState(() {}),
    inputFormatters: [FilteringTextInputFormatter.digitsOnly],
    style: const TextStyle(fontSize: 24), decoration: InputDecoration(labelText: label, filled: true, fillColor: Colors.white,
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(Brand.radius))));

  Widget pinDots() => Row(mainAxisAlignment: MainAxisAlignment.center, children: [
    for (var i = 0; i < 4; i++) Padding(padding: const EdgeInsets.all(8), child: Icon(i < pinIn.length ? Icons.circle : Icons.circle_outlined, size: 22))]);

  void pinKey(String k) {
    setState(() {
      if (k == '⌫') { if (pinIn.isNotEmpty) pinIn = pinIn.substring(0, pinIn.length - 1); }
      else if (pinIn.length < 4) pinIn += k;
    });
    if (pinIn.length == 4) {
      if (step == 3) { firstPin = pinIn; pinIn = ''; next(); }
      else if (pinIn == firstPin) { app.setPin(pinIn); pinIn = ''; next(); }
      else setState(() { err = 'PINs do not match. Try again.'; pinIn = ''; step = 3; });
    }
  }

  @override Widget build(BuildContext c) {
    Widget body; String? cta; bool ok = true; VoidCallback? action;
    switch (step) {
      case 0:
        body = Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          const LogoMark(size: 96), const SizedBox(height: 16),
          const Text('gOpay', style: TextStyle(fontSize: 36, fontWeight: FontWeight.w700, color: Brand.green)),
          const SizedBox(height: 8), const Text('Pay and get paid. Even offline.', style: TextStyle(fontSize: 18)),
          const SizedBox(height: 24), const Text('Choose your language'),
          const SizedBox(height: 8),
          Wrap(spacing: 8, children: [for (final e in _langs.entries) ChoiceChip(label: Text(e.value), selected: lang == e.key,
            onSelected: (_) => setState(() => lang = e.key))]),
        ]);
        cta = 'Get started'; action = () { app.setLocale(lang); next(); };
      case 1:
        body = Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('Your phone number', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w700)), const SizedBox(height: 16),
          field(phone, 'Phone number', 11)]);
        cta = 'Send code'; ok = phone.text.length >= 10; action = () { app.setPhone(phone.text); next(); };
      case 2:
        body = Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('Enter the code', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w700)), const SizedBox(height: 8),
          const Text('Demo build: your code is 123456.'), const SizedBox(height: 16), field(otp, '6-digit code', 6),
          if (err.isNotEmpty) Text(err, style: const TextStyle(color: Brand.error))]);
        cta = 'Verify'; ok = otp.text.length == 6;
        action = () { if (otp.text == '123456') { next(); } else { setState(() => err = 'Wrong code. Try again.'); } };
      case 3:
      case 4:
        body = Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          Text(step == 3 ? 'Create a 4-digit PIN' : 'Confirm your PIN', style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w700)),
          const SizedBox(height: 16), pinDots(),
          if (err.isNotEmpty) Text(err, style: const TextStyle(color: Brand.error)),
          const SizedBox(height: 16), Keypad(onKey: pinKey)]);
      case 5:
        body = Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('Verify your identity', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w700)), const SizedBox(height: 8),
          const Text('Enter your BVN or NIN. Demo build: it is not checked. Tier 1 limits apply.'), const SizedBox(height: 16),
          field(bvn, 'BVN or NIN (11 digits)', 11)]);
        cta = 'Continue'; ok = bvn.text.length == 11; action = next;
      default:
        body = Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Icon(Icons.warning_amber_rounded, size: 48, color: Brand.amber), const SizedBox(height: 8),
          const Text('Before you start', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w700)), const SizedBox(height: 12),
          const Text(riskText, style: TextStyle(fontSize: 17)), const SizedBox(height: 12),
          CheckboxListTile(contentPadding: EdgeInsets.zero, value: agreed, onChanged: (v) => setState(() => agreed = v ?? false),
            title: const Text('I understand the risk'))]);
        cta = 'Start'; ok = agreed; action = app.finishOnboarding;
    }
    return Scaffold(body: SafeArea(child: Padding(padding: const EdgeInsets.all(20), child: Column(children: [
      if (step > 0 && step < 7) LinearProgressIndicator(value: step / 6, color: Brand.green, backgroundColor: Brand.softGrey),
      const SizedBox(height: 16), Expanded(child: SingleChildScrollView(child: body)),
      if (cta != null) FilledButton(onPressed: ok ? action : null, child: Text(cta)),
    ]))));
  }
}
