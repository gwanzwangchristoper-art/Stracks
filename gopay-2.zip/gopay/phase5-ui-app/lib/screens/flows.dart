import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:mobile_scanner/mobile_scanner.dart';
import 'package:qr_flutter/qr_flutter.dart';
import '../app_state.dart';
import '../brand/brand.dart';
import 'home.dart';
import 'keypad.dart';
import 'onboarding.dart';

void toast(BuildContext c, String m) => ScaffoldMessenger.of(c).showSnackBar(SnackBar(content: Text(m)));

/// Bottom-sheet PIN check. Locks out after 3 wrong tries (demo: local only).
Future<bool> askPin(BuildContext context, String title) async {
  final ok = await showModalBottomSheet<bool>(context: context, isScrollControlled: true,
    builder: (_) => _PinSheet(title));
  return ok ?? false;
}
class _PinSheet extends StatefulWidget { final String title; const _PinSheet(this.title); @override State<_PinSheet> createState() => _P(); }
class _P extends State<_PinSheet> {
  String v = ''; int fails = 0; String err = '';
  void key(String k) {
    setState(() { if (k == '⌫') { if (v.isNotEmpty) v = v.substring(0, v.length - 1); } else if (v.length < 4) v += k; });
    if (v.length == 4) {
      if (app.checkPin(v)) { Navigator.pop(context, true); return; }
      HapticFeedback.heavyImpact();
      fails++;
      if (fails >= 3) { Navigator.pop(context, false); return; }
      setState(() { v = ''; err = 'Wrong PIN. ${3 - fails} tries left.'; });
    }
  }
  @override Widget build(BuildContext c) => SafeArea(child: Padding(padding: const EdgeInsets.all(20), child: Column(mainAxisSize: MainAxisSize.min, children: [
    Text(widget.title, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w700)), const SizedBox(height: 12),
    Row(mainAxisAlignment: MainAxisAlignment.center, children: [for (var i = 0; i < 4; i++) Padding(padding: const EdgeInsets.all(8), child: Icon(i < v.length ? Icons.circle : Icons.circle_outlined))]),
    if (err.isNotEmpty) Text(err, style: const TextStyle(color: Brand.error)),
    Keypad(onKey: key)])));
}

class ScanScreen extends StatefulWidget { final String title; const ScanScreen({super.key, required this.title}); @override State<ScanScreen> createState() => _Sc(); }
class _Sc extends State<ScanScreen> {
  bool done = false;
  @override Widget build(BuildContext c) => Scaffold(appBar: AppBar(title: Text(widget.title)), body: Stack(children: [
    MobileScanner(onDetect: (cap) {
      if (done || cap.barcodes.isEmpty) return;
      final raw = cap.barcodes.first.rawValue;
      if (raw == null) return;
      done = true; Navigator.pop(context, raw);
    }),
    const Align(alignment: Alignment.bottomCenter, child: Padding(padding: EdgeInsets.all(24), child: Text('Point the camera at the QR code.',
      style: TextStyle(color: Colors.white, fontSize: 18, backgroundColor: Colors.black54))))]));
}

Future<void> startLoad(BuildContext context) async {
  final amt = await Navigator.push<int>(context, MaterialPageRoute(builder: (ctx) =>
    AmountScreen(title: 'Load Offline Wallet', cta: 'Continue', maxKobo: AppState.offlineCap, onDone: (k) => Navigator.pop(ctx, k))));
  if (amt == null || !context.mounted) return;
  final ok = await askPin(context, 'Enter PIN to load ${naira(amt)}');
  if (!ok || !context.mounted) { if (context.mounted) toast(context, 'Load cancelled.'); return; }
  final err = app.loadFunds(amt);
  if (!context.mounted) return;
  if (err != null) { toast(context, err); return; }
  await Navigator.push(context, MaterialPageRoute(builder: (_) => SuccessScreen(title: 'Loaded', amount: amt, line: 'Offline Wallet: ${naira(app.offlineWallet)}')));
}

Future<void> startPay(BuildContext context) async {
  final raw = await Navigator.push<String>(context, MaterialPageRoute(builder: (_) => const ScanScreen(title: 'Scan receiver QR')));
  if (raw == null || !context.mounted) return;
  Map<String, dynamic> req;
  try {
    req = jsonDecode(raw) as Map<String, dynamic>;
    if (req['t'] != 'req') throw 'x';
  } catch (_) { toast(context, 'That is not a gOpay receive code.'); return; }
  int amt = (req['amt'] as num?)?.toInt() ?? 0;
  if (amt == 0) {
    final k = await Navigator.push<int>(context, MaterialPageRoute(builder: (ctx) =>
      AmountScreen(title: 'Pay', cta: 'Continue', maxKobo: AppState.perTxMax, onDone: (k) => Navigator.pop(ctx, k))));
    if (k == null || !context.mounted) return;
    amt = k;
  }
  final name = (req['name'] as String?) ?? 'Receiver';
  final ok = await askPin(context, 'Enter PIN to pay ${naira(amt)}');
  if (!ok || !context.mounted) { if (context.mounted) toast(context, 'Payment cancelled.'); return; }
  final r = app.pay(req['to'] as String, name, amt);
  if (!context.mounted) return;
  if (r.error != null) { HapticFeedback.heavyImpact(); toast(context, r.error!); return; }
  HapticFeedback.mediumImpact();
  await Navigator.push(context, MaterialPageRoute(builder: (_) => TokenScreen(token: r.token!, amount: amt, name: name)));
}

class TokenScreen extends StatelessWidget {
  final Map<String, dynamic> token; final int amount; final String name;
  const TokenScreen({super.key, required this.token, required this.amount, required this.name});
  @override Widget build(BuildContext c) => Scaffold(appBar: AppBar(title: const Text('Paid')), body: SafeArea(child: Padding(padding: const EdgeInsets.all(20), child: Column(children: [
    const Icon(Icons.check_circle, size: 64, color: Brand.green), const SizedBox(height: 8),
    Text(naira(amount), style: const TextStyle(fontSize: 44, fontWeight: FontWeight.w700)),
    Text('to $name · Waiting to settle'), const SizedBox(height: 16),
    const Text('Ask the receiver to tap "Scan payment" and scan this code.', textAlign: TextAlign.center), const SizedBox(height: 12),
    Container(color: Colors.white, padding: const EdgeInsets.all(8), child: QrImageView(data: jsonEncode(token), size: 260)),
    const Spacer(), FilledButton(onPressed: () => Navigator.pop(c), child: const Text('Done'))]))));
}

class SuccessScreen extends StatelessWidget {
  final String title, line; final int amount;
  const SuccessScreen({super.key, required this.title, required this.amount, required this.line});
  @override Widget build(BuildContext c) => Scaffold(body: SafeArea(child: Padding(padding: const EdgeInsets.all(24), child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
    const Icon(Icons.check_circle, size: 96, color: Brand.green), const SizedBox(height: 12),
    Text(title, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w700)),
    Text(naira(amount), style: const TextStyle(fontSize: 48, fontWeight: FontWeight.w700)), Text(line),
    const SizedBox(height: 32), FilledButton(onPressed: () => Navigator.pop(c), child: const Text('Done'))]))));
}

class ReceiveScreen extends StatefulWidget { const ReceiveScreen({super.key}); @override State<ReceiveScreen> createState() => _R(); }
class _R extends State<ReceiveScreen> {
  int amount = 0;
  Future<void> scan() async {
    final raw = await Navigator.push<String>(context, MaterialPageRoute(builder: (_) => const ScanScreen(title: 'Scan payment')));
    if (raw == null || !mounted) return;
    final r = app.receive(raw);
    HapticFeedback.mediumImpact();
    await showModalBottomSheet<void>(context: context, builder: (_) => SafeArea(child: Padding(padding: const EdgeInsets.all(20), child: Column(mainAxisSize: MainAxisSize.min, children: [
      if (r.error != null) Text(r.error!, style: const TextStyle(fontSize: 18)) else ...[
        Text(r.ok ? '${naira(r.amount)} pending' : 'Payment rejected', style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w700)),
        const SizedBox(height: 8),
        for (final k in r.checks) ListTile(dense: true, leading: Icon(k.ok ? Icons.check_circle : Icons.cancel, color: k.ok ? Brand.green : Brand.error),
          title: Text(k.name), trailing: Text(k.ok ? 'Passed' : 'Failed')),
        if (r.ok) const Text('It becomes Available after you go online.')],
      const SizedBox(height: 12), FilledButton(onPressed: () => Navigator.pop(context), child: const Text('OK'))]))));
  }
  @override Widget build(BuildContext c) {
    final req = jsonEncode({'t': 'req', 'to': app.myRef, 'name': 'gOpay user', 'amt': amount});
    return Scaffold(appBar: AppBar(title: const Text('Receive')), body: SafeArea(child: Padding(padding: const EdgeInsets.all(20), child: Column(children: [
      Text(amount == 0 ? 'Any amount' : naira(amount), style: const TextStyle(fontSize: 36, fontWeight: FontWeight.w700)),
      const SizedBox(height: 4), Text('Max you accept per payment: ${naira(AppState.maxAccept)}'),
      const SizedBox(height: 12), Container(color: Colors.white, padding: const EdgeInsets.all(8), child: QrImageView(data: req, size: 240)),
      const SizedBox(height: 8), const Text('Payer scans this code. Then tap "Scan payment".', textAlign: TextAlign.center),
      const Spacer(),
      OutlinedButton(onPressed: () async {
        final k = await Navigator.push<int>(c, MaterialPageRoute(builder: (ctx) =>
          AmountScreen(title: 'Amount', cta: 'Show QR', maxKobo: AppState.maxAccept, onDone: (k) => Navigator.pop(ctx, k))));
        if (k != null) setState(() => amount = k);
      }, child: const Text('Set amount')), const SizedBox(height: 8),
      FilledButton(onPressed: scan, child: const Text('Scan payment'))]))));
  }
}

class HistoryScreen extends StatefulWidget { const HistoryScreen({super.key}); @override State<HistoryScreen> createState() => _H(); }
class _H extends State<HistoryScreen> {
  String f = 'all';
  static const filters = {'all': 'All', 'sent': 'Sent', 'received': 'Received', 'pending': 'Pending', 'settled': 'Settled', 'failed': 'Failed'};
  bool match(Tx t) => switch (f) {
    'sent' => t.kind == 'sent', 'received' => t.kind == 'received',
    'pending' => t.status == 'pending' || t.status == 'waiting', 'settled' => t.status == 'settled', 'failed' => t.status == 'failed', _ => true };
  @override Widget build(BuildContext c) {
    final list = app.txs.where(match).toList();
    return SafeArea(child: ListView(padding: const EdgeInsets.all(16), children: [
      const Text('History', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w700)), const SizedBox(height: 8),
      SingleChildScrollView(scrollDirection: Axis.horizontal, child: Row(children: [for (final e in filters.entries) Padding(padding: const EdgeInsets.only(right: 8),
        child: ChoiceChip(label: Text(e.value), selected: f == e.key, onSelected: (_) => setState(() => f = e.key)))])),
      const SizedBox(height: 8),
      if (list.isEmpty) const Padding(padding: EdgeInsets.all(32), child: Center(child: Text('No payments yet.'))),
      for (final t in list) TxTile(t, onTap: () => showModalBottomSheet<void>(context: c, builder: (_) => SafeArea(child: Padding(padding: const EdgeInsets.all(20), child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(naira(t.amount), style: const TextStyle(fontSize: 36, fontWeight: FontWeight.w700)),
        Text('${t.kind == 'sent' ? 'To' : t.kind == 'load' ? 'From' : 'From'} ${t.peer}'),
        Text('Status: ${statusLabel(t.status)}'), Text('Time: ${DateTime.fromMillisecondsSinceEpoch(t.at).toLocal().toString().substring(0, 16)}'),
        Text('Reference: ${t.id}')]))))),
    ]));
  }
}

class MeScreen extends StatelessWidget {
  const MeScreen({super.key});
  @override Widget build(BuildContext c) => SafeArea(child: ListView(padding: const EdgeInsets.all(16), children: [
    const Text('Me', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w700)), const SizedBox(height: 8),
    ListTile(leading: const Icon(Icons.phone), title: Text(app.phone.isEmpty ? 'No phone' : app.phone)),
    ListTile(leading: const Icon(Icons.verified_user_outlined), title: const Text('KYC Tier 1'),
      subtitle: Text('Per payment ${naira(AppState.perTxMax)} · Offline wallet ${naira(AppState.offlineCap)}')),
    ListTile(leading: const Icon(Icons.language), title: const Text('Language'), trailing: DropdownButton<String>(value: app.locale,
      items: [for (final e in _l.entries) DropdownMenuItem(value: e.key, child: Text(e.value))], onChanged: (v) { if (v != null) app.setLocale(v); })),
    ListTile(leading: const Icon(Icons.warning_amber_rounded), title: const Text('Risk notice'),
      onTap: () => showDialog<void>(context: c, builder: (_) => AlertDialog(title: const Text('Risk notice'), content: const Text(riskText), actions: [TextButton(onPressed: () => Navigator.pop(c), child: const Text('OK'))]))),
    const Divider(), const Padding(padding: EdgeInsets.all(8), child: Text('Demo tools', style: TextStyle(fontWeight: FontWeight.w700))),
    const Text('This build uses simulated money and a simulated bank. Use these to test on one phone.'),
    ListTile(leading: const Icon(Icons.download), title: const Text('Simulate incoming ₦500 (pending)'),
      onTap: () { app.demoIncoming(); toast(c, '₦500 pending. Go online (tap the pill on Home) to settle it.'); }),
    ListTile(leading: const Icon(Icons.sync), title: const Text('Sync now'),
      onTap: () { final n = app.sync(); toast(c, n == 0 ? 'Nothing to settle.' : '$n payment(s) settled.'); }),
    ListTile(leading: const Icon(Icons.logout), title: const Text('Log out and reset demo'), onTap: () => app.reset()),
  ]));
}
const _l = {'en': 'English', 'pcm': 'Pidgin', 'ha': 'Hausa', 'yo': 'Yoruba', 'ig': 'Igbo'};
