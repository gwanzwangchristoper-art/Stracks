// DEMO wallet engine. Simulated bank, simulated settlement, demo checksums instead of real signatures.
// The real crypto lives in phase3-mobile-core and is not wired in yet.
import 'dart:convert';
import 'dart:math';
import 'package:crypto/crypto.dart';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

String naira(int kobo) {
  final n = kobo ~/ 100;
  final s = n.toString().replaceAllMapped(RegExp(r'\B(?=(\d{3})+(?!\d))'), (m) => ',');
  return '₦$s';
}

class Tx {
  final String id, kind, peer; // kind: load | sent | received
  String status; // pending | waiting | settled | failed
  final int amount, at;
  Tx(this.id, this.kind, this.peer, this.status, this.amount, this.at);
  Map<String, dynamic> toJson() => {'id': id, 'kind': kind, 'peer': peer, 'status': status, 'amount': amount, 'at': at};
  factory Tx.fromJson(Map<String, dynamic> j) => Tx(j['id'] as String, j['kind'] as String, j['peer'] as String,
      j['status'] as String, (j['amount'] as num).toInt(), (j['at'] as num).toInt());
}

class Chk { final String name; final bool ok; Chk(this.name, this.ok); }
class PayResult { final Map<String, dynamic>? token; final String? error; PayResult(this.token, this.error); }
class RecvResult { final List<Chk> checks; final bool ok; final String? error; final int amount;
  RecvResult(this.checks, this.ok, this.error, this.amount); }

final AppState app = AppState();

class AppState extends ChangeNotifier {
  bool onboarded = false, online = true;
  String locale = 'en', phone = '', pin = '', walletId = '', myRef = '';
  int bank = 5000000; // demo linked bank account: ₦50,000 (kobo)
  int offlineWallet = 0, available = 0, counter = 0, cumulativeSpent = 0;
  List<Tx> txs = [];
  Set<String> seen = {};

  static const perTxMax = 500000, offlineCap = 2000000, pendingCap = 2000000, maxAccept = 500000; // Tier 1, kobo

  int get pending => txs.where((t) => t.kind == 'received' && t.status == 'pending').fold(0, (s, t) => s + t.amount);

  String _rid([int n = 8]) {
    final r = Random.secure();
    const h = '0123456789abcdef';
    return List.generate(n, (_) => h[r.nextInt(16)]).join();
  }

  String _sig(Map<String, dynamic> t) => sha256
      .convert(utf8.encode('${t['id']}|${t['w']}|${t['to']}|${t['amt']}|${t['n']}|${t['cum']}|${t['at']}|${t['exp']}|demo'))
      .toString().substring(0, 16);

  Future<void> init() async {
    final p = await SharedPreferences.getInstance();
    final raw = p.getString('state');
    if (raw == null) return;
    try {
      final j = jsonDecode(raw) as Map<String, dynamic>;
      onboarded = j['onboarded'] as bool; locale = j['locale'] as String; phone = j['phone'] as String;
      pin = j['pin'] as String; walletId = j['walletId'] as String; myRef = j['myRef'] as String;
      bank = j['bank'] as int; offlineWallet = j['offline'] as int; available = j['available'] as int;
      counter = j['counter'] as int; cumulativeSpent = j['cum'] as int; online = j['online'] as bool;
      txs = (j['txs'] as List).map((e) => Tx.fromJson(e as Map<String, dynamic>)).toList();
      seen = (j['seen'] as List).map((e) => e as String).toSet();
    } catch (_) {/* corrupt state: start fresh */}
  }

  Future<void> _changed() async {
    notifyListeners();
    final p = await SharedPreferences.getInstance();
    await p.setString('state', jsonEncode({
      'onboarded': onboarded, 'locale': locale, 'phone': phone, 'pin': pin, 'walletId': walletId, 'myRef': myRef,
      'bank': bank, 'offline': offlineWallet, 'available': available, 'counter': counter, 'cum': cumulativeSpent,
      'online': online, 'txs': txs.map((t) => t.toJson()).toList(), 'seen': seen.toList(),
    }));
  }

  void setLocale(String l) { locale = l; _changed(); }
  void setPhone(String v) { phone = v; }
  void setPin(String v) { pin = v; }
  bool checkPin(String p) => p == pin;

  void finishOnboarding() {
    walletId = 'w-${_rid()}'; myRef = 'r-${_rid()}'; onboarded = true; _changed();
  }

  Future<void> reset() async {
    onboarded = false; online = true; locale = 'en'; phone = ''; pin = ''; walletId = ''; myRef = '';
    bank = 5000000; offlineWallet = 0; available = 0; counter = 0; cumulativeSpent = 0; txs = []; seen = {};
    await _changed();
  }

  String? loadFunds(int a) {
    if (!online) return 'You need internet to load. Go online and try again.';
    if (a > bank) return 'Not enough money in your bank account.';
    if (offlineWallet + a > offlineCap) return 'Over your offline wallet limit of ${naira(offlineCap)}.';
    bank -= a; offlineWallet += a;
    txs.insert(0, Tx(_rid(), 'load', 'Bank account', 'settled', a, DateTime.now().millisecondsSinceEpoch));
    _changed();
    return null;
  }

  PayResult pay(String toRef, String toName, int amt) {
    if (amt <= 0) return PayResult(null, 'Enter an amount.');
    if (amt > perTxMax) return PayResult(null, 'Max per payment is ${naira(perTxMax)}.');
    if (amt > offlineWallet) return PayResult(null, 'Not enough in your Offline Wallet. Load more when online.');
    final now = DateTime.now().millisecondsSinceEpoch;
    counter += 1; cumulativeSpent += amt; offlineWallet -= amt;
    final t = <String, dynamic>{'v': 1, 't': 'pay', 'id': _rid(12), 'w': walletId, 'to': toRef, 'amt': amt,
      'n': counter, 'cum': cumulativeSpent, 'at': now, 'exp': now + 10 * 60 * 1000, 'name': 'gOpay user'};
    t['sig'] = _sig(t);
    txs.insert(0, Tx(t['id'] as String, 'sent', toName, 'waiting', amt, now));
    _changed();
    return PayResult(t, null);
  }

  RecvResult receive(String raw) {
    Map<String, dynamic> t;
    try {
      t = jsonDecode(raw) as Map<String, dynamic>;
      if (t['t'] != 'pay') throw 'x';
    } catch (_) {
      return RecvResult([], false, 'That is not a gOpay payment code.', 0);
    }
    final now = DateTime.now().millisecondsSinceEpoch;
    final amt = (t['amt'] as num?)?.toInt() ?? 0;
    final checks = <Chk>[
      Chk('Signature is valid', t['sig'] == _sig(t)),
      Chk('Meant for you', t['to'] == myRef),
      Chk('Not expired', now < ((t['exp'] as num?)?.toInt() ?? 0)),
      Chk('Not seen before', !seen.contains(t['id'])),
      Chk('Within your limits', amt > 0 && amt <= maxAccept && pending + amt <= pendingCap),
    ];
    final ok = checks.every((c) => c.ok);
    if (ok) {
      seen.add(t['id'] as String);
      txs.insert(0, Tx(t['id'] as String, 'received', (t['name'] as String?) ?? 'Someone', 'pending', amt, now));
      _changed();
    }
    return RecvResult(checks, ok, null, amt);
  }

  /// Simulates going online: the "server" settles pending receipts and sent payments.
  int sync() {
    var n = 0;
    for (final t in txs) {
      if (t.kind == 'received' && t.status == 'pending') { t.status = 'settled'; available += t.amount; n++; }
      if (t.kind == 'sent' && t.status == 'waiting') { t.status = 'settled'; n++; }
    }
    _changed();
    return n;
  }

  String? setOnline(bool v) {
    online = v;
    final n = v ? sync() : 0;
    if (!v) _changed();
    return v ? (n == 0 ? 'You are online. Nothing to settle.' : '$n payment(s) settled.') : null;
  }

  void demoIncoming() {
    txs.insert(0, Tx(_rid(12), 'received', 'Demo payer', 'pending', 50000, DateTime.now().millisecondsSinceEpoch));
    _changed();
  }
}
