// ALL brand decisions live here (name, colors, logo). Provisional name: change `appName` + strings only.
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class Brand {
  static const appName = 'gOpay';
  static const green = Color(0xFF1FA855), deepGreen = Color(0xFF127A3C), yellow = Color(0xFFFFC93C);
  static const ink = Color(0xFF12211A), softGrey = Color(0xFFF3F5F4), error = Color(0xFFD92D20), amber = Color(0xFFB54708);
  static const radius = 16.0;

  static ThemeData theme() => ThemeData(
    useMaterial3: true,
    colorScheme: ColorScheme.fromSeed(seedColor: green, primary: green, error: error),
    scaffoldBackgroundColor: softGrey,
    textTheme: GoogleFonts.poppinsTextTheme().apply(bodyColor: ink, displayColor: ink),
    filledButtonTheme: FilledButtonThemeData(style: FilledButton.styleFrom(
      minimumSize: const Size.fromHeight(56), backgroundColor: green,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(radius)))),
  );
}

/// Logo: green rounded tile (radius 27%) + white ring + two chevrons (first yellow @55%, second solid).
class LogoMark extends StatelessWidget {
  final double size; const LogoMark({super.key, this.size = 48});
  @override Widget build(BuildContext c) => Semantics(label: Brand.appName, child: CustomPaint(size: Size.square(size), painter: _LogoPainter()));
}
class _LogoPainter extends CustomPainter {
  @override void paint(Canvas cv, Size s) {
    final w = s.width;
    cv.drawRRect(RRect.fromRectAndRadius(Offset.zero & s, Radius.circular(w * .27)), Paint()..color = Brand.green);
    cv.drawCircle(Offset(w * .32, w * .5), w * .13, Paint()..color = Colors.white..style = PaintingStyle.stroke..strokeWidth = w * .06);
    Paint chev(double a) => Paint()..color = Brand.yellow.withOpacity(a)..style = PaintingStyle.stroke..strokeWidth = w * .07..strokeCap = StrokeCap.round..strokeJoin = StrokeJoin.round;
    for (final (x, a) in [(.52, .55), (.68, 1.0)]) {
      cv.drawPath(Path()..moveTo(w * x, w * .36)..lineTo(w * (x + .11), w * .5)..lineTo(w * x, w * .64), chev(a));
    }
  }
  @override bool shouldRepaint(_) => false;
}

/// Signature overlay: one soft flat shape bleeding off a surface edge, behind content.
class RingOverlay extends StatelessWidget {
  final Widget child; final Color color;
  const RingOverlay({super.key, required this.child, this.color = const Color(0x1FFFFFFF)});
  @override Widget build(BuildContext c) => Stack(clipBehavior: Clip.hardEdge, children: [
    Positioned(right: -50, top: -50, child: IgnorePointer(child: Container(width: 180, height: 180,
      decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: color, width: 28))))),
    child]);
}
