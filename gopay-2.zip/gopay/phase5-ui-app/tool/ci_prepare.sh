#!/usr/bin/env bash
# Run from phase5-ui-app. Generates the Android shell, sets app name, installs gOpay launcher icon.
set -e
flutter create . --platforms=android --org ng.gopay --project-name gopay_app
sed -i 's/android:label="[^"]*"/android:label="gOpay"/' android/app/src/main/AndroidManifest.xml
flutter pub get
dart run flutter_launcher_icons
