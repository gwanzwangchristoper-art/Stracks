import { test } from "node:test";
import assert from "node:assert/strict";
import { createServer } from "node:http";
import { generateKeyPairSync } from "node:crypto";
import { buildApp, makeHandler } from "../src/server.ts";
import { rawFromPub } from "../src/protocol.ts";

test("HTTP: otp -> kyc -> register -> load -> balance; admin auth enforced", async () => {
  const { app, issuer } = buildApp(); const srv = createServer(makeHandler(app));
  await new Promise<void>((r) => srv.listen(0, r)); const base = `http://127.0.0.1:${(srv.address() as any).port}`;
  const call = async (m: string, p: string, body?: any, tok?: string, hdr: any = {}) => {
    const r = await fetch(base + p, { method: m, headers: { "content-type": "application/json", ...(tok ? { authorization: "Bearer " + tok } : {}), ...hdr }, body: body ? JSON.stringify(body) : undefined });
    return { status: r.status, body: await r.json() as any };
  };
  try {
    const phone = "+2348012345678"; issuer.fund("ACCT-" + phone, 100_000_00);
    await call("POST", "/v1/auth/otp/request", { phone });
    const { body: s } = await call("POST", "/v1/auth/otp/verify", { phone, code: "123456" });
    assert.equal((await call("POST", "/v1/kyc/submit", { tier: 1, data: { bvn: "123" } }, s.token)).status, 422);
    assert.equal((await call("POST", "/v1/kyc/submit", { tier: 1, data: { bvn: "12345678901" } }, s.token)).status, 200);
    const pub = Buffer.from(rawFromPub(generateKeyPairSync("ec", { namedCurve: "prime256v1" }).publicKey)).toString("base64");
    const reg = await call("POST", "/v1/devices/register", { publicKey: pub, platform: "android", attestation: "mock-ok" }, s.token);
    assert.equal(reg.status, 200);
    const ld = await call("POST", "/v1/wallet/load", { deviceId: reg.body.deviceId, loadId: "a1", amount: 1_000_00, source: "issuer", attestation: "mock-ok", pinVerified: true }, s.token);
    assert.equal(ld.body.offlineBalance, 1_000_00);
    assert.equal((await call("GET", "/v1/balance", undefined, s.token)).body.offline, 1_000_00);
    assert.equal((await call("GET", "/v1/blocklist?since=0", undefined, s.token)).status, 200);
    assert.equal((await call("GET", "/v1/balance")).status, 401);
    assert.equal((await call("GET", "/admin/audit")).status, 401);
    assert.equal((await call("GET", "/admin/audit", undefined, undefined, { "x-admin-key": "dev-admin-key" })).status, 200);
  } finally { srv.close(); }
});
