import { test } from "node:test";
import assert from "node:assert/strict";
import { setup, Phone } from "./helpers.ts";
import { parseToken, hex } from "../src/protocol.ts";
import { ApiError } from "../src/app.ts";
import { MockIssuer } from "../src/issuer.ts";

async function world() {
  const env = setup();
  const alice = await new Phone(env, "+2348011111111").onboard(2);
  const bob = await new Phone(env, "+2348022222222").onboard(2);
  const carol = await new Phone(env, "+2348033333333").onboard(2);
  await alice.load(10_000_00);
  return { env, alice, bob, carol };
}
const avail = (e: ReturnType<typeof setup>, p: Phone) => e.app.ledger.balance("available:" + p.userId);
const escrow = (e: ReturnType<typeof setup>, p: Phone) => e.app.ledger.balance("escrow:" + p.walletId);

test("load-pay-settle: money moves escrow -> receiver available; issuer debited once", async () => {
  const { env, alice, bob } = await world();
  assert.equal(await env.issuer.balance("ACCT-" + alice.phone), 1_000_000_00 - 10_000_00);
  assert.equal(escrow(env, alice), 10_000_00);
  const t1 = alice.pay(bob.walletId, 2_000_00), t2 = alice.pay(bob.walletId, 3_000_00);
  const r = await bob.settle([t2, t1]); // out of order is fine
  assert.deepEqual(r.map((x) => x.status), ["settled", "settled"]);
  assert.equal(avail(env, bob), 5_000_00); assert.equal(escrow(env, alice), 5_000_00);
  assert.ok(env.app.ledger.audit());
});
test("idempotent: re-uploading the same batch changes nothing", async () => {
  const { env, alice, bob } = await world();
  const t = alice.pay(bob.walletId, 1_000_00);
  await bob.settle([t]); const r = await bob.settle([t, t]);
  assert.deepEqual(r.map((x) => x.status), ["duplicate", "duplicate"]); assert.equal(avail(env, bob), 1_000_00);
});
test("wrong receiver: another user cannot settle a token addressed to Bob", async () => {
  const { alice, bob, carol, env } = await world();
  const t = alice.pay(bob.walletId, 1_000_00);
  const r = await carol.settle([t]); assert.equal(r[0]!.reason, "wrong_receiver"); assert.equal(avail(env, carol), 0);
});
test("copied token (replay by another receiver or later) cannot pay twice", async () => {
  const { alice, bob, env } = await world();
  const t = alice.pay(bob.walletId, 1_000_00);
  await bob.settle([t]); await bob.settle([t]); assert.equal(avail(env, bob), 1_000_00);
});
test("tampered token bytes rejected", async () => {
  const { alice, bob, env } = await world();
  const raw = Buffer.from(alice.pay(bob.walletId, 1_000_00)); raw[raw.length - 5] ^= 0xff;
  const r = await bob.settle([new Uint8Array(raw)]); assert.equal(r[0]!.status, "rejected"); assert.equal(avail(env, bob), 0);
});
test("double-spend (same counter, two receivers): first settles, second rejected, wallet frozen and blocklisted", async () => {
  const { alice, bob, carol, env } = await world();
  const a = alice.pay(bob.walletId, 1_000_00);
  alice.counter--; alice.cumulative -= 1_000_00;          // attacker rolls local state back (cloned/restored phone)
  const b = alice.pay(carol.walletId, 1_000_00);
  assert.equal((await bob.settle([a]))[0]!.status, "settled");
  assert.equal((await carol.settle([b]))[0]!.reason, "double_spend");
  assert.equal(env.app.store.wallets.get(alice.walletId)!.status, "frozen");
  assert.ok(env.app.blocklistSince(0).entries.some((e) => e.kind === "wallet" && e.id === alice.walletId));
  assert.equal(env.app.store.disputes[0]!.kind, "double_spend");
  await assert.rejects(env.app.refreshCertificate(alice.user, alice.deviceId, "mock-ok"), (e: any) => e.code === "blocked");   // frozen => device blocked before anything else
});
test("clone spends beyond escrow with fresh counters: receivers beyond the escrow lose, escrow never goes negative", async () => {
  const { alice, bob, carol, env } = await world();
  const clone = { counter: 0, cumulative: 0 };
  const mk = (to: Phone, amt: number) => { clone.counter++; clone.cumulative += amt; return alice.pay(to.walletId, amt, { counter: clone.counter, cumulativeSpent: clone.cumulative }, { noAdvance: true }); };
  const toks: [Phone, Uint8Array][] = [];
  for (let i = 0; i < 4; i++) toks.push([i % 2 ? bob : carol, mk(i % 2 ? bob : carol, 2_900_00 + i)]);
  // ceiling is 10,000: counters 1-3 fit (8,700+), 4th exceeds the signed ceiling -> receiver would refuse offline; server also refuses
  const results = [];
  for (const [p, t] of toks) results.push((await p.settle([t]))[0]!);
  assert.equal(results.filter((r) => r.status === "settled").length, 3);
  assert.equal(results[3]!.status, "rejected");
  assert.ok(escrow(env, alice) >= 0 && env.app.ledger.audit());
});
test("forged certificate rejected at settlement", async () => {
  const { alice, bob } = await world();
  const t = Buffer.from(alice.pay(bob.walletId, 1_000_00));
  const p = parseToken(t); const i = t.indexOf(Buffer.from(p.certBlob)); t[i + 10] ^= 1;
  assert.equal((await bob.settle([new Uint8Array(t)]))[0]!.status, "rejected");
});
test("token created after cert expiry + grace is too late; unspent escrow is refunded by the expiry job", async () => {
  const { alice, bob, env } = await world();
  const t = alice.pay(bob.walletId, 1_000_00);
  env.clock.advance(5 * 86400 + 7 * 86400 + 10);
  assert.equal((await bob.settle([t]))[0]!.reason, "too_late");
  const before = await env.issuer.balance("ACCT-" + alice.phone);
  const r = await env.app.runExpiryRefunds();
  const aw = r.find((x) => x.walletId === alice.walletId)!; assert.equal(aw.refunded, 10_000_00);
  assert.equal(await env.issuer.balance("ACCT-" + alice.phone), before + 10_000_00);
  assert.equal(env.app.store.wallets.get(alice.walletId)!.status, "closed");
  assert.ok(env.app.ledger.audit());
});
test("token settles after payer cert expiry but inside grace (receiver was offline for days)", async () => {
  const { alice, bob, env } = await world();
  const t = alice.pay(bob.walletId, 1_000_00);
  env.clock.advance(6 * 86400);
  assert.equal((await bob.settle([t]))[0]!.status, "settled");
});
test("load limits: tier cap, cooling cap, daily limit, idempotent retry", async () => {
  const env = setup(); const p = await new Phone(env, "+2348099999999").onboard(1);
  await assert.rejects(p.load(6_000_00), (e: any) => e.code === "over_cap");       // tier1 cap 20k * 0.25 cooling = 5k
  await p.load(4_000_00);
  const loadId = "same"; const args = { deviceId: p.deviceId, loadId, amount: 500_00, source: "issuer" as const, attestation: "mock-ok", pinVerified: true };
  await env.app.load(p.user, args); await env.app.load(p.user, args);
  assert.equal(env.app.ledger.balance("escrow:" + p.walletId), 4_500_00);
  env.clock.advance(73 * 3600);                                                     // cooling over: cap 20k
  await p.load(15_000_00);
  await assert.rejects(p.load(1_000_00), (e: any) => ["over_cap", "daily_limit"].includes(e.code));
});
test("issuer outage or insufficient funds never creates escrow", async () => {
  const env = setup(); const p = await new Phone(env, "+2348077777777").onboard(2, 1_000_00);
  await assert.rejects(p.load(5_000_00), (e: any) => e.code === "insufficient_funds");
  (env.issuer as MockIssuer).down = true;
  await assert.rejects(p.load(500_00), (e: any) => e.code === "issuer_unavailable");
  assert.equal(env.app.ledger.balance("escrow:" + p.walletId), 0);
});
test("blocked/unattested devices and rooted phones are refused", async () => {
  const env = setup(); const p = await new Phone(env, "+2348066666666").onboard(2);
  await assert.rejects(env.app.load(p.user, { deviceId: p.deviceId, loadId: "x", amount: 100, source: "issuer", attestation: "rooted", pinVerified: true }), (e: any) => e.code === "attestation_failed");
  env.app.freeze(p.walletId, "test", "admin");
  await assert.rejects(env.app.load(p.user, { deviceId: p.deviceId, loadId: "y", amount: 100, source: "issuer", attestation: "mock-ok", pinVerified: true }), (e: any) => e.code === "blocked");
});
test("frozen wallet escrow is held, not refunded, until admin forces it", async () => {
  const { alice, env } = await world();
  env.app.freeze(alice.walletId, "fraud ring", "admin");
  await assert.rejects(env.app.refundWallet(alice.walletId, "job"), (e: any) => e.code === "wallet_frozen");
  env.clock.advance(20 * 86400); assert.deepEqual(await env.app.runExpiryRefunds(), []);
  assert.equal((await env.app.refundWallet(alice.walletId, "admin", true)).refunded, 10_000_00);
});
test("new phone: old wallet retired, keys never copied, old device blocked", async () => {
  const { alice, env } = await world();
  const { generateKeyPairSync } = await import("node:crypto"); const { rawFromPub } = await import("../src/protocol.ts");
  const k = rawFromPub(generateKeyPairSync("ec", { namedCurve: "prime256v1" }).publicKey);
  const r = await env.app.registerDevice(alice.user, Buffer.from(k).toString("base64"), "ios", "mock-ok");
  assert.notEqual(r.walletId, alice.walletId); assert.equal(env.app.store.wallets.get(alice.walletId)!.status, "retired");
  // tokens already issued by the OLD wallet still settle during grace (receivers are protected)
  const bob = await new Phone(env, "+2348022222299").onboard(2); const tok = alice.pay(bob.walletId, 1_000_00);
  assert.equal((await bob.settle([tok]))[0]!.status, "settled");
  await assert.rejects(env.app.refreshCertificate(alice.user, alice.deviceId, "mock-ok"), (e: any) => e.code === "device_not_allowed");
  assert.equal(await env.app.refundWallet(alice.walletId, "job").then((x) => x.refunded), 9_000_00);
});
test("OTP + session: wrong code, bad session", async () => {
  const env = setup(); env.app.requestOtp("+2348055555555");
  assert.throws(() => env.app.verifyOtp("+2348055555555", "000000"), (e: any) => e.code === "otp_wrong");
  assert.throws(() => env.app.auth("a.b"), (e: any) => e instanceof ApiError && e.status === 401);
});
test("receipt retrieval only for parties", async () => {
  const { alice, bob, carol, env } = await world();
  const t = alice.pay(bob.walletId, 1_000_00); await bob.settle([t]);
  const id = hex(parseToken(t).payload.txId);
  assert.equal(env.app.receipt(bob.user, id).status, "settled"); assert.equal(env.app.receipt(alice.user, id).amount, 1_000_00);
  assert.throws(() => env.app.receipt(carol.user, id), (e: any) => e.code === "no_receipt");
});
test("rotate wallet after local tamper lock: new walletId, old one keeps settling then is refunded", async () => {
  const { alice, bob, env } = await world();
  const pre = alice.pay(bob.walletId, 1_000_00);
  const r = await env.app.rotateWallet(alice.user, alice.deviceId, "mock-ok");
  assert.notEqual(r.walletId, alice.walletId);
  assert.equal((await bob.settle([pre]))[0]!.status, "settled");   // token issued before the lock still pays
  env.clock.advance(13 * 86400);
  const jobs = await env.app.runExpiryRefunds();
  assert.equal(jobs.find((j) => j.walletId === alice.walletId)!.refunded, 9_000_00);
  assert.ok(env.app.ledger.audit());
});
