import { test } from "node:test";
import assert from "node:assert/strict";
import { encode, decode } from "../src/cbor.ts";
import { b45encode, b45decode } from "../src/base45.ts";
import { parseToken, verifyForReceiver, type ReceiverCtx, hex } from "../src/protocol.ts";
import { setup, Phone, cert } from "./helpers.ts";

test("cbor roundtrip and canonical rejection", () => {
  const m = new Map<number, any>([[1, 1], [2, new Uint8Array([1, 2])], [3, "é"], [4, [0, 23, 24, 255, 256, 65535, 65536, 2 ** 32, 2 ** 40]]]);
  assert.deepEqual(decode(encode(m)), m);
  assert.throws(() => decode(Uint8Array.from([0x18, 0x05])), /non-canonical/);          // 5 encoded in 2 bytes
  assert.throws(() => decode(Uint8Array.from([0xa2, 0x02, 0x00, 0x01, 0x00])), /ascending/); // keys out of order
  assert.throws(() => decode(Uint8Array.from([0x01, 0x00])), /trailing/);
  assert.throws(() => decode(Uint8Array.from([0x9f, 0xff])), /indefinite/);
});
test("base45 RFC 9285 vectors", () => {
  assert.equal(b45encode(new TextEncoder().encode("ietf!")), "QED8WEX0");
  assert.equal(b45encode(new TextEncoder().encode("Hello!!")), "%69 VD92EX0");
  assert.equal(new TextDecoder().decode(b45decode("QED8WEX0")), "ietf!");
  assert.throws(() => b45decode("GGW"), /overflow/);
});

async function world() {
  const env = setup();
  const alice = await new Phone(env, "+2348011111111").onboard(2);
  const bob = await new Phone(env, "+2348022222222").onboard(2);
  await alice.load(5_000_00);
  const ctx = (over: Partial<ReceiverCtx> = {}): ReceiverCtx => ({
    trustedIssuerKeys: env.app.keys.trusted(), nowSec: env.clock.get(), maxClockSkew: 300, blockedWallets: new Set(), blockedDeviceKeyIds: new Set(),
    myWalletId: bob.walletId, myCurrency: "NGN", myMaxAccept: 10_000_00, pendingTotal: 0, pendingCap: 100_000_00, seenTxIds: new Set(), seenWalletCounters: new Set(), ...over });
  return { env, alice, bob, ctx };
}

test("receiver pipeline: happy path passes all checks", async () => {
  const { alice, bob, ctx } = await world();
  const r = verifyForReceiver(alice.pay(bob.walletId, 1000_00), ctx());
  assert.equal(r.ok, true); assert.equal(r.checks.length, 12);
});

const bad = async (mutate: (w: Awaited<ReturnType<typeof world>>) => [Uint8Array, Partial<ReceiverCtx>?], failId: string) => {
  const w = await world(); const [bytes, c] = mutate(w);
  const r = verifyForReceiver(bytes, w.ctx(c ?? {}));
  assert.equal(r.ok, false); assert.equal(r.checks.at(-1)!.id, failId);
};
test("tampered amount fails payer signature", () => bad(({ alice, bob }) => {
  const raw = Buffer.from(alice.pay(bob.walletId, 1000_00));
  const enc = Buffer.from(encode(1000_00));                 // amount 100000 is a unique 5-byte uint in the payload
  const at = raw.indexOf(Buffer.concat([Buffer.from([0x05]), enc])); // key 5 (amount) then value
  assert.ok(at > 0); raw[at + enc.length] ^= 0x01;            // change the amount by one kobo-unit
  return [new Uint8Array(raw)];
}, "payer_signature"));
test("wrong receiver", () => bad(({ alice }) => [alice.pay("someone-else", 1000_00)], "bound_to_receiver"));
test("expired token", () => bad(({ alice, bob, env }) => { const t = alice.pay(bob.walletId, 100_00); env.clock.advance(1000); return [t, { nowSec: env.clock.get() }]; }, "token_valid_time"));
test("over payer per-tx max", () => bad(({ alice, bob }) => [alice.pay(bob.walletId, 20_000_00)], "within_per_tx_max"));
test("over spend ceiling", () => bad(({ alice, bob }) => [alice.pay(bob.walletId, 100_00, { cumulativeSpent: 6_000_00 })], "within_ceiling"));
test("replay: same txId seen", () => bad(({ alice, bob }) => { const t = alice.pay(bob.walletId, 100_00); return [t, { seenTxIds: new Set([hex(parseToken(t).payload.txId)]) }]; }, "not_seen_before"));
test("replay: same (wallet,counter) seen", () => bad(({ alice, bob }) => { const t = alice.pay(bob.walletId, 100_00); const p = parseToken(t).payload; return [t, { seenWalletCounters: new Set([`${p.walletId}:${p.counter}`]) }]; }, "not_seen_before"));
test("receiver max-accept and pending cap", async () => {
  await bad(({ alice, bob }) => [alice.pay(bob.walletId, 5000_00), { myMaxAccept: 1000_00 }], "within_receiver_limits");
  await bad(({ alice, bob }) => [alice.pay(bob.walletId, 1000_00), { pendingTotal: 99_500_00 }], "within_receiver_limits");
});
test("blocklisted payer", () => bad(({ alice, bob }) => [alice.pay(bob.walletId, 100_00), { blockedWallets: new Set([alice.walletId]) }], "not_blocklisted"));
test("unknown issuer key", () => bad(({ alice, bob }) => [alice.pay(bob.walletId, 100_00), { trustedIssuerKeys: new Map() }], "issuer_trusted"));
test("expired certificate (clock manipulation forward is caught offline)", () => bad(({ alice, bob, env }) => [alice.pay(bob.walletId, 100_00), { nowSec: env.clock.get() + 6 * 86400 }], "cert_valid_time"));
test("forged certificate (self-signed by attacker) is rejected", async () => {
  const { alice, bob, ctx, env } = await world();
  const { generateKeyPairSync } = await import("node:crypto");
  const { signCert, buildToken, rawFromPub, keyIdOf } = await import("../src/protocol.ts");
  const evil = generateKeyPairSync("ec", { namedCurve: "prime256v1" });
  const c = { ...cert(alice), spendCeiling: 999_999_00, perTxMax: 999_999_00, issuerKeyId: env.app.keys.currentId };
  const blob = signCert(evil.privateKey, c); // signed by attacker but claims real key id
  const tok = buildToken(alice.priv, blob, { txId: new Uint8Array(16), walletId: alice.walletId, receiverRef: bob.walletId, amount: 900_000_00, counter: 1, cumulativeSpent: 900_000_00, createdAt: env.clock.get(), expiresAt: env.clock.get() + 600, nonce: new Uint8Array(8), currency: "NGN" });
  const r = verifyForReceiver(tok, ctx()); assert.equal(r.checks.at(-1)!.id, "issuer_signature"); void rawFromPub; void keyIdOf;
});
test("garbage bytes fail structure", async () => { const { ctx } = await world(); assert.equal(verifyForReceiver(Uint8Array.from([1, 2, 3]), ctx()).checks[0]!.id, "structure"); });
