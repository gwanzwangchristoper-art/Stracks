import { test } from "node:test";
import assert from "node:assert/strict";
import { Ledger } from "../src/ledger.ts";

test("postings must balance and not overdraw", () => {
  const l = new Ledger();
  assert.throws(() => l.post("a", "x", [{ account: "issuer:settlement", delta: -5 }, { account: "escrow:w", delta: 4 }]), /balance/);
  l.post("b", "load", [{ account: "issuer:settlement", delta: -100 }, { account: "escrow:w", delta: 100 }]);
  assert.throws(() => l.post("c", "over", [{ account: "escrow:w", delta: -101 }, { account: "available:u", delta: 101 }]), /insufficient/);
  assert.equal(l.balance("escrow:w"), 100);
});
test("idempotent by ref and postings are immutable", () => {
  const l = new Ledger();
  const a = l.post("r1", "load", [{ account: "issuer:settlement", delta: -50 }, { account: "escrow:w", delta: 50 }]);
  const b = l.post("r1", "load", [{ account: "issuer:settlement", delta: -50 }, { account: "escrow:w", delta: 50 }]);
  assert.equal(a, b); assert.equal(l.balance("escrow:w"), 50); assert.equal(l.all().length, 1);
  assert.throws(() => { (a as any).memo = "hack"; }); assert.throws(() => { (a.legs as any)[0].delta = 1; });
});
test("property: random valid postings keep total money constant and audit passes", () => {
  const l = new Ledger(); let seed = 42; const rnd = (n: number) => { seed = (seed * 1103515245 + 12345) & 0x7fffffff; return seed % n; };
  l.post("seed", "fund", [{ account: "issuer:settlement", delta: -1_000_000 }, { account: "escrow:w0", delta: 1_000_000 }]);
  const accts = ["escrow:w0", "escrow:w1", "available:u0", "available:u1", "held:w0"];
  for (let i = 0; i < 2000; i++) {
    const a = accts[rnd(5)]!, b = accts[rnd(5)]!; if (a === b) continue;
    const amt = 1 + rnd(5000);
    try { l.post("p" + i, "m", [{ account: a, delta: -amt }, { account: b, delta: amt }]); } catch { /* insufficient, rejected atomically */ }
  }
  const total = accts.reduce((s, a) => s + l.balance(a), 0);
  assert.equal(total, 1_000_000); assert.equal(l.balance("issuer:settlement"), -1_000_000); assert.ok(l.audit());
  for (const a of accts) assert.ok(l.balance(a) >= 0);
});
