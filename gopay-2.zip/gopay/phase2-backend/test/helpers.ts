import { generateKeyPairSync, randomBytes, randomUUID, type KeyObject } from "node:crypto";
import { GoPay } from "../src/app.ts";
import { MockIssuer, MockAttestation, MockKyc } from "../src/issuer.ts";
import { buildToken, parseCertBlob, rawFromPub, type Payload } from "../src/protocol.ts";

export function setup() {
  let t = 1_800_000_000;
  const issuer = new MockIssuer();
  const app = new GoPay({ issuer, attest: new MockAttestation(), kyc: new MockKyc(), now: () => t });
  return { app, issuer, clock: { get: () => t, advance: (s: number) => { t += s; } } };
}
export type Env = ReturnType<typeof setup>;

/** Simulated phone: holds a device key (software here; hardware in the real app), certificate, counter and cumulative. */
export class Phone {
  priv!: KeyObject; pub!: Uint8Array; token = ""; userId = ""; deviceId = ""; walletId = ""; certBlob = new Uint8Array();
  counter = 0; cumulative = 0; loadN = 0;
  env: Env; phone: string;
  constructor(env: Env, phone: string) { this.env = env; this.phone = phone; }
  async onboard(tier = 1, fund = 1_000_000_00) {
    const { app, issuer } = this.env;
    const kp = generateKeyPairSync("ec", { namedCurve: "prime256v1" }); this.priv = kp.privateKey; this.pub = rawFromPub(kp.publicKey);
    app.requestOtp(this.phone); const s = app.verifyOtp(this.phone, "123456"); this.token = s.token; this.userId = s.userId;
    issuer.accounts.set(`ACCT-${this.phone}`, fund);
    const u = app.auth(this.token);
    await app.submitKyc(u, 1, { bvn: "12345678901" });
    if (tier >= 2) await app.submitKyc(u, 2, { idDoc: "x", selfie: "live" });
    if (tier >= 3) await app.submitKyc(u, 3, { address: "x" });
    const r = await app.registerDevice(u, Buffer.from(this.pub).toString("base64"), "android", "mock-ok");
    this.deviceId = r.deviceId; this.walletId = r.walletId; this.certBlob = new Uint8Array(Buffer.from(r.certificate, "base64"));
    return this;
  }
  get user() {
    try { return this.env.app.auth(this.token); }
    catch { this.env.app.requestOtp(this.phone); this.token = this.env.app.verifyOtp(this.phone, "123456").token; return this.env.app.auth(this.token); }
  }
  async load(amount: number) {
    const r = await this.env.app.load(this.user, { deviceId: this.deviceId, loadId: `l${this.phone}-${this.loadN++}`, amount, source: "issuer", attestation: "mock-ok", pinVerified: true });
    this.certBlob = new Uint8Array(Buffer.from(r.certificate, "base64")); return r;
  }
  /** Create a token. Mirrors the real wallet: bump counter + cumulative first, then sign. */
  pay(receiverWalletId: string, amount: number, over: Partial<Payload> = {}, opts: { noAdvance?: boolean } = {}) {
    const now = this.env.clock.get();
    if (!opts.noAdvance) { this.counter++; this.cumulative += amount; }
    const p: Payload = { txId: new Uint8Array(randomBytes(16)), walletId: this.walletId, receiverRef: receiverWalletId, amount,
      counter: this.counter, cumulativeSpent: this.cumulative, createdAt: now, expiresAt: now + 900, nonce: new Uint8Array(randomBytes(8)), currency: "NGN", ...over };
    return buildToken(this.priv, this.certBlob, p);
  }
  async settle(tokens: Uint8Array[]) {
    return this.env.app.settleBatch(this.user, { deviceId: this.deviceId, attestation: "mock-ok", tokens: tokens.map((x) => Buffer.from(x).toString("base64")) });
  }
}
export const cert = (p: Phone) => parseCertBlob(p.certBlob).cert;
