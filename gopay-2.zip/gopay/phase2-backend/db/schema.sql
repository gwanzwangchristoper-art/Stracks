-- Postgres model for gOpay. Money is BIGINT kobo. Ledger tables are append-only (enforced by trigger).
CREATE TABLE users (id uuid PRIMARY KEY, phone text UNIQUE NOT NULL, tier smallint NOT NULL DEFAULT 0, issuer_account_ref text NOT NULL,
  language text NOT NULL DEFAULT 'en', pin_locked boolean NOT NULL DEFAULT false, created_at timestamptz NOT NULL DEFAULT now());
CREATE TABLE devices (id uuid PRIMARY KEY, user_id uuid NOT NULL REFERENCES users, pub_key bytea NOT NULL CHECK (octet_length(pub_key)=65),
  key_id text UNIQUE NOT NULL, platform text NOT NULL CHECK (platform IN ('android','ios')), status text NOT NULL DEFAULT 'active', attestation_ref text);
CREATE TABLE wallets (id uuid PRIMARY KEY, user_id uuid NOT NULL REFERENCES users, device_id uuid NOT NULL REFERENCES devices,
  ceiling bigint NOT NULL DEFAULT 0, settled_total bigint NOT NULL DEFAULT 0, status text NOT NULL DEFAULT 'active' CHECK (status IN ('active','frozen','retired')),
  cert_expires_at timestamptz, frozen_at timestamptz, refunded bigint NOT NULL DEFAULT 0, created_at timestamptz NOT NULL DEFAULT now());
CREATE UNIQUE INDEX one_live_wallet_per_user ON wallets(user_id) WHERE status <> 'retired';

CREATE TABLE ledger_postings (seq bigserial PRIMARY KEY, ref text UNIQUE NOT NULL, memo text NOT NULL, at timestamptz NOT NULL DEFAULT now());
CREATE TABLE ledger_legs (posting_seq bigint NOT NULL REFERENCES ledger_postings, account text NOT NULL, delta bigint NOT NULL CHECK (delta <> 0));
CREATE INDEX ON ledger_legs(account);
-- Deferred constraint: each posting sums to zero. Non-issuer accounts may not go negative (enforce in the posting transaction with SELECT ... FOR UPDATE on account rows).
CREATE FUNCTION ledger_balanced() RETURNS trigger AS $$ BEGIN
  IF (SELECT sum(delta) FROM ledger_legs WHERE posting_seq = NEW.posting_seq) <> 0 THEN RAISE EXCEPTION 'unbalanced posting'; END IF; RETURN NULL; END $$ LANGUAGE plpgsql;
CREATE CONSTRAINT TRIGGER legs_balanced AFTER INSERT ON ledger_legs DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION ledger_balanced();
CREATE FUNCTION no_mutation() RETURNS trigger AS $$ BEGIN RAISE EXCEPTION 'ledger is append-only'; END $$ LANGUAGE plpgsql;
CREATE TRIGGER postings_ro BEFORE UPDATE OR DELETE ON ledger_postings FOR EACH ROW EXECUTE FUNCTION no_mutation();
CREATE TRIGGER legs_ro BEFORE UPDATE OR DELETE ON ledger_legs FOR EACH ROW EXECUTE FUNCTION no_mutation();

CREATE TABLE txs (tx_id text PRIMARY KEY, wallet_id uuid, counter bigint, cumulative bigint, amount bigint, receiver_wallet_id uuid, token_hash text NOT NULL,
  status text NOT NULL, reason text, created_at bigint, settled_at bigint);
CREATE UNIQUE INDEX one_settled_per_wallet_counter ON txs(wallet_id, counter) WHERE status = 'settled';   -- the double-spend guard, enforced by the DB
CREATE TABLE blocklist (seq bigserial PRIMARY KEY, kind text NOT NULL CHECK (kind IN ('wallet','device')), id text NOT NULL, reason text, at timestamptz DEFAULT now(), UNIQUE(kind,id));
CREATE TABLE disputes (id uuid PRIMARY KEY, wallet_id uuid, kind text, detail text, status text DEFAULT 'open', at timestamptz DEFAULT now());
CREATE TABLE loads (id text PRIMARY KEY, user_id uuid, wallet_id uuid, amount bigint, at timestamptz DEFAULT now());
CREATE TABLE audit_log (id bigserial PRIMARY KEY, at timestamptz DEFAULT now(), actor text, action text, detail text);
CREATE TABLE consents (user_id uuid, kind text, version text, at timestamptz DEFAULT now());   -- NDPA consent records (risk notice, privacy policy, KYC)
