// gOpay offline payment protocol v1 (reference implementation).
// Byte layouts are specified in phase1-architecture/PROTOCOL.md. All money is integer kobo.
import { createHash, createPublicKey, sign as nsign, verify as nverify, type KeyObject } from "node:crypto";
import { encode, decode, type Cbor } from "./cbor.ts";

export const VERSION = 1;
const SPKI_P256 = Buffer.from("3059301306072a8648ce3d020106082a8648ce3d030107034200", "hex");
const DS_CERT = Buffer.from("GOPAY1-CERT"), DS_TOKEN = Buffer.from("GOPAY1-TOKEN"), DS_RECEIPT = Buffer.from("GOPAY1-RECEIPT");

export interface Certificate {
  walletId: string; devicePubKey: Uint8Array; attestationRef: string; currency: string;
  spendCeiling: number; perTxMax: number; expiresAt: number; issuerKeyId: string;
  issuedAt: number; maxUnsynced: number;
}
export interface Payload {
  txId: Uint8Array; walletId: string; receiverRef: string; amount: number; counter: number;
  cumulativeSpent: number; createdAt: number; expiresAt: number; nonce: Uint8Array; currency: string;
}
export interface Receipt { txId: Uint8Array; receiverWalletId: string; amount: number; receivedAt: number }

export const hex = (b: Uint8Array) => Buffer.from(b).toString("hex");
export const unhex = (s: string) => new Uint8Array(Buffer.from(s, "hex"));
export const sha256 = (...p: Uint8Array[]) => { const h = createHash("sha256"); p.forEach((x) => h.update(x)); return new Uint8Array(h.digest()); };
const cat = (...p: Uint8Array[]) => new Uint8Array(Buffer.concat(p));

export function pubFromRaw(raw: Uint8Array): KeyObject {
  if (raw.length !== 65 || raw[0] !== 4) throw new Error("bad P-256 public key");
  return createPublicKey({ key: Buffer.concat([SPKI_P256, raw]), format: "der", type: "spki" });
}
export function rawFromPub(k: KeyObject): Uint8Array {
  return new Uint8Array((k.export({ type: "spki", format: "der" }) as Buffer).subarray(-65));
}
export const keyIdOf = (raw: Uint8Array) => hex(sha256(raw)).slice(0, 16);
const sig = (priv: KeyObject, msg: Uint8Array) => new Uint8Array(nsign("sha256", msg, { key: priv, dsaEncoding: "ieee-p1363" }));
const ver = (pub: KeyObject, msg: Uint8Array, s: Uint8Array) => {
  try { return s.length === 64 && nverify("sha256", msg, { key: pub, dsaEncoding: "ieee-p1363" }, s); } catch { return false; }
};

// ---- field helpers
const M = (o: [number, Cbor][]) => new Map<number, Cbor>(o);
function req<T>(m: Map<number, Cbor>, k: number, t: "number" | "string" | "bytes", len?: number): T {
  const v = m.get(k);
  const ok = t === "bytes" ? v instanceof Uint8Array : typeof v === t;
  if (!ok) throw new Error(`field ${k} missing/wrong type`);
  if (len !== undefined && (v as Uint8Array).length !== len) throw new Error(`field ${k} bad length`);
  return v as T;
}
const asMap = (v: Cbor) => { if (!(v instanceof Map)) throw new Error("expected map"); return v; };

// ---- certificate
export function encodeCert(c: Certificate): Uint8Array {
  return encode(M([[1, VERSION], [2, c.walletId], [3, c.devicePubKey], [4, c.attestationRef], [5, c.currency],
    [6, c.spendCeiling], [7, c.perTxMax], [8, c.expiresAt], [9, c.issuerKeyId], [10, c.issuedAt], [11, c.maxUnsynced]]));
}
export function decodeCert(b: Uint8Array): Certificate {
  const m = asMap(decode(b));
  if (req<number>(m, 1, "number") !== VERSION) throw new Error("unsupported cert version");
  return { walletId: req(m, 2, "string"), devicePubKey: req(m, 3, "bytes", 65), attestationRef: req(m, 4, "string"),
    currency: req(m, 5, "string"), spendCeiling: req(m, 6, "number"), perTxMax: req(m, 7, "number"),
    expiresAt: req(m, 8, "number"), issuerKeyId: req(m, 9, "string"), issuedAt: req(m, 10, "number"), maxUnsynced: req(m, 11, "number") };
}
/** certBlob = CBOR [ certBytes, issuerSig ] ; issuerSig = ECDSA(SHA256("GOPAY1-CERT" || certBytes)) */
export function signCert(issuerPriv: KeyObject, c: Certificate): Uint8Array {
  const cb = encodeCert(c);
  return encode([cb, sig(issuerPriv, cat(DS_CERT, cb))]);
}
export function parseCertBlob(blob: Uint8Array): { certBytes: Uint8Array; sig: Uint8Array; cert: Certificate } {
  const a = decode(blob);
  if (!Array.isArray(a) || a.length !== 2 || !(a[0] instanceof Uint8Array) || !(a[1] instanceof Uint8Array)) throw new Error("bad cert blob");
  return { certBytes: a[0], sig: a[1], cert: decodeCert(a[0]) };
}
export function verifyCertSig(parsed: { certBytes: Uint8Array; sig: Uint8Array; cert: Certificate }, trusted: Map<string, KeyObject>) {
  const k = trusted.get(parsed.cert.issuerKeyId);
  if (!k) return { trusted: false, valid: false };
  return { trusted: true, valid: ver(k, cat(DS_CERT, parsed.certBytes), parsed.sig) };
}

// ---- token
export function encodePayload(p: Payload): Uint8Array {
  return encode(M([[1, VERSION], [2, p.txId], [3, p.walletId], [4, p.receiverRef], [5, p.amount], [6, p.counter],
    [7, p.cumulativeSpent], [8, p.createdAt], [9, p.expiresAt], [10, p.nonce], [11, p.currency]]));
}
export function decodePayload(b: Uint8Array): Payload {
  const m = asMap(decode(b));
  if (req<number>(m, 1, "number") !== VERSION) throw new Error("unsupported token version");
  return { txId: req(m, 2, "bytes", 16), walletId: req(m, 3, "string"), receiverRef: req(m, 4, "string"),
    amount: req(m, 5, "number"), counter: req(m, 6, "number"), cumulativeSpent: req(m, 7, "number"),
    createdAt: req(m, 8, "number"), expiresAt: req(m, 9, "number"), nonce: req(m, 10, "bytes", 8), currency: req(m, 11, "string") };
}
/** token = CBOR [ certBlob, payloadBytes, payerSig ] ; payerSig over SHA256("GOPAY1-TOKEN" || certBlob || payloadBytes) */
export function buildToken(payerPriv: KeyObject, certBlob: Uint8Array, p: Payload): Uint8Array {
  const pb = encodePayload(p);
  return encode([certBlob, pb, sig(payerPriv, cat(DS_TOKEN, certBlob, pb))]);
}
export interface ParsedToken { certBlob: Uint8Array; payloadBytes: Uint8Array; sig: Uint8Array; cert: Certificate; certParsed: ReturnType<typeof parseCertBlob>; payload: Payload }
export function parseToken(b: Uint8Array): ParsedToken {
  const a = decode(b);
  if (!Array.isArray(a) || a.length !== 3 || !a.every((x) => x instanceof Uint8Array)) throw new Error("bad token");
  const [certBlob, payloadBytes, s] = a as Uint8Array[];
  const certParsed = parseCertBlob(certBlob!);
  return { certBlob: certBlob!, payloadBytes: payloadBytes!, sig: s!, cert: certParsed.cert, certParsed, payload: decodePayload(payloadBytes!) };
}
export function verifyPayerSig(t: ParsedToken) {
  return ver(pubFromRaw(t.cert.devicePubKey), cat(DS_TOKEN, t.certBlob, t.payloadBytes), t.sig);
}

// ---- receipt (receiver -> payer acknowledgement)
export function encodeReceipt(r: Receipt) { return encode(M([[1, VERSION], [2, r.txId], [3, r.receiverWalletId], [4, r.amount], [5, r.receivedAt]])); }
export function signReceipt(receiverPriv: KeyObject, receiverCertBlob: Uint8Array, r: Receipt): Uint8Array {
  const rb = encodeReceipt(r);
  return encode([rb, sig(receiverPriv, cat(DS_RECEIPT, rb)), receiverCertBlob]);
}
export function verifyReceipt(blob: Uint8Array, trusted: Map<string, KeyObject>, token: ParsedToken) {
  try {
    const a = decode(blob);
    if (!Array.isArray(a) || a.length !== 3) return false;
    const [rb, s, cb] = a as Uint8Array[];
    const cp = parseCertBlob(cb!); const v = verifyCertSig(cp, trusted);
    if (!v.valid) return false;
    if (!ver(pubFromRaw(cp.cert.devicePubKey), cat(DS_RECEIPT, rb!, ), s!)) return false;
    const m = asMap(decode(rb!));
    return hex(req<Uint8Array>(m, 2, "bytes", 16)) === hex(token.payload.txId) && req<string>(m, 3, "string") === token.payload.receiverRef
      && cp.cert.walletId === token.payload.receiverRef && req<number>(m, 4, "number") === token.payload.amount;
  } catch { return false; }
}

// ---- receiver pipeline: all checks must pass, offline, in this order (spec section 6)
export interface ReceiverCtx {
  trustedIssuerKeys: Map<string, KeyObject>; nowSec: number; maxClockSkew: number;
  blockedWallets: Set<string>; blockedDeviceKeyIds: Set<string>;
  myWalletId: string; myCurrency: string; myMaxAccept: number; pendingTotal: number; pendingCap: number;
  seenTxIds: Set<string>; seenWalletCounters: Set<string>;
}
export interface Check { id: string; ok: boolean; detail?: string }
export const CHECK_ORDER = ["structure", "issuer_trusted", "issuer_signature", "cert_valid_time", "not_blocklisted", "payer_signature",
  "bound_to_receiver", "token_valid_time", "within_per_tx_max", "within_ceiling", "not_seen_before", "within_receiver_limits"] as const;

export function verifyForReceiver(bytes: Uint8Array, ctx: ReceiverCtx): { ok: boolean; checks: Check[]; token?: ParsedToken } {
  const checks: Check[] = [];
  const fail = (id: string, detail: string) => { checks.push({ id, ok: false, detail }); return { ok: false, checks }; };
  const pass = (id: string) => checks.push({ id, ok: true });
  let t: ParsedToken;
  try { t = parseToken(bytes); } catch (e) { return fail("structure", (e as Error).message); }
  const { cert, payload: p } = t;
  pass("structure");
  const cv = verifyCertSig(t.certParsed, ctx.trustedIssuerKeys);
  if (!cv.trusted) return fail("issuer_trusted", "unknown issuer key " + cert.issuerKeyId);
  pass("issuer_trusted");
  if (!cv.valid) return fail("issuer_signature", "certificate signature invalid");
  pass("issuer_signature");
  if (cert.walletId !== p.walletId) return fail("cert_valid_time", "wallet mismatch");
  if (ctx.nowSec > cert.expiresAt) return fail("cert_valid_time", "certificate expired");
  if (cert.issuedAt > ctx.nowSec + ctx.maxClockSkew) return fail("cert_valid_time", "certificate from the future");
  pass("cert_valid_time");
  if (ctx.blockedWallets.has(cert.walletId) || ctx.blockedDeviceKeyIds.has(keyIdOf(cert.devicePubKey))) return fail("not_blocklisted", "payer is blocked");
  pass("not_blocklisted");
  if (!verifyPayerSig(t)) return fail("payer_signature", "payer signature invalid");
  pass("payer_signature");
  if (p.receiverRef !== ctx.myWalletId) return fail("bound_to_receiver", "token is for another receiver");
  if (p.currency !== ctx.myCurrency || cert.currency !== p.currency) return fail("bound_to_receiver", "currency mismatch");
  pass("bound_to_receiver");
  if (ctx.nowSec > p.expiresAt) return fail("token_valid_time", "token expired");
  if (p.createdAt > ctx.nowSec + ctx.maxClockSkew) return fail("token_valid_time", "token from the future");
  if (p.createdAt > p.expiresAt || p.expiresAt > cert.expiresAt + ctx.maxClockSkew) return fail("token_valid_time", "bad token window");
  pass("token_valid_time");
  if (p.amount <= 0 || p.amount > cert.perTxMax) return fail("within_per_tx_max", "amount over payer limit");
  pass("within_per_tx_max");
  if (p.counter < 1 || p.cumulativeSpent < p.amount || p.cumulativeSpent > cert.spendCeiling) return fail("within_ceiling", "payer ceiling exceeded");
  pass("within_ceiling");
  if (ctx.seenTxIds.has(hex(p.txId)) || ctx.seenWalletCounters.has(`${p.walletId}:${p.counter}`)) return fail("not_seen_before", "already received");
  pass("not_seen_before");
  if (p.amount > ctx.myMaxAccept) return fail("within_receiver_limits", "over your max single payment");
  if (ctx.pendingTotal + p.amount > ctx.pendingCap) return fail("within_receiver_limits", "pending cap reached");
  pass("within_receiver_limits");
  return { ok: true, checks, token: t };
}
