// Reference implementation of the gOpay offline protocol (v1).
// Encoding: canonical JSON (sorted keys) for the MVP; swap to CBOR+base45 before pilot (see docs).
import { createSign, createVerify, generateKeyPairSync, createPublicKey } from 'node:crypto';

export const canon = (o) => JSON.stringify(sortKeys(o));
const sortKeys = (v) => Array.isArray(v) ? v.map(sortKeys)
  : v && typeof v === 'object' ? Object.fromEntries(Object.keys(v).sort().map(k => [k, sortKeys(v[k])])) : v;

export const newKeyPair = () => {
  const { publicKey, privateKey } = generateKeyPairSync('ec', { namedCurve: 'P-256' });
  return { publicKey, privateKey, publicPem: publicKey.export({ type: 'spki', format: 'pem' }) };
};
export const sign = (priv, data) =>
  createSign('SHA256').update(data).sign({ key: priv, dsaEncoding: 'ieee-p1363' }).toString('base64');
export const verify = (pubPem, data, sig) => {
  try {
    return createVerify('SHA256').update(data).verify(
      { key: createPublicKey(pubPem), dsaEncoding: 'ieee-p1363' }, Buffer.from(sig, 'base64'));
  } catch { return false; }
};

// Issuer signs the wallet certificate.
export function issueCertificate(issuer, c) {
  const body = { ...c, issuerKeyId: issuer.keyId };
  return { body, sig: sign(issuer.privateKey, canon(body)) };
}

// Payer builds a token offline. `state` is the sealed record {counter, cumulativeSpent}.
export function createToken({ cert, devicePriv, state, receiverRef, amount, now, ttlMs = 600000, txId, nonce }) {
  const counter = state.counter + 1;
  const payload = {
    version: 1, txId, walletId: cert.body.walletId, receiverRef, amount, counter,
    cumulativeSpent: state.cumulativeSpent + amount, createdAt: now, expiresAt: now + ttlMs, nonce,
  };
  const sig = sign(devicePriv, canon({ cert, payload }));
  return { cert, payload, sig };
}

// Receiver-side verification. Returns {ok, checks[]} - every check is shown to the user.
export function verifyToken(token, ctx) {
  const { cert, payload: p } = token;
  const checks = [];
  const add = (name, ok) => { checks.push({ name, ok }); return ok; };
  const trustedKey = ctx.trustedIssuerKeys[cert.body.issuerKeyId];
  add('issuer_signature', !!trustedKey && verify(trustedKey, canon(cert.body), cert.sig));
  add('cert_valid', ctx.now < cert.body.expiresAt && !ctx.blocklist.has(cert.body.walletId));
  add('payer_signature', verify(cert.body.devicePubKey, canon({ cert, payload: p }), token.sig));
  add('bound_to_me', p.receiverRef === ctx.myRef && ctx.now < p.expiresAt && p.amount > 0 && p.amount <= cert.body.perTxMax);
  add('within_ceiling', p.cumulativeSpent <= cert.body.spendCeiling && p.walletId === cert.body.walletId);
  add('not_seen', !ctx.seen.txIds.has(p.txId) && !ctx.seen.counters.has(`${p.walletId}:${p.counter}`));
  add('my_limits', p.amount <= ctx.maxAccept && ctx.pendingTotal + p.amount <= ctx.pendingCap);
  return { ok: checks.every(c => c.ok), checks };
}
