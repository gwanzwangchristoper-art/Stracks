// Provider-agnostic issuer adapter. A licensed bank/PSP implements this interface.
export interface IssuerResult { ref: string }
export interface IssuerProvider {
  debit(accountRef: string, amount: number, idemKey: string): Promise<IssuerResult>;
  credit(accountRef: string, amount: number, idemKey: string): Promise<IssuerResult>;
  refund(accountRef: string, amount: number, idemKey: string): Promise<IssuerResult>;
  balance(accountRef: string): Promise<number>;
}
export class IssuerError extends Error { code: "insufficient_funds" | "unavailable" | "unknown_account"; constructor(code: "insufficient_funds" | "unavailable" | "unknown_account", m: string) { super(m); this.code = code; } }

/** DEV/TEST ONLY. Never ship. */
export class MockIssuer implements IssuerProvider {
  accounts = new Map<string, number>();
  private done = new Map<string, IssuerResult>();
  down = false;
  fund(accountRef: string, amount: number) { this.accounts.set(accountRef, (this.accounts.get(accountRef) ?? 0) + amount); }
  private async op(kind: string, a: string, amt: number, key: string, sign: 1 | -1) {
    if (this.down) throw new IssuerError("unavailable", "issuer down");
    const k = `${kind}:${key}`; const prior = this.done.get(k); if (prior) return prior;
    if (!this.accounts.has(a)) throw new IssuerError("unknown_account", a);
    const nb = this.accounts.get(a)! + sign * amt;
    if (nb < 0) throw new IssuerError("insufficient_funds", "insufficient funds");
    this.accounts.set(a, nb);
    const r = { ref: `MOCK-${kind}-${this.done.size + 1}` }; this.done.set(k, r); return r;
  }
  debit(a: string, amt: number, k: string) { return this.op("debit", a, amt, k, -1); }
  credit(a: string, amt: number, k: string) { return this.op("credit", a, amt, k, 1); }
  refund(a: string, amt: number, k: string) { return this.op("refund", a, amt, k, 1); }
  async balance(a: string) { return this.accounts.get(a) ?? 0; }
}

export interface AttestationVerifier { verify(token: string, nonce: string, platform: "android" | "ios"): Promise<{ ok: boolean; ref: string; reason?: string }> }
/** DEV ONLY: accepts "mock-ok". Production: Play Integrity (server decode) and Apple App Attest (assertion check). */
export class MockAttestation implements AttestationVerifier {
  async verify(token: string) { return token === "mock-ok" ? { ok: true, ref: "mock-att" } : { ok: false, ref: "", reason: "attestation failed" }; }
}
export interface KycProvider { verify(tier: number, data: Record<string, string>): Promise<{ ok: boolean; reason?: string }> }
/** DEV ONLY. Production: NIBSS BVN / NIMC NIN, liveness vendor, address vendor. */
export class MockKyc implements KycProvider {
  async verify(tier: number, d: Record<string, string>) {
    if (tier === 1) return /^\d{11}$/.test(d.bvn ?? d.nin ?? "") ? { ok: true } : { ok: false, reason: "BVN or NIN must be 11 digits" };
    if (tier === 2) return d.idDoc && d.selfie === "live" ? { ok: true } : { ok: false, reason: "ID and selfie needed" };
    return d.address ? { ok: true } : { ok: false, reason: "address needed" };
  }
}
