import { Ledger } from './ledger.js';
import { TIERS, CERT_LIFETIME_MS } from './tiers.js';
import { issueCertificate, verify, canon } from './protocol.js';

export class GoPayServer {
  constructor({ issuer, issuerKeys }) {
    this.issuer = issuer; this.keys = issuerKeys; this.ledger = new Ledger();
    this.wallets = new Map(); this.seenTx = new Set(); this.seenCounter = new Set();
    this.blocklist = new Set(); this.settled = new Map(); // txId -> result
  }
  async load({ userId, walletId, devicePubKey, tier, amount, now = Date.now() }) {
    const t = TIERS[tier]; if (!t) throw new Error('bad_tier');
    const w = this.wallets.get(walletId) ?? { userId, devicePubKey, tier, escrow: 0 };
    if (this.blocklist.has(walletId)) throw new Error('wallet_frozen');
    if (w.escrow + amount > t.offlineCap) throw new Error('over_offline_cap');
    await this.issuer.debit(userId, amount);
    this.ledger.post(`load:${walletId}:${this.ledger.entries.length}`, [
      { account: `user:${userId}`, amount: -amount }, { account: `escrow:${walletId}`, amount }]);
    w.escrow += amount; this.wallets.set(walletId, w);
    const cert = issueCertificate(this.keys, { walletId, devicePubKey, deviceAttestationRef: 'mock', currency: 'NGN',
      spendCeiling: w.escrow, perTxMax: t.perTxMax, expiresAt: now + CERT_LIFETIME_MS });
    return cert;
  }
  // Idempotent batch settlement from a receiver.
  settle(receiverUserId, tokens, now = Date.now()) {
    return tokens.map(tok => {
      const p = tok.payload, w = this.wallets.get(p.walletId);
      if (this.settled.has(p.txId)) return this.settled.get(p.txId); // replay of same upload
      const reject = (reason) => { const r = { txId: p.txId, status: 'rejected', reason }; this.settled.set(p.txId, r); return r; };
      if (!w) return reject('unknown_wallet');
      if (!verify(this.keys.publicPem, canon(tok.cert.body), tok.cert.sig)) return reject('bad_certificate');
      if (!verify(w.devicePubKey, canon({ cert: tok.cert, payload: p }), tok.sig)) return reject('bad_signature');
      const ck = `${p.walletId}:${p.counter}`;
      if (this.seenCounter.has(ck) || this.seenTx.has(p.txId)) { this.#freeze(p.walletId); return reject('double_spend'); }
      if (this.blocklist.has(p.walletId)) return reject('wallet_frozen');
      if (this.ledger.balance(`escrow:${p.walletId}`) < p.amount) return reject('escrow_exhausted');
      this.seenCounter.add(ck); this.seenTx.add(p.txId);
      this.ledger.post(`settle:${p.txId}`, [
        { account: `escrow:${p.walletId}`, amount: -p.amount }, { account: `user:${receiverUserId}`, amount: p.amount }]);
      const r = { txId: p.txId, status: 'settled' }; this.settled.set(p.txId, r); return r;
    });
  }
  #freeze(walletId) { this.blocklist.add(walletId); } // remaining escrow held for disputes
  // Expired unspent balance refunds to linked account.
  async refundExpired(walletId) {
    const w = this.wallets.get(walletId); if (!w || this.blocklist.has(walletId)) return 0;
    const left = this.ledger.balance(`escrow:${walletId}`); if (left <= 0) return 0;
    this.ledger.post(`refund:${walletId}:${this.ledger.entries.length}`, [
      { account: `escrow:${walletId}`, amount: -left }, { account: `user:${w.userId}`, amount: left }]);
    await this.issuer.refund(w.userId, left); return left;
  }
}
