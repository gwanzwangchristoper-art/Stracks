// Server-side configurable. CONFIRM against current CBN rules and issuer policy (legal review).
export const TIERS = {
  1: { perTxMax: 5000, offlineCap: 20000, pendingCap: 20000 },
  2: { perTxMax: 20000, offlineCap: 100000, pendingCap: 100000 },
  3: { perTxMax: 50000, offlineCap: 300000, pendingCap: 300000 },
};
export const CERT_LIFETIME_MS = 5 * 24 * 3600 * 1000;
