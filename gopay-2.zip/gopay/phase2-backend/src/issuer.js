// Provider-agnostic issuer adapter + mock. Swap MockIssuer for a licensed bank/PSP implementation.
export class IssuerProvider { async debit(){throw 0} async credit(){throw 0} async refund(){throw 0} async balance(){throw 0} }
export class MockIssuer extends IssuerProvider {
  constructor() { super(); this.acc = new Map(); }
  fund(user, n) { this.acc.set(user, (this.acc.get(user) ?? 0) + n); }
  async balance(user) { return this.acc.get(user) ?? 0; }
  async debit(user, n) { if ((await this.balance(user)) < n) throw new Error('insufficient_funds'); this.acc.set(user, this.acc.get(user) - n); }
  async credit(user, n) { this.fund(user, n); }
  async refund(user, n) { this.fund(user, n); }
}
