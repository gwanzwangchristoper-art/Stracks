// Minimal canonical CBOR (RFC 8949 subset): uint, bstr, tstr, array, map with uint keys.
// Canonical = shortest-form heads, map keys ascending. The decoder REJECTS anything else,
// so every logical object has exactly one byte encoding (no malleability).
export type Cbor = number | string | Uint8Array | Cbor[] | Map<number, Cbor>;

const te = new TextEncoder();
const td = new TextDecoder("utf-8", { fatal: true });

function head(major: number, n: number): number[] {
  if (!Number.isSafeInteger(n) || n < 0) throw new Error("cbor: bad uint");
  const m = major << 5;
  if (n < 24) return [m | n];
  if (n < 0x100) return [m | 24, n];
  if (n < 0x10000) return [m | 25, n >> 8, n & 255];
  if (n < 0x100000000) return [m | 26, (n >>> 24) & 255, (n >>> 16) & 255, (n >>> 8) & 255, n & 255];
  const hi = Math.floor(n / 0x100000000), lo = n >>> 0;
  return [m | 27, (hi >>> 24) & 255, (hi >>> 16) & 255, (hi >>> 8) & 255, hi & 255,
    (lo >>> 24) & 255, (lo >>> 16) & 255, (lo >>> 8) & 255, lo & 255];
}

function enc(v: Cbor, out: number[]): void {
  if (typeof v === "number") out.push(...head(0, v));
  else if (typeof v === "string") { const b = te.encode(v); out.push(...head(3, b.length)); for (const x of b) out.push(x); }
  else if (v instanceof Uint8Array) { out.push(...head(2, v.length)); for (const x of v) out.push(x); }
  else if (Array.isArray(v)) { out.push(...head(4, v.length)); for (const x of v) enc(x, out); }
  else if (v instanceof Map) {
    out.push(...head(5, v.size));
    for (const k of [...v.keys()].sort((a, b) => a - b)) { out.push(...head(0, k)); enc(v.get(k)!, out); }
  } else throw new Error("cbor: unsupported type");
}

export function encode(v: Cbor): Uint8Array { const o: number[] = []; enc(v, o); return Uint8Array.from(o); }

export function decode(buf: Uint8Array): Cbor {
  let p = 0;
  const need = (n: number) => { if (p + n > buf.length) throw new Error("cbor: truncated"); };
  function readHead(): [number, number] {
    need(1);
    const b = buf[p++]!; const major = b >> 5, ai = b & 31;
    if (ai < 24) return [major, ai];
    const len = ai === 24 ? 1 : ai === 25 ? 2 : ai === 26 ? 4 : ai === 27 ? 8 : -1;
    if (len < 0) throw new Error("cbor: indefinite/reserved not allowed");
    need(len);
    let n = 0;
    for (let i = 0; i < len; i++) n = n * 256 + buf[p++]!;
    if (!Number.isSafeInteger(n)) throw new Error("cbor: uint too large");
    const min = len === 1 ? 24 : len === 2 ? 0x100 : len === 4 ? 0x10000 : 0x100000000;
    if (n < min) throw new Error("cbor: non-canonical integer");
    return [major, n];
  }
  function item(depth: number): Cbor {
    if (depth > 8) throw new Error("cbor: too deep");
    const [major, n] = readHead();
    switch (major) {
      case 0: return n;
      case 2: { need(n); const r = buf.slice(p, p + n); p += n; return r; }
      case 3: { need(n); const r = td.decode(buf.subarray(p, p + n)); p += n; return r; }
      case 4: { if (n > 64) throw new Error("cbor: array too long"); const a: Cbor[] = []; for (let i = 0; i < n; i++) a.push(item(depth + 1)); return a; }
      case 5: {
        if (n > 64) throw new Error("cbor: map too large");
        const m = new Map<number, Cbor>(); let last = -1;
        for (let i = 0; i < n; i++) {
          const k = item(depth + 1);
          if (typeof k !== "number") throw new Error("cbor: map key must be uint");
          if (k <= last) throw new Error("cbor: map keys not ascending/unique");
          last = k; m.set(k, item(depth + 1));
        }
        return m;
      }
      default: throw new Error("cbor: unsupported major type");
    }
  }
  const v = item(0);
  if (p !== buf.length) throw new Error("cbor: trailing bytes");
  return v;
}
