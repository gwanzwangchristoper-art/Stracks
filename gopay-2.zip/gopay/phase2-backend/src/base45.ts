// RFC 9285 Base45, used so binary tokens fit QR alphanumeric mode.
const A = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ $%*+-./:";
export function b45encode(b: Uint8Array): string {
  let s = "";
  for (let i = 0; i < b.length; i += 2) {
    if (i + 1 < b.length) { const n = b[i]! * 256 + b[i + 1]!; s += A[n % 45]! + A[Math.floor(n / 45) % 45]! + A[Math.floor(n / 2025)]!; }
    else { const n = b[i]!; s += A[n % 45]! + A[Math.floor(n / 45)]!; }
  }
  return s;
}
export function b45decode(s: string): Uint8Array {
  const v = [...s].map((c) => { const i = A.indexOf(c); if (i < 0) throw new Error("base45: bad char"); return i; });
  const out: number[] = [];
  for (let i = 0; i < v.length; i += 3) {
    if (i + 2 < v.length) { const n = v[i]! + v[i + 1]! * 45 + v[i + 2]! * 2025; if (n > 65535) throw new Error("base45: overflow"); out.push(n >> 8, n & 255); }
    else if (i + 1 < v.length) { const n = v[i]! + v[i + 1]! * 45; if (n > 255) throw new Error("base45: overflow"); out.push(n); }
    else throw new Error("base45: bad length");
  }
  return Uint8Array.from(out);
}
