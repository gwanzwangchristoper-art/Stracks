// In-memory repositories. db/schema.sql is the Postgres model these map to; swap in a pg-backed Store for production.
export interface User { id: string; phone: string; tier: number; issuerAccountRef: string; createdAt: number; pinLocked: boolean; language: string }
export interface Device { id: string; userId: string; pubKey: Uint8Array; keyId: string; platform: "android" | "ios"; status: "active" | "blocked"; attestationRef: string }
export interface Wallet { id: string; userId: string; deviceId: string; ceiling: number; settledTotal: number; status: "active" | "frozen" | "retired" | "closed"; createdAt: number; certExpiresAt: number; frozenAt?: number; refunded: number }
export interface Tx { txId: string; walletId: string; counter: number; cumulative: number; amount: number; receiverWalletId: string; tokenHash: string; status: "settled" | "rejected"; reason?: string; createdAt: number; settledAt: number }
export interface BlockEntry { seq: number; kind: "wallet" | "device"; id: string; reason: string; at: number }
export interface Dispute { id: string; walletId: string; kind: string; detail: string; status: "open" | "resolved"; at: number }
export interface AuditEntry { at: number; actor: string; action: string; detail: string }
export interface LoadRec { id: string; userId: string; walletId: string; amount: number; at: number }
export interface Notice { userId: string; kind: string; text: string; at: number }

export class Store {
  users = new Map<string, User>(); usersByPhone = new Map<string, string>();
  devices = new Map<string, Device>(); wallets = new Map<string, Wallet>();
  txs = new Map<string, Tx>(); txByWalletCounter = new Map<string, string>();
  blocklist: BlockEntry[] = []; disputes: Dispute[] = []; audit: AuditEntry[] = [];
  loads = new Map<string, LoadRec>(); notices: Notice[] = [];
  otps = new Map<string, { code: string; exp: number; tries: number }>();
  walletsOf(userId: string) { return [...this.wallets.values()].filter((w) => w.userId === userId); }
  activeWallet(userId: string) { return this.walletsOf(userId).find((w) => w.status === "active" || w.status === "frozen"); }
  txsOfWallet(walletId: string) { return [...this.txs.values()].filter((t) => t.walletId === walletId && t.status === "settled"); }
}
