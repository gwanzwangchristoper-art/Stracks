// All limits are server-side configuration (kobo). CONFIRM EVERY FIGURE against current CBN rules and the issuer policy.
export interface Tier { perPayment: number; offlineCap: number; pendingCap: number; dailyLoad: number }
export const NAIRA = 100;
export const config = {
  currency: "NGN",
  tiers: {
    1: { perPayment: 5_000 * NAIRA, offlineCap: 20_000 * NAIRA, pendingCap: 20_000 * NAIRA, dailyLoad: 20_000 * NAIRA },
    2: { perPayment: 20_000 * NAIRA, offlineCap: 100_000 * NAIRA, pendingCap: 100_000 * NAIRA, dailyLoad: 100_000 * NAIRA },
    3: { perPayment: 50_000 * NAIRA, offlineCap: 300_000 * NAIRA, pendingCap: 300_000 * NAIRA, dailyLoad: 300_000 * NAIRA },
  } as Record<number, Tier>,
  certLifetimeSec: 5 * 86400,        // 3 to 7 days
  settlementGraceSec: 7 * 86400,     // tokens can settle until cert expiry + grace
  maxClockSkewSec: 300,
  tokenWindowSec: 15 * 60,           // receiver acceptance window
  maxUnsynced: 30,                   // max offline payments between syncs
  coolingPeriodSec: 72 * 3600,       // new-wallet cooling
  coolingFactor: 0.25,               // cap multiplier while cooling
  coolingPerTxFactor: 0.5,
  otpDevCode: "123456",              // DEV ONLY; real SMS provider in production
  sessionSecret: process.env.GOPAY_SESSION_SECRET ?? "dev-only-change-me",
  adminKey: process.env.GOPAY_ADMIN_KEY ?? "dev-admin-key",
};
