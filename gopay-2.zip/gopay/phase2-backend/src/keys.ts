import { generateKeyPairSync, type KeyObject } from "node:crypto";
import { keyIdOf, rawFromPub } from "./protocol.ts";
/** Issuer signing keys. Software keys for dev. PRODUCTION: keep private keys in cloud KMS/HSM and replace `priv` use with a remote sign call. */
export class IssuerKeys {
  private all = new Map<string, { pub: KeyObject; priv: KeyObject }>();
  currentId = "";
  constructor() { this.rotate(); }
  rotate(): string {
    const { publicKey, privateKey } = generateKeyPairSync("ec", { namedCurve: "prime256v1" });
    const id = keyIdOf(rawFromPub(publicKey));
    this.all.set(id, { pub: publicKey, priv: privateKey }); this.currentId = id; return id;
  }
  current() { return { id: this.currentId, priv: this.all.get(this.currentId)!.priv }; }
  trusted(): Map<string, KeyObject> { return new Map([...this.all].map(([k, v]) => [k, v.pub])); }
  publicList() { return [...this.all].map(([id, v]) => ({ keyId: id, pubKey: Buffer.from(rawFromPub(v.pub)).toString("base64"), current: id === this.currentId })); }
}
