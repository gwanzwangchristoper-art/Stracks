import { randomUUID, createHmac, timingSafeEqual, createHash } from "node:crypto";
import { config } from "./config.ts";
import { Ledger } from "./ledger.ts";
import { Store, type Wallet, type Device, type User } from "./store.ts";
import { IssuerError, type IssuerProvider, type AttestationVerifier, type KycProvider } from "./issuer.ts";
import { IssuerKeys } from "./keys.ts";
import { signCert, parseToken, verifyCertSig, verifyPayerSig, keyIdOf, hex, type Certificate } from "./protocol.ts";

export class ApiError extends Error { status: number; code: string; constructor(status: number, code: string, m: string) { super(m); this.status = status; this.code = code; } }
const b64 = (b: Uint8Array) => Buffer.from(b).toString("base64");
const unb64 = (s: string) => new Uint8Array(Buffer.from(s, "base64"));
const h = (b: Uint8Array) => createHash("sha256").update(b).digest("hex");

export interface Deps { issuer: IssuerProvider; attest: AttestationVerifier; kyc: KycProvider; now?: () => number }
export type SettleResult = { txId: string; status: "settled" | "duplicate" | "rejected"; reason?: string };

export class GoPay {
  store = new Store(); keys = new IssuerKeys();
  ledger: Ledger; now: () => number; d: Deps;
  constructor(d: Deps) { this.d = d; this.now = d.now ?? (() => Math.floor(Date.now() / 1000)); this.ledger = new Ledger(this.now); }

  // ---------- auth (OTP + signed session tokens) ----------
  requestOtp(phone: string) {
    if (!/^\+234\d{10}$|^\+\d{8,15}$/.test(phone)) throw new ApiError(400, "bad_phone", "Enter a valid phone number.");
    const prev = this.store.otps.get(phone);
    if (prev && prev.exp > this.now() && prev.tries >= 5) throw new ApiError(429, "otp_rate", "Too many tries. Wait 10 minutes.");
    this.store.otps.set(phone, { code: config.otpDevCode, exp: this.now() + 600, tries: prev?.tries ?? 0 });
    return { sent: true }; // production: send via SMS provider, never return the code
  }
  verifyOtp(phone: string, code: string) {
    const o = this.store.otps.get(phone);
    if (!o || o.exp < this.now()) throw new ApiError(400, "otp_expired", "Code expired. Ask for a new one.");
    o.tries++;
    if (o.tries > 5) throw new ApiError(429, "otp_rate", "Too many tries. Wait 10 minutes.");
    if (code !== o.code) throw new ApiError(400, "otp_wrong", "Wrong code. Check and try again.");
    this.store.otps.delete(phone);
    let uid = this.store.usersByPhone.get(phone);
    if (!uid) {
      uid = randomUUID();
      const u: User = { id: uid, phone, tier: 0, issuerAccountRef: `ACCT-${phone}`, createdAt: this.now(), pinLocked: false, language: "en" };
      this.store.users.set(uid, u); this.store.usersByPhone.set(phone, uid);
    }
    return { token: this.mintSession(uid), userId: uid };
  }
  private mintSession(uid: string) {
    const body = Buffer.from(JSON.stringify({ uid, exp: this.now() + 86400 })).toString("base64url");
    return `${body}.${createHmac("sha256", config.sessionSecret).update(body).digest("base64url")}`;
  }
  auth(token: string | undefined): User {
    if (!token) throw new ApiError(401, "no_session", "Sign in again.");
    const [body, mac] = token.split(".");
    const exp = createHmac("sha256", config.sessionSecret).update(body ?? "").digest("base64url");
    if (!mac || mac.length !== exp.length || !timingSafeEqual(Buffer.from(mac), Buffer.from(exp))) throw new ApiError(401, "bad_session", "Sign in again.");
    const s = JSON.parse(Buffer.from(body!, "base64url").toString());
    if (s.exp < this.now()) throw new ApiError(401, "session_expired", "Sign in again.");
    const u = this.store.users.get(s.uid); if (!u) throw new ApiError(401, "bad_session", "Sign in again.");
    return u;
  }
  reportPinLockout(u: User) { u.pinLocked = true; this.audit("user:" + u.id, "pin_lockout", ""); return { locked: true }; }
  /** Server-side unlock: needs a fresh OTP verification (caller must have just passed verifyOtp). */
  unlockPin(u: User) { u.pinLocked = false; this.audit("user:" + u.id, "pin_unlock", ""); return { locked: false }; }

  // ---------- KYC ----------
  async submitKyc(u: User, tier: number, data: Record<string, string>) {
    if (![1, 2, 3].includes(tier) || tier > u.tier + 1) throw new ApiError(400, "bad_tier", "Finish the previous level first.");
    const r = await this.d.kyc.verify(tier, data);
    if (!r.ok) throw new ApiError(422, "kyc_failed", r.reason ?? "Could not verify. Check details.");
    u.tier = Math.max(u.tier, tier); this.audit("user:" + u.id, "kyc_tier", String(tier));
    return { tier: u.tier, limits: config.tiers[u.tier] };
  }

  // ---------- device + wallet ----------
  async registerDevice(u: User, pubKeyB64: string, platform: "android" | "ios", attestation: string) {
    if (u.tier < 1) throw new ApiError(403, "kyc_required", "Finish ID check first.");
    const pub = unb64(pubKeyB64);
    if (pub.length !== 65 || pub[0] !== 4) throw new ApiError(400, "bad_key", "Bad device key.");
    const at = await this.d.attest.verify(attestation, "register", platform);
    if (!at.ok) throw new ApiError(403, "attestation_failed", "This phone is not allowed. Use a normal, up-to-date phone.");
    const keyId = keyIdOf(pub);
    if (this.store.blocklist.some((b) => b.kind === "device" && b.id === keyId)) throw new ApiError(403, "blocked", "This phone is blocked. Contact support.");
    let dev = [...this.store.devices.values()].find((x) => x.userId === u.id && x.keyId === keyId);
    if (!dev) {
      // new phone: retire old wallets' devices (never copy keys). Old wallet funds are refunded by expiry job.
      for (const d of this.store.devices.values()) if (d.userId === u.id) d.status = "blocked";
      dev = { id: randomUUID(), userId: u.id, pubKey: pub, keyId, platform, status: "active", attestationRef: at.ref };
      this.store.devices.set(dev.id, dev);
    }
    const wallet = this.ensureWallet(u, dev);
    return { deviceId: dev.id, walletId: wallet.id, certificate: b64(this.issueCert(u, wallet, dev)), issuerKeys: this.keys.publicList() };
  }
  private ensureWallet(u: User, dev: Device): Wallet {
    const cur = this.store.activeWallet(u.id);
    if (cur && cur.deviceId === dev.id) return cur;
    if (cur) cur.status = cur.status === "frozen" ? "frozen" : "retired"; // keep frozen ones frozen; escrow held
    const w: Wallet = { id: randomUUID(), userId: u.id, deviceId: dev.id, ceiling: 0, settledTotal: 0, status: "active", createdAt: this.now(), certExpiresAt: 0, refunded: 0 };
    this.store.wallets.set(w.id, w); return w;
  }
  private cooling(w: Wallet) { return this.now() - w.createdAt < config.coolingPeriodSec; }
  limitsFor(u: User, w: Wallet) {
    const t = config.tiers[u.tier]; if (!t) throw new ApiError(403, "kyc_required", "Finish ID check first.");
    const c = this.cooling(w);
    return { perTxMax: Math.floor(t.perPayment * (c ? config.coolingPerTxFactor : 1)), offlineCap: Math.floor(t.offlineCap * (c ? config.coolingFactor : 1)), pendingCap: t.pendingCap, dailyLoad: t.dailyLoad };
  }
  private issueCert(u: User, w: Wallet, dev: Device): Uint8Array {
    const now = this.now(); const lim = this.limitsFor(u, w);
    const c: Certificate = { walletId: w.id, devicePubKey: dev.pubKey, attestationRef: dev.attestationRef, currency: config.currency,
      spendCeiling: w.ceiling, perTxMax: lim.perTxMax, expiresAt: now + config.certLifetimeSec, issuerKeyId: this.keys.current().id, issuedAt: now, maxUnsynced: config.maxUnsynced };
    w.certExpiresAt = c.expiresAt;
    return signCert(this.keys.current().priv, c);
  }
  private async gate(u: User, deviceId: string, attestation: string, step: string) {
    const dev = this.store.devices.get(deviceId);
    if (!dev || dev.userId !== u.id || dev.status !== "active") throw new ApiError(403, "device_not_allowed", "This phone is not registered. Sign in again.");
    if (this.store.blocklist.some((b) => b.kind === "device" && b.id === dev.keyId)) throw new ApiError(403, "blocked", "This phone is blocked. Contact support.");
    const at = await this.d.attest.verify(attestation, step, dev.platform);
    if (!at.ok) throw new ApiError(403, "attestation_failed", "This phone is not allowed. Use a normal, up-to-date phone.");
    return dev;
  }

  // ---------- load (internet required) ----------
  async load(u: User, a: { deviceId: string; loadId: string; amount: number; source: "issuer" | "available"; attestation: string; pinVerified: boolean }) {
    if (u.pinLocked) throw new ApiError(423, "pin_locked", "PIN locked. Unlock with a code.");
    const dev = await this.gate(u, a.deviceId, a.attestation, "load");
    const w = this.store.activeWallet(u.id);
    if (!w || w.deviceId !== dev.id || w.status !== "active") throw new ApiError(403, "wallet_unavailable", "Wallet not available. Contact support.");
    if (!Number.isSafeInteger(a.amount) || a.amount <= 0) throw new ApiError(400, "bad_amount", "Enter an amount.");
    const prior = this.store.loads.get(a.loadId);
    if (prior) return this.loadResponse(u, w, dev); // idempotent retry
    const lim = this.limitsFor(u, w);
    const offlineNow = this.ledger.balance("escrow:" + w.id);
    if (offlineNow + a.amount > lim.offlineCap) throw new ApiError(422, "over_cap", `Offline wallet limit is ₦${lim.offlineCap / 100}.`);
    const dayStart = this.now() - 86400;
    const today = [...this.store.loads.values()].filter((l) => l.userId === u.id && l.at > dayStart).reduce((s, l) => s + l.amount, 0);
    if (today + a.amount > lim.dailyLoad) throw new ApiError(422, "daily_limit", "Daily load limit reached. Try tomorrow.");
    const idem = "load:" + a.loadId;
    if (a.source === "issuer") {
      let ref;
      try { ref = await this.d.issuer.debit(u.issuerAccountRef, a.amount, idem); }
      catch (e) { throw this.issuerErr(e); }
      try { this.ledger.post(idem, "load " + ref.ref, [{ account: "issuer:settlement", delta: -a.amount }, { account: "escrow:" + w.id, delta: a.amount }]); }
      catch (e) { await this.d.issuer.refund(u.issuerAccountRef, a.amount, idem + ":undo"); throw e; }
    } else {
      try { this.ledger.post(idem, "load from available", [{ account: "available:" + u.id, delta: -a.amount }, { account: "escrow:" + w.id, delta: a.amount }]); }
      catch { throw new ApiError(422, "insufficient_available", "Not enough available balance."); }
    }
    w.ceiling += a.amount;
    this.store.loads.set(a.loadId, { id: a.loadId, userId: u.id, walletId: w.id, amount: a.amount, at: this.now() });
    return this.loadResponse(u, w, dev);
  }
  private loadResponse(u: User, w: Wallet, dev: Device) {
    return { walletId: w.id, offlineBalance: this.ledger.balance("escrow:" + w.id), certificate: b64(this.issueCert(u, w, dev)) };
  }
  private issuerErr(e: unknown) {
    if (e instanceof IssuerError) return e.code === "insufficient_funds" ? new ApiError(422, "insufficient_funds", "Not enough money in your account.") : new ApiError(503, "issuer_unavailable", "Bank not reachable. Try again soon.");
    return e as Error;
  }

  async refreshCertificate(u: User, deviceId: string, attestation: string) {
    const dev = await this.gate(u, deviceId, attestation, "refresh");
    const w = this.store.activeWallet(u.id);
    if (!w || w.deviceId !== dev.id) throw new ApiError(403, "wallet_unavailable", "Wallet not available. Contact support.");
    if (w.status === "frozen") throw new ApiError(403, "wallet_frozen", "Wallet is frozen. Contact support.");
    return { certificate: b64(this.issueCert(u, w, dev)), issuerKeys: this.keys.publicList() };
  }

  /** Recovery after the phone reports a restored/cloned wallet (or any local tamper lock): old walletId keeps settling until its grace
   *  period ends (then escrow is refunded); the same device gets a fresh walletId with zero balance and zero counters. */
  async rotateWallet(u: User, deviceId: string, attestation: string) {
    const dev = await this.gate(u, deviceId, attestation, "rotate");
    const cur = this.store.activeWallet(u.id);
    if (cur?.status === "frozen") throw new ApiError(403, "wallet_frozen", "Wallet is frozen. Contact support.");
    if (cur) cur.status = "retired";
    const w: Wallet = { id: randomUUID(), userId: u.id, deviceId: dev.id, ceiling: 0, settledTotal: 0, status: "active", createdAt: this.now(), certExpiresAt: 0, refunded: 0 };
    this.store.wallets.set(w.id, w); this.audit("user:" + u.id, "rotate_wallet", `${cur?.id} -> ${w.id}`);
    return { walletId: w.id, certificate: b64(this.issueCert(u, w, dev)), issuerKeys: this.keys.publicList() };
  }

  balances(u: User) {
    const w = this.store.activeWallet(u.id);
    const pendingInflight = 0; // pending lives on the receiver phone until settlement; server knows only settled
    return { available: this.ledger.balance("available:" + u.id), offline: w ? this.ledger.balance("escrow:" + w.id) : 0, pending: pendingInflight, walletId: w?.id ?? null, tier: u.tier };
  }

  // ---------- settlement ----------
  async settleBatch(u: User, a: { deviceId: string; attestation: string; tokens: string[] }): Promise<SettleResult[]> {
    await this.gate(u, a.deviceId, a.attestation, "settle");
    if (a.tokens.length > 200) throw new ApiError(413, "batch_too_big", "Send fewer items at once.");
    const mine = new Set(this.store.walletsOf(u.id).map((w) => w.id));
    const out: SettleResult[] = [];
    for (const t of a.tokens) out.push(this.settleOne(u, mine, unb64(t)));
    return out;
  }

  private reject(tx: { txId: string; walletId?: string; counter?: number; amount?: number; cum?: number; recv?: string; hash: string; created?: number }, reason: string): SettleResult {
    if (!this.store.txs.has(tx.txId) && tx.txId) this.store.txs.set(tx.txId, { txId: tx.txId, walletId: tx.walletId ?? "", counter: tx.counter ?? 0, cumulative: tx.cum ?? 0, amount: tx.amount ?? 0, receiverWalletId: tx.recv ?? "", tokenHash: tx.hash, status: "rejected", reason, createdAt: tx.created ?? 0, settledAt: this.now() });
    return { txId: tx.txId, status: "rejected", reason };
  }

  private settleOne(u: User, mine: Set<string>, bytes: Uint8Array): SettleResult {
    let t; try { t = parseToken(bytes); } catch { return { txId: "", status: "rejected", reason: "malformed" }; }
    const p = t.payload, txId = hex(p.txId);
    // hash the SIGNED PAYLOAD (not the token): ECDSA signatures are randomized, so a re-signed identical payload is the same payment
    const hash = h(t.payloadBytes);
    const base = { txId, walletId: p.walletId, counter: p.counter, amount: p.amount, cum: p.cumulativeSpent, recv: p.receiverRef, hash, created: p.createdAt };
    const prior = this.store.txs.get(txId);
    if (prior) {
      if (prior.tokenHash === hash) return { txId, status: prior.status === "settled" ? "duplicate" : "rejected", reason: prior.reason };
      this.flag(p.walletId, "txid_reuse", `txId ${txId} reused with different bytes`);
      return { txId, status: "rejected", reason: "txid_reuse" };
    }
    const cv = verifyCertSig(t.certParsed, this.keys.trusted());
    if (!cv.trusted || !cv.valid) return this.reject(base, "bad_certificate");
    let sigOk = false; try { sigOk = verifyPayerSig(t); } catch { /* bad key */ }
    if (!sigOk) return this.reject(base, "bad_signature");
    if (!mine.has(p.receiverRef)) return this.reject(base, "wrong_receiver");
    if (p.currency !== config.currency || t.cert.currency !== p.currency) return this.reject(base, "currency_mismatch");
    if (t.cert.walletId !== p.walletId) return this.reject(base, "wallet_mismatch");
    const w = this.store.wallets.get(p.walletId);
    if (!w) return this.reject(base, "unknown_wallet");
    const dev = this.store.devices.get(w.deviceId);
    if (!dev || hex(dev.pubKey) !== hex(t.cert.devicePubKey)) return this.reject(base, "device_mismatch");
    if (p.createdAt > p.expiresAt || p.createdAt > t.cert.expiresAt + config.maxClockSkewSec) return this.reject(base, "bad_window");
    if (this.now() > t.cert.expiresAt + config.settlementGraceSec || w.status === "closed") return this.reject(base, "too_late");
    if (p.amount <= 0 || p.amount > t.cert.perTxMax) return this.reject(base, "over_per_tx_max");
    if (p.cumulativeSpent < p.amount || p.cumulativeSpent > t.cert.spendCeiling || t.cert.spendCeiling > w.ceiling) return this.reject(base, "over_ceiling");
    // double-spend: same (wallet, counter), different token
    const wc = `${p.walletId}:${p.counter}`;
    if (this.store.txByWalletCounter.has(wc)) {
      this.flag(p.walletId, "double_spend", `counter ${p.counter} used twice`);
      return this.reject(base, "double_spend");
    }
    // cumulative must be strictly monotone in counter
    for (const o of this.store.txsOfWallet(p.walletId)) {
      if ((o.counter < p.counter && o.cumulative >= p.cumulativeSpent) || (o.counter > p.counter && o.cumulative <= p.cumulativeSpent)) {
        this.flag(p.walletId, "inconsistent_cumulative", `counter ${p.counter}`); return this.reject(base, "inconsistent_counter");
      }
    }
    // escrow must cover it (clone / over-spend shows up here)
    if (this.ledger.balance("escrow:" + w.id) < p.amount) { this.flag(p.walletId, "escrow_exhausted", "spend beyond escrow"); return this.reject(base, "escrow_exhausted"); }
    const recvWallet = this.store.wallets.get(p.receiverRef)!;
    this.ledger.post("settle:" + txId, `settle ${txId}`, [{ account: "escrow:" + w.id, delta: -p.amount }, { account: "available:" + recvWallet.userId, delta: p.amount }]);
    w.settledTotal += p.amount;
    this.store.txs.set(txId, { txId, walletId: w.id, counter: p.counter, cumulative: p.cumulativeSpent, amount: p.amount, receiverWalletId: p.receiverRef, tokenHash: hash, status: "settled", createdAt: p.createdAt, settledAt: this.now() });
    this.store.txByWalletCounter.set(wc, txId);
    this.notify(recvWallet.userId, "settled", `₦${p.amount / 100} now available`);
    this.notify(w.userId, "payer_settled", `Your ₦${p.amount / 100} payment settled`);
    return { txId, status: "settled" };
  }

  // ---------- risk / freeze ----------
  flag(walletId: string, kind: string, detail: string) {
    const w = this.store.wallets.get(walletId); if (!w) return;
    this.store.disputes.push({ id: randomUUID(), walletId, kind, detail, status: "open", at: this.now() });
    this.freeze(walletId, kind, "system");
    this.notify(w.userId, "frozen", "Your wallet is frozen. Contact support.");
  }
  freeze(walletId: string, reason: string, actor: string) {
    const w = this.store.wallets.get(walletId); if (!w) throw new ApiError(404, "no_wallet", "Wallet not found.");
    if (w.status !== "frozen") { w.status = "frozen"; w.frozenAt = this.now(); }
    const dev = this.store.devices.get(w.deviceId);
    this.addBlock("wallet", walletId, reason); if (dev) this.addBlock("device", dev.keyId, reason);
    this.audit(actor, "freeze", `${walletId} ${reason}`);
  }
  private addBlock(kind: "wallet" | "device", id: string, reason: string) {
    if (this.store.blocklist.some((b) => b.kind === kind && b.id === id)) return;
    this.store.blocklist.push({ seq: this.store.blocklist.length + 1, kind, id, reason, at: this.now() });
  }
  blocklistSince(since: number) {
    return { entries: this.store.blocklist.filter((b) => b.seq > since), latest: this.store.blocklist.length, serverTime: this.now(), issuerKeys: this.keys.publicList() };
  }

  // ---------- refunds ----------
  /** Refund unspent escrow to the user's linked account. Skips frozen wallets (held for disputes). */
  async refundWallet(walletId: string, actor: string, force = false) {
    const w = this.store.wallets.get(walletId); if (!w) throw new ApiError(404, "no_wallet", "Wallet not found.");
    if (w.status === "frozen" && !force) throw new ApiError(409, "wallet_frozen", "Wallet is held for review.");
    const u = this.store.users.get(w.userId)!;
    const amt = this.ledger.balance("escrow:" + w.id);
    if (amt > 0) {
      const key = "refund:" + w.id;
      this.ledger.post(key, "refund", [{ account: "escrow:" + w.id, delta: -amt }, { account: "issuer:settlement", delta: amt }]);
      try { await this.d.issuer.refund(u.issuerAccountRef, amt, key); } catch (e) { throw this.issuerErr(e); }
      w.refunded += amt;
    }
    if (w.status !== "frozen") w.status = "closed";
    this.audit(actor, "refund", `${walletId} ${amt}`);
    return { refunded: amt };
  }
  /** Scheduled job: refund wallets whose certificate + settlement grace has passed. */
  async runExpiryRefunds() {
    const out: { walletId: string; refunded: number }[] = [];
    for (const w of this.store.wallets.values()) {
      if ((w.status !== "active" && w.status !== "retired") || w.certExpiresAt === 0) continue;
      if (this.now() > w.certExpiresAt + config.settlementGraceSec) {
        const r = await this.refundWallet(w.id, "job:expiry");
        if (r.refunded > 0) { out.push({ walletId: w.id, refunded: r.refunded }); this.notify(w.userId, "refund", `₦${r.refunded / 100} unused offline money was returned to your account`); }
      }
    }
    return out;
  }
  async withdrawAvailable(u: User, amount: number, key: string) {
    const bal = this.ledger.balance("available:" + u.id);
    if (amount <= 0 || amount > bal) throw new ApiError(422, "insufficient_available", "Not enough available balance.");
    this.ledger.post("withdraw:" + key, "withdraw", [{ account: "available:" + u.id, delta: -amount }, { account: "issuer:settlement", delta: amount }]);
    await this.d.issuer.credit(u.issuerAccountRef, amount, "withdraw:" + key);
    return { balance: this.ledger.balance("available:" + u.id) };
  }

  receipt(u: User, txId: string) {
    const t = this.store.txs.get(txId);
    const mine = new Set(this.store.walletsOf(u.id).map((w) => w.id));
    if (!t || !(mine.has(t.walletId) || mine.has(t.receiverWalletId))) throw new ApiError(404, "no_receipt", "Receipt not found.");
    return { txId: t.txId, status: t.status, reason: t.reason, amount: t.amount, settledAt: t.settledAt, ref: "GP-" + t.txId.slice(0, 8).toUpperCase() };
  }

  // ---------- notifications + audit ----------
  notify(userId: string, kind: string, text: string) { this.store.notices.push({ userId, kind, text, at: this.now() }); /* production: push (FCM/APNs) then SMS fallback */ }
  audit(actor: string, action: string, detail: string) { this.store.audit.push({ at: this.now(), actor, action, detail }); }
  resolveDispute(id: string, actor: string) { const d = this.store.disputes.find((x) => x.id === id); if (!d) throw new ApiError(404, "no_dispute", "Not found."); d.status = "resolved"; this.audit(actor, "dispute_resolved", id); return d; }
  // NOTE: unfreezing is deliberately not implemented: blocklist entries are append-only. Resolve disputes, refund with force, retire the wallet.
}
