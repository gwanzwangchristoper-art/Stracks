// Double-entry, append-only escrow ledger. Postings are frozen; balances derive from postings.
// Accounts: issuer:settlement (external, may go negative) | escrow:<walletId> | available:<userId> | held:<walletId>
export interface Leg { account: string; delta: number }
export interface Posting { seq: number; ref: string; memo: string; legs: readonly Leg[]; at: number }

export class LedgerError extends Error {}

export class Ledger {
  private postings: Posting[] = [];
  private byRef = new Map<string, Posting>();
  private bal = new Map<string, number>();
  private now: () => number;
  constructor(now: () => number = () => Math.floor(Date.now() / 1000)) { this.now = now; }

  /** Idempotent by ref: replaying the same ref returns the original posting and changes nothing. */
  post(ref: string, memo: string, legs: Leg[]): Posting {
    const prior = this.byRef.get(ref);
    if (prior) return prior;
    if (legs.length < 2) throw new LedgerError("posting needs at least two legs");
    let sum = 0;
    for (const l of legs) {
      if (!Number.isSafeInteger(l.delta) || l.delta === 0) throw new LedgerError("bad leg amount");
      sum += l.delta;
    }
    if (sum !== 0) throw new LedgerError("posting does not balance");
    const next = new Map<string, number>();
    for (const l of legs) next.set(l.account, (next.get(l.account) ?? this.balance(l.account)) + l.delta);
    for (const [a, v] of next) if (v < 0 && !a.startsWith("issuer:")) throw new LedgerError(`insufficient funds in ${a}`);
    const p: Posting = Object.freeze({ seq: this.postings.length + 1, ref, memo, legs: Object.freeze(legs.map((l) => Object.freeze({ ...l }))), at: this.now() });
    this.postings.push(p); this.byRef.set(ref, p);
    for (const [a, v] of next) this.bal.set(a, v);
    return p;
  }
  balance(account: string): number { return this.bal.get(account) ?? 0; }
  all(): readonly Posting[] { return this.postings; }
  /** Invariant check: every posting sums to zero and recomputed balances match. */
  audit(): boolean {
    const re = new Map<string, number>();
    for (const p of this.postings) {
      if (p.legs.reduce((s, l) => s + l.delta, 0) !== 0) return false;
      for (const l of p.legs) re.set(l.account, (re.get(l.account) ?? 0) + l.delta);
    }
    for (const [a, v] of re) if ((this.bal.get(a) ?? 0) !== v) return false;
    return true;
  }
}
