// Append-only double-entry ledger. Every posting sums to zero; balances are derived, never stored.
export class Ledger {
  #entries = [];
  post(ref, legs) {
    if (legs.reduce((s, l) => s + l.amount, 0) !== 0) throw new Error('unbalanced posting');
    if (this.#entries.some(e => e.ref === ref)) return false; // idempotent
    this.#entries.push(Object.freeze({ ref, legs: legs.map(l => Object.freeze({ ...l })), at: Date.now() }));
    return true;
  }
  balance(account) {
    return this.#entries.flatMap(e => e.legs).filter(l => l.account === account).reduce((s, l) => s + l.amount, 0);
  }
  get entries() { return [...this.#entries]; }
}
