// Thin HTTP layer (node:http, zero deps). Port to NestJS controllers 1:1: each route calls one GoPay method.
import { createServer, type IncomingMessage, type ServerResponse } from "node:http";
import { timingSafeEqual } from "node:crypto";
import { GoPay, ApiError } from "./app.ts";
import { MockIssuer, MockAttestation, MockKyc } from "./issuer.ts";
import { config } from "./config.ts";

export function buildApp() {
  const issuer = new MockIssuer();
  const app = new GoPay({ issuer, attest: new MockAttestation(), kyc: new MockKyc() });
  return { app, issuer };
}

const json = (res: ServerResponse, status: number, body: unknown) => { res.writeHead(status, { "content-type": "application/json", "cache-control": "no-store" }); res.end(JSON.stringify(body)); };
async function readBody(req: IncomingMessage): Promise<any> {
  const chunks: Buffer[] = []; let n = 0;
  for await (const c of req) { n += (c as Buffer).length; if (n > 1_000_000) throw new ApiError(413, "too_big", "Request too large."); chunks.push(c as Buffer); }
  if (!chunks.length) return {};
  try { return JSON.parse(Buffer.concat(chunks).toString()); } catch { throw new ApiError(400, "bad_json", "Bad request."); }
}
const adminOk = (k: string | undefined) => !!k && k.length === config.adminKey.length && timingSafeEqual(Buffer.from(k), Buffer.from(config.adminKey));

export function makeHandler(app: GoPay) {
  return async (req: IncomingMessage, res: ServerResponse) => {
    try {
      const url = new URL(req.url ?? "/", "http://x"); const route = `${req.method} ${url.pathname}`;
      const bearer = req.headers.authorization?.replace(/^Bearer /, "");
      const b = req.method === "POST" ? await readBody(req) : {};
      const user = () => app.auth(bearer);
      if (url.pathname.startsWith("/admin/")) {
        if (!adminOk(req.headers["x-admin-key"] as string | undefined)) throw new ApiError(401, "admin_auth", "Not allowed.");
        const m = url.pathname.match(/^\/admin\/wallets\/([^/]+)\/(freeze|refund)$/);
        if (req.method === "POST" && m) return json(res, 200, m[2] === "freeze" ? (app.freeze(m[1]!, b.reason ?? "admin", "admin"), { ok: true }) : await app.refundWallet(m[1]!, "admin", !!b.force));
        if (route === "GET /admin/audit") return json(res, 200, app.store.audit);
        if (route === "GET /admin/disputes") return json(res, 200, app.store.disputes);
        if (req.method === "POST" && url.pathname.startsWith("/admin/disputes/")) return json(res, 200, app.resolveDispute(url.pathname.split("/")[3]!, "admin"));
        throw new ApiError(404, "not_found", "Not found.");
      }
      switch (route) {
        case "GET /health": return json(res, 200, { ok: true });
        case "POST /v1/auth/otp/request": return json(res, 200, app.requestOtp(b.phone));
        case "POST /v1/auth/otp/verify": return json(res, 200, app.verifyOtp(b.phone, b.code));
        case "POST /v1/auth/pin/lockout": return json(res, 200, app.reportPinLockout(user()));
        case "POST /v1/auth/pin/unlock": { const r = app.verifyOtp(b.phone, b.code); return json(res, 200, { ...app.unlockPin(app.auth(r.token)), token: r.token }); }
        case "POST /v1/kyc/submit": return json(res, 200, await app.submitKyc(user(), b.tier, b.data ?? {}));
        case "POST /v1/devices/register": return json(res, 200, await app.registerDevice(user(), b.publicKey, b.platform, b.attestation));
        case "POST /v1/wallet/load": return json(res, 200, await app.load(user(), b));
        case "POST /v1/wallet/certificate/refresh": return json(res, 200, await app.refreshCertificate(user(), b.deviceId, b.attestation));
        case "POST /v1/wallet/rotate": return json(res, 200, await app.rotateWallet(user(), b.deviceId, b.attestation));
        case "POST /v1/sync/settle": return json(res, 200, { results: await app.settleBatch(user(), b) });
        case "POST /v1/wallet/withdraw": return json(res, 200, await app.withdrawAvailable(user(), b.amount, b.key));
        case "GET /v1/balance": return json(res, 200, app.balances(user()));
        case "GET /v1/blocklist": user(); return json(res, 200, app.blocklistSince(Number(url.searchParams.get("since") ?? 0)));
        case "GET /v1/notifications": { const u = user(); return json(res, 200, app.store.notices.filter((n) => n.userId === u.id)); }
      }
      const r = url.pathname.match(/^\/v1\/receipts\/([0-9a-f]{32})$/);
      if (req.method === "GET" && r) return json(res, 200, app.receipt(user(), r[1]!));
      throw new ApiError(404, "not_found", "Not found.");
    } catch (e) {
      if (e instanceof ApiError) return json(res, e.status, { error: e.code, message: e.message });
      console.error(JSON.stringify({ level: "error", msg: (e as Error).message })); // structured logs; never log tokens/PINs
      return json(res, 500, { error: "server_error", message: "Something went wrong. Try again." });
    }
  };
}

if (import.meta.url === `file://${process.argv[1]}`) {
  const { app } = buildApp();
  createServer(makeHandler(app)).listen(Number(process.env.PORT ?? 8080), () => console.log(JSON.stringify({ level: "info", msg: "gopay backend up (MOCK issuer)" })));
  setInterval(() => app.runExpiryRefunds().catch((e) => console.error(String(e))), 3600_000).unref();
}
