# gOpay: phased source drop
phase1-architecture  protocol (CBOR/Base45), threat model, test vectors
phase2-backend       Node 22 TypeScript (no build step): `npm test`, `npm start`
phase3-mobile-core   Flutter package: keys, sealed record, wallet, verify
phase4-transports    QR chunking + NFC (Android HCE, iOS reader)
phase5-ui-app        Flutter UI shell (brand, Home, keypad); wiring to core is partial
phase6-sync-l10n     sync client + 5-language strings (needs native review)
phase7-hardening     pilot plan, honest security status
Build APK (needs Flutter SDK + Android SDK): cd phase5-ui-app && flutter create . --platforms=android,ios && flutter pub get && flutter build apk
Then copy the native Kotlin/Swift files from phase3/phase4 into android/ and ios/ and register the plugins.
