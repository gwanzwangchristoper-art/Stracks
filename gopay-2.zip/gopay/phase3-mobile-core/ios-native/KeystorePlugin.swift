import Flutter
import Foundation
import Security
import LocalAuthentication
import CryptoKit
import DeviceCheck

/// Channel "gopay/keystore".
///  - Signing key: P-256 in the Secure Enclave, non-exportable, `.userPresence` required for every signature.
///  - Sealing keys: random 32-byte keys in the Keychain, `...ThisDeviceOnly` (not in backups, never migrates), AES-256-GCM via CryptoKit.
///  - Attestation: App Attest.
public class KeystorePlugin: NSObject, FlutterPlugin {
  public static func register(with registrar: FlutterPluginRegistrar) {
    let ch = FlutterMethodChannel(name: "gopay/keystore", binaryMessenger: registrar.messenger())
    registrar.addMethodCallDelegate(KeystorePlugin(), channel: ch)
  }
  private func tag(_ a: String) -> Data { Data(("gopay.sign." + a).utf8) }
  private func err(_ r: FlutterResult, _ code: String, _ m: String? = nil) { r(FlutterError(code: code, message: m, details: nil)) }

  public func handle(_ call: FlutterMethodCall, result: @escaping FlutterResult) {
    let a = call.arguments as? [String: Any] ?? [:]
    let alias = a["alias"] as? String ?? ""
    switch call.method {
    case "ensureSigningKey": ensureSigningKey(alias, result)
    case "sign": sign(alias, (a["data"] as! FlutterStandardTypedData).data, a["prompt"] as? String ?? "Confirm", result)
    case "createAesKey": createAes(alias); result(nil)
    case "deleteKey": deleteAes(alias); result(nil)
    case "hasKey": result(loadAes(alias) != nil)
    case "encrypt": encrypt(alias, (a["data"] as! FlutterStandardTypedData).data, (a["aad"] as! FlutterStandardTypedData).data, result)
    case "decrypt": decrypt(alias, (a["data"] as! FlutterStandardTypedData).data, (a["aad"] as! FlutterStandardTypedData).data, result)
    case "attest": attest(a["nonce"] as? String ?? "", result)
    default: result(FlutterMethodNotImplemented)
    }
  }

  private func privateKey(_ alias: String, prompt: String? = nil) -> SecKey? {
    var q: [String: Any] = [kSecClass as String: kSecClassKey, kSecAttrApplicationTag as String: tag(alias), kSecAttrKeyType as String: kSecAttrKeyTypeECSECPrimeRandom,
                            kSecReturnRef as String: true]
    if let p = prompt { let c = LAContext(); c.localizedReason = p; q[kSecUseAuthenticationContext as String] = c }
    var out: CFTypeRef?
    return SecItemCopyMatching(q as CFDictionary, &out) == errSecSuccess ? (out as! SecKey) : nil
  }
  private func ensureSigningKey(_ alias: String, _ r: FlutterResult) {
    var key = privateKey(alias)
    if key == nil {
      var e: Unmanaged<CFError>?
      guard let ac = SecAccessControlCreateWithFlags(nil, kSecAttrAccessibleWhenPasscodeSetThisDeviceOnly, [.privateKeyUsage, .userPresence], &e) else { return err(r, "key_error", "no passcode set") }
      let attrs: [String: Any] = [kSecAttrKeyType as String: kSecAttrKeyTypeECSECPrimeRandom, kSecAttrKeySizeInBits as String: 256,
        kSecAttrTokenID as String: kSecAttrTokenIDSecureEnclave,
        kSecPrivateKeyAttrs as String: [kSecAttrIsPermanent as String: true, kSecAttrApplicationTag as String: tag(alias), kSecAttrAccessControl as String: ac]]
      key = SecKeyCreateRandomKey(attrs as CFDictionary, &e)
      if key == nil { return err(r, "key_error", e?.takeRetainedValue().localizedDescription) }
    }
    guard let pub = SecKeyCopyPublicKey(key!), let raw = SecKeyCopyExternalRepresentation(pub, nil) as Data? else { return err(r, "key_error") }
    r(FlutterStandardTypedData(bytes: raw))                       // 65-byte X9.63 uncompressed point
  }
  private func sign(_ alias: String, _ data: Data, _ prompt: String, _ r: @escaping FlutterResult) {
    DispatchQueue.global().async {                                // the system prompt blocks; keep it off the main thread
      guard let k = self.privateKey(alias, prompt: prompt) else { return DispatchQueue.main.async { self.err(r, "no_key") } }
      var e: Unmanaged<CFError>?
      let sig = SecKeyCreateSignature(k, .ecdsaSignatureMessageX962SHA256, data as CFData, &e) as Data?
      DispatchQueue.main.async { if let s = sig { r(FlutterStandardTypedData(bytes: s)) } else { self.err(r, "auth_cancelled", e?.takeRetainedValue().localizedDescription) } }
    }
  }

  // --- AES sealing keys in Keychain
  private func aesQuery(_ alias: String) -> [String: Any] { [kSecClass as String: kSecClassGenericPassword, kSecAttrService as String: "gopay.seal", kSecAttrAccount as String: alias] }
  private func loadAes(_ alias: String) -> SymmetricKey? {
    var q = aesQuery(alias); q[kSecReturnData as String] = true
    var out: CFTypeRef?
    guard SecItemCopyMatching(q as CFDictionary, &out) == errSecSuccess, let d = out as? Data else { return nil }
    return SymmetricKey(data: d)
  }
  private func createAes(_ alias: String) {
    if loadAes(alias) != nil { return }
    var q = aesQuery(alias)
    q[kSecValueData as String] = Data((0..<32).map { _ in UInt8.random(in: 0...255) })
    q[kSecAttrAccessible as String] = kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly     // readable by background sync, never in backups
    SecItemAdd(q as CFDictionary, nil)
  }
  private func deleteAes(_ alias: String) { SecItemDelete(aesQuery(alias) as CFDictionary) }
  private func encrypt(_ alias: String, _ d: Data, _ aad: Data, _ r: FlutterResult) {
    guard let k = loadAes(alias) else { return err(r, "no_key") }
    do { let s = try AES.GCM.seal(d, using: k, authenticating: aad); r(FlutterStandardTypedData(bytes: s.combined!)) }   // nonce(12)||ct||tag
    catch { err(r, "native_error", "\(error)") }
  }
  private func decrypt(_ alias: String, _ d: Data, _ aad: Data, _ r: FlutterResult) {
    guard let k = loadAes(alias) else { return err(r, "no_key") }
    do { r(FlutterStandardTypedData(bytes: try AES.GCM.open(try AES.GCM.SealedBox(combined: d), using: k, authenticating: aad))) }
    catch { err(r, "bad_tag") }
  }

  // --- App Attest
  private func attest(_ nonce: String, _ r: @escaping FlutterResult) {
    let svc = DCAppAttestService.shared
    guard svc.isSupported else { return err(r, "attestation_unsupported") }
    let hash = Data(SHA256.hash(data: Data(nonce.utf8)))
    let stored = UserDefaults.standard.string(forKey: "gopay.attest.keyid")
    func assert(_ id: String) { svc.generateAssertion(id, clientDataHash: hash) { d, e in if let d = d { r(d.base64EncodedString()) } else { self.err(r, "attestation_failed", e?.localizedDescription) } } }
    if let id = stored { assert(id); return }
    svc.generateKey { id, e in
      guard let id = id else { return self.err(r, "attestation_failed", e?.localizedDescription) }
      svc.attestKey(id, clientDataHash: hash) { d, e in
        if let d = d { UserDefaults.standard.set(id, forKey: "gopay.attest.keyid"); r(d.base64EncodedString()) } else { self.err(r, "attestation_failed", e?.localizedDescription) }
      }
    }
  }
}
