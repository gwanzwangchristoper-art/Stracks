import 'dart:typed_data';
import 'package:flutter_test/flutter_test.dart';
import 'package:gopay_core/gopay_core.dart';

void main() {
  late MemoryVault vault;
  late MemoryBlobStore files;
  setUp(() { vault = MemoryVault(); files = MemoryBlobStore(); });

  test('commit/reopen round trip; old generations are cleaned up', () async {
    final a = SealedRecord(vault, files, 'w');
    expect(await a.open(), SealStatus.fresh);
    await a.commit({'counter': 1});
    await a.commit({'counter': 2});
    expect(files.files.length, 1);
    expect(vault.keys.length, 1);
    final b = SealedRecord(vault, files, 'w');
    expect(await b.open(), SealStatus.ok);
    expect(b.data['counter'], 2);
  });

  test('ROLLBACK: restoring an old file from backup cannot be opened (its key is gone) -> tampered', () async {
    final a = SealedRecord(vault, files, 'w');
    await a.open();
    await a.commit({'counter': 1});
    final oldFiles = Map<String, Uint8List>.from(files.files);   // attacker's backup
    await a.commit({'counter': 5});                              // real progress, key g1 deleted
    files.files..clear()..addAll(oldFiles);                      // restore backup over the files
    final b = SealedRecord(vault, files, 'w');
    expect(await b.open(), SealStatus.tampered);
    expect(() => b.commit({'counter': 2}), throwsStateError);   // refuses to continue
  });

  test('CLONE: copying files to a device without the Keystore keys -> tampered', () async {
    final a = SealedRecord(vault, files, 'w');
    await a.open();
    await a.commit({'counter': 3});
    final otherVault = MemoryVault();                            // new phone: empty Keystore
    final b = SealedRecord(otherVault, files, 'w');
    expect(await b.open(), SealStatus.tampered);
  });

  test('CRASH after new key created but before file written: old state still opens', () async {
    final a = SealedRecord(vault, files, 'w');
    await a.open();
    await a.commit({'counter': 1});
    await vault.createKey('gopay.seal.w.g2');                    // simulated crash leftovers
    final b = SealedRecord(vault, files, 'w');
    expect(await b.open(), SealStatus.ok);
    expect(b.data['counter'], 1);
    expect(await vault.hasKey('gopay.seal.w.g2'), isFalse);      // orphan removed
  });

  test('CRASH after file written but before old file/key deleted: newest wins, old removed', () async {
    final a = SealedRecord(vault, files, 'w');
    await a.open();
    await a.commit({'counter': 1});
    // emulate: write gen2 fully, then crash before deleting gen1
    await vault.createKey('gopay.seal.w.g2');
    final blob = await vault.encrypt('gopay.seal.w.g2', Uint8List.fromList('{"counter":2}'.codeUnits), Uint8List.fromList('w|2'.codeUnits));
    await files.writeAtomic('w.2.bin', blob);
    final b = SealedRecord(vault, files, 'w');
    expect(await b.open(), SealStatus.ok);
    expect(b.data['counter'], 2);
    expect(files.files.keys.toList(), ['w.2.bin']);
  });

  test('flipped bit in file is detected', () async {
    final a = SealedRecord(vault, files, 'w');
    await a.open();
    await a.commit({'counter': 1});
    files.files['w.1.bin']![20] ^= 1;
    expect(await SealedRecord(vault, files, 'w').open(), SealStatus.tampered);
  });

  test('failed write leaves state unchanged', () async {
    final a = SealedRecord(vault, files, 'w');
    await a.open();
    await a.commit({'counter': 1});
    final broken = _FailingStore(files);
    final c = SealedRecord(vault, broken, 'w');
    await c.open();
    broken.fail = true;
    await expectLater(c.commit({'counter': 2}), throwsException);
    broken.fail = false;
    expect(await SealedRecord(vault, files, 'w').open(), SealStatus.ok);
    expect(vault.keys.length, 1);
  });
}

class _FailingStore implements BlobStore {
  final MemoryBlobStore inner;
  bool fail = false;
  _FailingStore(this.inner);
  @override Future<Uint8List?> read(String n) => inner.read(n);
  @override Future<void> writeAtomic(String n, Uint8List b) async { if (fail) throw Exception('disk full'); await inner.writeAtomic(n, b); }
  @override Future<void> delete(String n) => inner.delete(n);
  @override Future<List<String>> list(String p) => inner.list(p);
}
