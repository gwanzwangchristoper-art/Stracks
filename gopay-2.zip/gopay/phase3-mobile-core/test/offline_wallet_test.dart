import 'dart:typed_data';
import 'package:flutter_test/flutter_test.dart';
import 'package:gopay_core/gopay_core.dart';
import 'helpers.dart';

// Builds an issuer + certificate in Dart so the wallet can be exercised without the backend.
class Issuer {
  final signer = SoftwareSigner.fromSeed(seed(0x11));
  late Uint8List pub;
  late String keyId;
  Future<void> init() async { pub = await signer.publicKey(); keyId = keyIdOf(pub); }
  Future<Uint8List> cert(String wallet, Uint8List devPub, {int ceiling = 1000000, int perTx = 500000, int expiresAt = 1800000000 + 5 * 86400, int maxUnsynced = 30}) async {
    final cb = cborEncode(<int, Object?>{1: 1, 2: wallet, 3: devPub, 4: 'att', 5: 'NGN', 6: ceiling, 7: perTx, 8: expiresAt, 9: keyId, 10: 1800000000, 11: maxUnsynced});
    final sig = await signer.sign(cat([ 'GOPAY1-CERT'.codeUnits, cb ]), prompt: '');
    return cborEncode([cb, sig]);
  }
}

void main() {
  late Env env; late Issuer issuer; late SoftwareSigner dev; late OfflineWallet w; late TrustedClock clock; late String recvWallet;
  Future<bool> yes() async => true;

  setUp(() async {
    env = Env(); issuer = Issuer(); await issuer.init(); dev = SoftwareSigner.fromSeed(seed(0x22)); recvWallet = '22222222-2222-4222-8222-222222222222';
    clock = TrustedClock(wall: env.wall);
    w = OfflineWallet(SealedRecord(env.vault, env.files, 'wallet'), dev, clock);
    await w.open();
    await w.installCertificate(await issuer.cert('11111111-1111-4111-8111-111111111111', await dev.publicKey()), serverTime: env.t, issuerKeys: {issuer.keyId: hexOf(issuer.pub)});
  });

  ReceiverCtx rctx(int pending, Set<String> tx, Set<String> wc) => ReceiverCtx(trustedIssuerKeys: {issuer.keyId: issuer.pub}, nowSec: env.t, myWalletId: recvWallet,
      myMaxAccept: 500000, pendingTotal: pending, pendingCap: 2000000, seenTxIds: tx, seenWalletCounters: wc);

  test('payment: counter and cumulative advance, token passes receiver pipeline', () async {
    final e = await w.pay(receiverRef: recvWallet, amount: 100000, authorize: yes);
    expect(w.counter, 1); expect(w.cumulative, 100000); expect(w.remaining, 900000);
    final r = verifyForReceiver(unhex(e.tokenHex), rctx(0, {}, {}));
    expect(r.ok, isTrue); expect(r.checks.length, 12);
  });

  test('state survives restart (sealed) and counters never go backwards', () async {
    await w.pay(receiverRef: recvWallet, amount: 100000, authorize: yes);
    final w2 = OfflineWallet(SealedRecord(env.vault, env.files, 'wallet'), dev, TrustedClock(wall: env.wall));
    expect(await w2.open(), SealStatus.ok);
    expect(w2.counter, 1);
    final e2 = await w2.pay(receiverRef: recvWallet, amount: 50000, authorize: yes);
    expect(e2.counter, 2);
  });

  test('cannot exceed balance, per-tx max, or max unsynced', () async {
    await expectLater(w.pay(receiverRef: recvWallet, amount: 600000, authorize: yes), throwsA(predicate((e) => e is PayError && e.code == 'over_limit')));
    for (var i = 0; i < 2; i++) { await w.pay(receiverRef: recvWallet, amount: 500000, authorize: yes); }
    await expectLater(w.pay(receiverRef: recvWallet, amount: 1, authorize: yes), throwsA(predicate((e) => e is PayError && e.code == 'over_balance')));
  });

  test('auth failure changes nothing', () async {
    await expectLater(w.pay(receiverRef: recvWallet, amount: 1000, authorize: () async => false), throwsA(predicate((e) => e is PayError && e.code == 'auth_failed')));
    expect(w.counter, 0); expect(w.cumulative, 0);
  });

  test('concurrent payments get distinct counters (no double use)', () async {
    final rs = await Future.wait([for (var i = 0; i < 5; i++) w.pay(receiverRef: recvWallet, amount: 1000, authorize: yes)]);
    expect(rs.map((e) => e.counter).toSet().length, 5);
    expect(w.cumulative, 5000);
  });

  test('expired certificate refuses to sign offline', () async {
    env.t += 6 * 86400;
    await expectLater(w.pay(receiverRef: recvWallet, amount: 1000, authorize: yes), throwsA(predicate((e) => e is PayError && e.code == 'cert_expired')));
  });

  test('CLOCK ROLLBACK is detected and blocks signing until server time agrees', () async {
    await w.pay(receiverRef: recvWallet, amount: 1000, authorize: yes);
    env.t -= 3 * 86400;                                    // user sets the date back to keep an expired cert alive
    await expectLater(w.pay(receiverRef: recvWallet, amount: 1000, authorize: yes), throwsA(predicate((e) => e is PayError && e.code == 'clock')));
    clock.onServerTime(env.t);                             // real server time is also the (rolled back) wall? still blocked if server is ahead
    expect(clock.tampered, isFalse);                       // wall agrees with server within 5 min => cleared
  });

  test('interrupted transfer: same token bytes can be shown again until expiry, never re-signed', () async {
    final e = await w.pay(receiverRef: recvWallet, amount: 1000, authorize: yes);
    expect(hexOf(w.reshow(e.txId)!), e.tokenHex);
    env.t += 901;
    expect(w.reshow(e.txId), isNull);
    expect(w.counter, 1);
  });

  test('receipt from the receiver is verified and marks the payment acknowledged; forged receipt is not', () async {
    final e = await w.pay(receiverRef: recvWallet, amount: 1000, authorize: yes);
    final rsigner = SoftwareSigner.fromSeed(seed(0x33));
    final rcert = await issuer.cert(recvWallet, await rsigner.publicKey(), ceiling: 0);
    final good = await signReceipt(rsigner, rcert, Receipt(unhex(e.txId), recvWallet, 1000, env.t));
    final wrongAmt = await signReceipt(rsigner, rcert, Receipt(unhex(e.txId), recvWallet, 999, env.t));
    expect(await w.acceptReceipt(wrongAmt), isFalse);
    expect(await w.acceptReceipt(good), isTrue);
    expect(w.outbox.single.status, 'acked');
    expect(w.reshow(e.txId), isNull);
  });

  test('frozen wallet (blocklist) stops signing', () async {
    await w.applyBlocklist({w.walletId!});
    await expectLater(w.pay(receiverRef: recvWallet, amount: 1000, authorize: yes), throwsA(predicate((e) => e is PayError && e.code == 'frozen')));
  });

  test('ROLLED-BACK / CLONED wallet record opens as tampered and the wallet cannot sign', () async {
    await w.pay(receiverRef: recvWallet, amount: 1000, authorize: yes);
    final old = Map<String, Uint8List>.from(env.files.files);
    await w.pay(receiverRef: recvWallet, amount: 1000, authorize: yes);
    env.files.files..clear()..addAll(old);
    final w2 = OfflineWallet(SealedRecord(env.vault, env.files, 'wallet'), dev, TrustedClock(wall: env.wall));
    expect(await w2.open(), SealStatus.tampered);
    await expectLater(w2.pay(receiverRef: recvWallet, amount: 1000, authorize: yes), throwsA(predicate((e) => e is PayError && e.code == 'tampered')));
  });

  test('commit failure discards the signed token and leaves counters unchanged', () async {
    final failing = _Fail(env.files);
    final w3 = OfflineWallet(SealedRecord(env.vault, failing, 'w3'), dev, TrustedClock(wall: env.wall));
    await w3.open();
    await w3.installCertificate(await issuer.cert('11111111-1111-4111-8111-111111111111', await dev.publicKey()), serverTime: env.t, issuerKeys: {issuer.keyId: hexOf(issuer.pub)});
    failing.fail = true;
    await expectLater(w3.pay(receiverRef: recvWallet, amount: 1000, authorize: yes), throwsException);
    expect(w3.counter, 0); expect(w3.outbox, isEmpty);
  });
}

class _Fail implements BlobStore {
  final MemoryBlobStore i; bool fail = false;
  _Fail(this.i);
  @override Future<Uint8List?> read(String n) => i.read(n);
  @override Future<void> writeAtomic(String n, Uint8List b) async { if (fail) throw Exception('disk full'); await i.writeAtomic(n, b); }
  @override Future<void> delete(String n) => i.delete(n);
  @override Future<List<String>> list(String p) => i.list(p);
}
