// Cross-language conformance: every vector was produced by the TypeScript reference.
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:flutter_test/flutter_test.dart';
import 'package:gopay_core/gopay_core.dart';

void main() {
  final v = jsonDecode(File('../phase1-architecture/test-vectors/vectors.json').readAsStringSync()) as Map<String, dynamic>;

  test('cbor vector matches and rejects non-canonical', () {
    final bytes = unhex(v['cbor'][0]['hex'] as String);
    final m = cborDecode(bytes) as Map<int, Object?>;
    expect(m[3], 'hi');
    expect(hexOf(cborEncode(m)), v['cbor'][0]['hex']);
    expect(() => cborDecode(Uint8List.fromList([0x18, 0x05])), throwsA(isA<CborException>()));
    expect(() => cborDecode(Uint8List.fromList([0xa2, 0x02, 0x00, 0x01, 0x00])), throwsA(isA<CborException>()));
    expect(() => cborDecode(Uint8List.fromList([0x01, 0x00])), throwsA(isA<CborException>()));
  });

  test('base45 RFC 9285 vectors', () {
    for (final c in v['base45']) {
      expect(base45Encode(Uint8List.fromList((c['text'] as String).codeUnits)), c['enc']);
      expect(String.fromCharCodes(base45Decode(c['enc'] as String)), c['text']);
    }
  });

  ReceiverCtx ctx(Map<String, dynamic> over) => ReceiverCtx(
        trustedIssuerKeys: {v['issuerKeyId'] as String: unhex(v['issuerPubHex'] as String)},
        nowSec: (over['nowSec'] as int?) ?? (v['NOW'] as int) + 30,
        myWalletId: v['WALLET_R'] as String,
        myMaxAccept: (over['myMaxAccept'] as int?) ?? 500000,
        pendingTotal: 0, pendingCap: 2000000,
        seenTxIds: {...((over['seenTxIds'] as List?) ?? []).cast<String>()},
        blockedWallets: {...((over['blockedWallets'] as List?) ?? []).cast<String>()},
      );

  for (final c in v['tokens']) {
    test('token vector: ${c['name']}', () {
      final bytes = unhex(c['tokenHex'] as String);
      expect(base45Decode(c['base45'] as String), bytes);
      final r = verifyForReceiver(bytes, ctx(Map<String, dynamic>.from(c['ctx'] as Map)));
      expect(r.ok, c['expectOk']);
      expect(r.last.id, c['expectLastCheck']);
    });
  }

  test('receipt vector verifies for the matching token', () {
    final tok = ParsedToken.parse(unhex(v['tokens'][0]['tokenHex'] as String));
    expect(verifyReceipt(unhex(v['receiptHex'] as String), {v['issuerKeyId'] as String: unhex(v['issuerPubHex'] as String)}, tok), isTrue);
  });

  test('software signer produces signatures the TS-compatible verifier accepts; DER round trip', () async {
    final s = SoftwareSigner.fromSeed(Uint8List.fromList(List.filled(32, 0x22)));
    expect(hexOf(await s.publicKey()), v['payerPubHex']);
    final sig = await s.sign(Uint8List.fromList([1, 2, 3]), prompt: 't');
    expect(p256Verify(await s.publicKey(), Uint8List.fromList([1, 2, 3]), sig), isTrue);
    expect(derToRaw(rawToDer(sig)), sig);
    expect(p256Verify(await s.publicKey(), Uint8List.fromList([1, 2, 4]), sig), isFalse);
  });
}
