import 'dart:typed_data';
import 'package:flutter_test/flutter_test.dart';
import 'package:gopay_core/gopay_core.dart';
import 'helpers.dart';

void main() {
  late Env env;
  setUp(() => env = Env());

  test('PIN: 3 wrong tries lock; counter survives restart; only server unlock clears it', () async {
    var g = PinGuard(SealedRecord(env.vault, env.files, 'pin'), iterations: 10);
    await g.open(); await g.setPin('4821');
    expect((await g.verify('0000')).attemptsLeft, 2);
    g = PinGuard(SealedRecord(env.vault, env.files, 'pin'), iterations: 10);       // app killed and restarted
    await g.open();
    expect((await g.verify('1111')).attemptsLeft, 1);
    expect((await g.verify('2222')).result, PinResult.locked);
    expect((await g.verify('4821')).result, PinResult.locked);                    // right PIN no longer works
    await g.serverUnlock();
    expect((await g.verify('4821')).result, PinResult.ok);
  });

  test('PIN must be 4 digits', () async {
    final g = PinGuard(SealedRecord(env.vault, env.files, 'pin'), iterations: 10);
    await g.open();
    expect(() => g.setPin('12a4'), throwsArgumentError);
  });

  test('restored PIN record counts as locked', () async {
    final g = PinGuard(SealedRecord(env.vault, env.files, 'pin'), iterations: 10);
    await g.open(); await g.setPin('4821');
    final g2 = PinGuard(SealedRecord(MemoryVault(), env.files, 'pin'), iterations: 10);   // different keystore
    await g2.open();
    expect(g2.locked, isTrue);
    await g2.serverUnlock(newPin: '9137');
    expect((await g2.verify('9137')).result, PinResult.ok);
  });

  test('TrustedClock never goes backwards and clears after server agreement', () {
    var t = 1000000;
    final c = TrustedClock(wall: () => t);
    expect(c.now(), 1000000);
    t = 999000;
    expect(c.now(), 1000000); expect(c.tampered, isTrue);
    c.onServerTime(999000);                       // server agrees with wall: flag cleared, but time never regresses
    expect(c.tampered, isFalse); expect(c.now(), 1000000);
  });

  test('ReceiveStore: stores pending before ack, rejects duplicates, survives restart, applies settlement', () async {
    final store = ReceiveStore(SealedRecord(env.vault, env.files, 'recv'));
    await store.open();
    // garbage bytes fail the structure check and store nothing
    ReceiverCtx dummy({required int pendingTotal, required Set<String> seenTx, required Set<String> seenWc}) =>
        ReceiverCtx(trustedIssuerKeys: {}, nowSec: 0, myWalletId: 'x', myMaxAccept: 1, pendingTotal: pendingTotal, pendingCap: 1);
    final r = await store.accept(Uint8List.fromList([1, 2, 3]), dummy, 0);
    expect(r.ok, isFalse); expect(r.verify.last.id, 'structure');
    expect(store.items, isEmpty);
    store.items.add(ReceivedItem(txId: 'aa', walletId: 'w', counter: 1, amount: 500, receivedAt: 1, tokenHex: '00'));
    await store.setMaxAccept(123);                                                 // forces a commit
    final s2 = ReceiveStore(SealedRecord(env.vault, env.files, 'recv'));
    await s2.open();
    expect(s2.pendingTotal, 500); expect(s2.maxAccept, 123);
    final changed = await s2.applySettleResults([{'txId': 'aa', 'status': 'settled'}, {'txId': 'zz', 'status': 'rejected'}]);
    expect(changed.single.status, 'settled'); expect(s2.pendingTotal, 0);
  });
}
