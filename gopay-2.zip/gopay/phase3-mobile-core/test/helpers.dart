import 'dart:typed_data';
import 'package:gopay_core/gopay_core.dart';

Uint8List seed(int b) => Uint8List.fromList(List.filled(32, b));
class Env {
  final vault = MemoryVault();
  final files = MemoryBlobStore();
  int t = 1800000000;
  int wall() => t;
}
