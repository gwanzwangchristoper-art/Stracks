// Canonical CBOR subset, byte-identical to phase2-backend/src/cbor.ts. Values: int, String, Uint8List, List, Map<int,Object?>.
// Mobile/VM only (uses 64-bit shifts).
import 'dart:convert';
import 'dart:typed_data';

class CborException implements Exception {
  final String message;
  CborException(this.message);
  @override
  String toString() => 'cbor: $message';
}

Uint8List cborEncode(Object? v) {
  final b = BytesBuilder();
  _enc(v, b);
  return b.toBytes();
}

void _head(BytesBuilder b, int major, int n) {
  final m = major << 5;
  if (n < 0) throw CborException('negative');
  if (n < 24) {
    b.addByte(m | n);
  } else if (n < 0x100) {
    b..addByte(m | 24)..addByte(n);
  } else if (n < 0x10000) {
    b..addByte(m | 25)..addByte(n >> 8)..addByte(n & 255);
  } else if (n <= 0xFFFFFFFF) {
    b.addByte(m | 26);
    for (var s = 24; s >= 0; s -= 8) { b.addByte((n >> s) & 255); }
  } else {
    b.addByte(m | 27);
    for (var s = 56; s >= 0; s -= 8) { b.addByte((n >> s) & 255); }
  }
}

void _enc(Object? v, BytesBuilder b) {
  if (v is int) {
    _head(b, 0, v);
  } else if (v is String) {
    final u = utf8.encode(v);
    _head(b, 3, u.length);
    b.add(u);
  } else if (v is Uint8List) {
    _head(b, 2, v.length);
    b.add(v);
  } else if (v is List) {
    _head(b, 4, v.length);
    for (final x in v) { _enc(x, b); }
  } else if (v is Map<int, Object?>) {
    _head(b, 5, v.length);
    for (final k in (v.keys.toList()..sort())) { _head(b, 0, k); _enc(v[k], b); }
  } else {
    throw CborException('unsupported type ${v.runtimeType}');
  }
}

Object? cborDecode(Uint8List buf) {
  final r = _Reader(buf);
  final v = r.item(0);
  if (r.p != buf.length) throw CborException('trailing bytes');
  return v;
}

class _Reader {
  final Uint8List buf;
  int p = 0;
  _Reader(this.buf);
  void need(int n) { if (p + n > buf.length) throw CborException('truncated'); }
  (int, int) head() {
    need(1);
    final b = buf[p++];
    final major = b >> 5, ai = b & 31;
    if (ai < 24) return (major, ai);
    final len = ai == 24 ? 1 : ai == 25 ? 2 : ai == 26 ? 4 : ai == 27 ? 8 : -1;
    if (len < 0) throw CborException('indefinite/reserved not allowed');
    need(len);
    var n = 0;
    for (var i = 0; i < len; i++) { n = (n << 8) | buf[p++]; }
    if (n < 0) throw CborException('uint too large');
    final min = len == 1 ? 24 : len == 2 ? 0x100 : len == 4 ? 0x10000 : 0x100000000;
    if (n < min) throw CborException('non-canonical integer');
    return (major, n);
  }
  Object? item(int depth) {
    if (depth > 8) throw CborException('too deep');
    final (major, n) = head();
    switch (major) {
      case 0: return n;
      case 2: need(n); final r = Uint8List.fromList(buf.sublist(p, p + n)); p += n; return r;
      case 3:
        need(n);
        final s = utf8.decode(buf.sublist(p, p + n), allowMalformed: false);
        p += n;
        return s;
      case 4:
        if (n > 64) throw CborException('array too long');
        return [for (var i = 0; i < n; i++) item(depth + 1)];
      case 5:
        if (n > 64) throw CborException('map too large');
        final m = <int, Object?>{};
        var last = -1;
        for (var i = 0; i < n; i++) {
          final k = item(depth + 1);
          if (k is! int) throw CborException('map key must be uint');
          if (k <= last) throw CborException('map keys not ascending/unique');
          last = k;
          m[k] = item(depth + 1);
        }
        return m;
      default: throw CborException('unsupported major type');
    }
  }
}
