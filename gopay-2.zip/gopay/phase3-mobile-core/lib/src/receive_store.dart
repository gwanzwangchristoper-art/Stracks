// Receiver side. Tokens are stored (sealed, encrypted) BEFORE the receipt is returned, so a receipt is never sent for money we could lose.
import 'dart:typed_data';
import 'crypto.dart';
import 'protocol.dart';
import 'sealed_record.dart';

class ReceivedItem {
  final String txId, walletId, tokenHex;
  final int counter, amount, receivedAt;
  String status; // pending | settled | rejected
  String? reason;
  ReceivedItem({required this.txId, required this.walletId, required this.counter, required this.amount, required this.receivedAt, required this.tokenHex, this.status = 'pending', this.reason});
  Map<String, Object?> toJson() => {'txId': txId, 'w': walletId, 'c': counter, 'a': amount, 'at': receivedAt, 'tok': tokenHex, 's': status, 'r': reason};
  static ReceivedItem fromJson(Map j) => ReceivedItem(txId: j['txId'] as String, walletId: j['w'] as String, counter: j['c'] as int, amount: j['a'] as int,
    receivedAt: j['at'] as int, tokenHex: j['tok'] as String, status: j['s'] as String, reason: j['r'] as String?);
}

class AcceptOutcome {
  final VerifyResult verify;
  final ReceivedItem? item;
  AcceptOutcome(this.verify, this.item);
  bool get ok => item != null;
}

class ReceiveStore {
  final SealedRecord rec;
  List<ReceivedItem> items = [];
  int maxAccept = 5000 * 100; // user setting, kobo
  bool tampered = false;
  ReceiveStore(this.rec);

  Future<SealStatus> open() async {
    final s = await rec.open();
    if (s == SealStatus.tampered) tampered = true;
    if (s == SealStatus.ok) {
      items = [for (final o in (rec.data['items'] as List? ?? [])) ReceivedItem.fromJson(o as Map)];
      maxAccept = rec.data['maxAccept'] as int? ?? maxAccept;
    }
    return s;
  }

  Set<String> get seenTxIds => {for (final i in items) i.txId};
  Set<String> get seenWalletCounters => {for (final i in items) '${i.walletId}:${i.counter}'};
  int get pendingTotal => items.where((i) => i.status == 'pending').fold(0, (a, i) => a + i.amount);
  List<ReceivedItem> get pending => items.where((i) => i.status == 'pending').toList();

  Future<void> _save() => rec.commit({'items': [for (final i in items) i.toJson()], 'maxAccept': maxAccept});
  Future<void> setMaxAccept(int kobo) async { maxAccept = kobo; await _save(); }

  /// Verify then persist as Pending. Only after this returns ok may the caller sign and send the receipt.
  Future<AcceptOutcome> accept(Uint8List bytes, ReceiverCtx Function({required int pendingTotal, required Set<String> seenTx, required Set<String> seenWc}) ctxFor, int now) async {
    if (tampered) throw StateError('Receive storage was restored or copied. Go online to fix it.');
    final r = verifyForReceiver(bytes, ctxFor(pendingTotal: pendingTotal, seenTx: seenTxIds, seenWc: seenWalletCounters));
    if (!r.ok) return AcceptOutcome(r, null);
    final p = r.token!.payload;
    final item = ReceivedItem(txId: hexOf(p.txId), walletId: p.walletId, counter: p.counter, amount: p.amount, receivedAt: now, tokenHex: hexOf(bytes));
    items.add(item);
    try { await _save(); } catch (e) { items.removeLast(); rethrow; }
    return AcceptOutcome(r, item);
  }

  /// Apply per-item results from POST /v1/sync/settle: [{txId, status, reason?}].
  Future<List<ReceivedItem>> applySettleResults(List<Map<String, Object?>> results) async {
    final changed = <ReceivedItem>[];
    for (final r in results) {
      final it = items.where((i) => i.txId == r['txId']).firstOrNull;
      if (it == null || it.status != 'pending') continue;
      it.status = r['status'] == 'rejected' ? 'rejected' : 'settled';
      it.reason = r['reason'] as String?;
      changed.add(it);
    }
    if (changed.isNotEmpty) await _save();
    return changed;
  }
}
