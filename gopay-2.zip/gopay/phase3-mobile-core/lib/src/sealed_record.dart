// Hardware-sealed, rollback-detecting record.
//
// Each commit: create key gN+1 -> encrypt -> atomically write file name.N+1 -> delete file N and key gN.
// The newest state is only decryptable by the newest Keystore key. Keystore keys are excluded from backups and never exist on a cloned device,
// so: restored backup (old file, key gone) or copied data (files, no keys) => cannot decrypt => TAMPERED => wallet locks and forces online re-verification.
// Crash safety: at every instant at least one (file, key) pair is complete.
import 'dart:convert';
import 'dart:typed_data';
import 'vault.dart';

enum SealStatus { fresh, ok, tampered }

class SealedRecord {
  final SecureVault vault;
  final BlobStore files;
  final String name;
  int _gen = 0;
  Future<void> _lock = Future.value();
  SealStatus status = SealStatus.fresh;
  Map<String, Object?> data = {};

  SealedRecord(this.vault, this.files, this.name);

  String _alias(int g) => 'gopay.seal.$name.g$g';
  String _file(int g) => '$name.$g.bin';
  Uint8List _aad(int g) => Uint8List.fromList(utf8.encode('$name|$g'));
  int? _genOf(String f) {
    final m = RegExp('^${RegExp.escape(name)}\\.(\\d+)\\.bin\$').firstMatch(f);
    return m == null ? null : int.parse(m.group(1)!);
  }

  Future<SealStatus> open() async {
    final gens = [for (final f in await files.list('$name.')) if (_genOf(f) != null) _genOf(f)!]..sort((a, b) => b.compareTo(a));
    if (gens.isEmpty) { status = SealStatus.fresh; data = {}; _gen = 0; return status; }
    for (final g in gens) {
      if (!await vault.hasKey(_alias(g))) continue;
      final blob = await files.read(_file(g));
      if (blob == null) continue;
      try {
        final plain = await vault.decrypt(_alias(g), blob, _aad(g));
        data = Map<String, Object?>.from(jsonDecode(utf8.decode(plain)) as Map);
        _gen = g;
        status = SealStatus.ok;
        await _cleanup(g, gens);
        return status;
      } on VaultException { continue; }
    }
    status = SealStatus.tampered; // files exist but no live key opens any of them
    data = {};
    return status;
  }

  Future<void> _cleanup(int keep, List<int> gens) async {
    for (final g in gens) { if (g != keep) { await files.delete(_file(g)); await vault.deleteKey(_alias(g)); } }
    await vault.deleteKey(_alias(keep + 1)); // key created by a commit that crashed before its file landed
  }

  /// Atomically replace the record. Serialised; state is unchanged if anything throws.
  Future<void> commit(Map<String, Object?> next) {
    final run = _lock.then((_) => _commit(next));
    _lock = run.catchError((_) {});
    return run;
  }

  Future<void> _commit(Map<String, Object?> next) async {
    if (status == SealStatus.tampered) throw StateError('record is tampered; re-verify online and reset');
    final g = _gen + 1;
    await vault.createKey(_alias(g));
    try {
      final blob = await vault.encrypt(_alias(g), Uint8List.fromList(utf8.encode(jsonEncode(next))), _aad(g));
      await files.writeAtomic(_file(g), blob);
    } catch (_) {
      await vault.deleteKey(_alias(g));
      rethrow;
    }
    final old = _gen;
    _gen = g;
    data = Map<String, Object?>.from(next);
    status = SealStatus.ok;
    if (old > 0) { await files.delete(_file(old)); await vault.deleteKey(_alias(old)); }
  }

  /// After a tamper lock, the app must re-register online. This wipes the dead record so a new wallet can start.
  Future<void> resetAfterOnlineReverification() async {
    for (final f in await files.list('$name.')) { await files.delete(f); }
    _gen = 0; data = {}; status = SealStatus.fresh;
  }
}
