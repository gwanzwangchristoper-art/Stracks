import 'dart:typed_data';
import 'package:crypto/crypto.dart' as c;
import 'package:pointycastle/export.dart';

Uint8List sha256(List<int> data) => Uint8List.fromList(c.sha256.convert(data).bytes);
String hexOf(List<int> b) => b.map((x) => x.toRadixString(16).padLeft(2, '0')).join();
Uint8List unhex(String s) => Uint8List.fromList([for (var i = 0; i < s.length; i += 2) int.parse(s.substring(i, i + 2), radix: 16)]);
Uint8List cat(List<List<int>> parts) => Uint8List.fromList([for (final p in parts) ...p]);
String keyIdOf(Uint8List rawPub) => hexOf(sha256(rawPub)).substring(0, 16);

final ECDomainParameters _p256 = ECCurve_secp256r1();
BigInt _big(List<int> b) => b.fold(BigInt.zero, (a, x) => (a << 8) | BigInt.from(x));
Uint8List _be32(BigInt v) {
  final out = Uint8List(32);
  var x = v;
  for (var i = 31; i >= 0; i--) { out[i] = (x & BigInt.from(255)).toInt(); x = x >> 8; }
  return out;
}

/// ECDSA P-256 / SHA-256 verify. [sig64] is raw r||s. Never throws.
bool p256Verify(Uint8List pub65, Uint8List message, Uint8List sig64) {
  if (pub65.length != 65 || pub65[0] != 4 || sig64.length != 64) return false;
  try {
    final q = _p256.curve.decodePoint(pub65);
    if (q == null) return false;
    final signer = ECDSASigner(SHA256Digest())..init(false, PublicKeyParameter<ECPublicKey>(ECPublicKey(q, _p256)));
    return signer.verifySignature(message, ECSignature(_big(sig64.sublist(0, 32)), _big(sig64.sublist(32))));
  } catch (_) {
    return false;
  }
}

/// Signs [message] (not a hash) with ECDSA P-256/SHA-256 and returns raw r||s.
/// Production implementation: hardware key via platform channel (see KeystoreSigner in vault.dart).
abstract class DeviceSigner {
  Future<Uint8List> publicKey();
  Future<Uint8List> sign(Uint8List message, {required String prompt});
}

/// TEST ONLY. Software key from a 32-byte scalar. Never use in production.
class SoftwareSigner implements DeviceSigner {
  final ECPrivateKey _priv;
  final Uint8List _pub;
  SoftwareSigner._(this._priv, this._pub);
  factory SoftwareSigner.fromSeed(Uint8List d32) {
    final d = _big(d32);
    final q = (_p256.G * d)!;
    return SoftwareSigner._(ECPrivateKey(d, _p256), q.getEncoded(false));
  }
  @override
  Future<Uint8List> publicKey() async => _pub;
  @override
  Future<Uint8List> sign(Uint8List message, {required String prompt}) async {
    final s = ECDSASigner(SHA256Digest(), HMacDSAKCalculator(SHA256Digest()))..init(true, PrivateKeyParameter<ECPrivateKey>(_priv));
    final sig = s.generateSignature(message) as ECSignature;
    return Uint8List.fromList([..._be32(sig.r), ..._be32(sig.s)]);
  }
}
