// 4-digit PIN: salted PBKDF2, 3 failures then lock until a SERVER-SIDE unlock (OTP). Counter lives in a sealed record so it cannot be reset by reinstalling or restoring a backup.
import 'dart:math';
import 'dart:typed_data';
import 'package:pointycastle/export.dart';
import 'crypto.dart';
import 'sealed_record.dart';

enum PinResult { ok, wrong, locked }

class PinOutcome {
  final PinResult result;
  final int attemptsLeft;
  const PinOutcome(this.result, this.attemptsLeft);
}

class PinGuard {
  static const maxFails = 3;
  final SealedRecord rec;
  final int iterations;
  String? _saltHex, _hashHex;
  int fails = 0;
  bool locked = false;

  PinGuard(this.rec, {this.iterations = 60000});

  bool get isSet => _hashHex != null;

  Future<void> open() async {
    await rec.open();
    final d = rec.data;
    _saltHex = d['salt'] as String?; _hashHex = d['hash'] as String?; fails = d['fails'] as int? ?? 0; locked = d['locked'] as bool? ?? false;
    if (rec.status == SealStatus.tampered) { locked = true; } // restored data: treat as locked until server unlock
  }

  Uint8List _hash(String pin, Uint8List salt) {
    final k = PBKDF2KeyDerivator(HMac(SHA256Digest(), 64))..init(Pbkdf2Parameters(salt, iterations, 32));
    return k.process(Uint8List.fromList(pin.codeUnits));
  }

  Future<void> _save() => rec.commit({'salt': _saltHex, 'hash': _hashHex, 'fails': fails, 'locked': locked});

  Future<void> setPin(String pin) async {
    if (!RegExp(r'^\d{4}$').hasMatch(pin)) throw ArgumentError('PIN must be 4 digits');
    final r = Random.secure();
    final salt = Uint8List.fromList(List.generate(16, (_) => r.nextInt(256)));
    _saltHex = hexOf(salt); _hashHex = hexOf(_hash(pin, salt)); fails = 0; locked = false;
    await _save();
  }

  Future<PinOutcome> verify(String pin) async {
    if (locked) return const PinOutcome(PinResult.locked, 0);
    final got = _hash(pin, unhex(_saltHex!));
    final want = unhex(_hashHex!);
    var diff = 0;
    for (var i = 0; i < want.length; i++) { diff |= got[i] ^ want[i]; } // constant time
    if (diff == 0) { if (fails != 0) { fails = 0; await _save(); } return const PinOutcome(PinResult.ok, maxFails); }
    fails++;
    if (fails >= maxFails) locked = true;
    await _save(); // persist BEFORE answering so killing the app cannot reset the counter
    return PinOutcome(locked ? PinResult.locked : PinResult.wrong, maxFails - fails);
  }

  /// Only after the server confirmed an OTP-based unlock (POST /v1/auth/pin/unlock).
  Future<void> serverUnlock({String? newPin}) async {
    if (rec.status == SealStatus.tampered) {
      if (newPin == null) throw ArgumentError('new PIN required after restore/clone');
      await rec.resetAfterOnlineReverification();
    }
    locked = false; fails = 0;
    if (newPin != null) { await setPin(newPin); } else if (_hashHex != null) { await _save(); }
  }
}
