// Hardware-backed primitives, implemented natively (Kotlin: Android Keystore/StrongBox, Swift: Secure Enclave + Keychain).
// Dart sees only these interfaces, so everything above is unit-testable with MemoryVault.
import 'dart:io';
import 'dart:math';
import 'dart:typed_data';
import 'package:flutter/services.dart';
import 'package:pointycastle/export.dart';
import 'crypto.dart';
import 'der.dart';

class VaultException implements Exception {
  final String message;
  VaultException(this.message);
  @override
  String toString() => 'vault: $message';
}

/// Non-exportable AES-256-GCM keys by alias. Keys are NOT in OS backups and do not move between devices.
abstract class SecureVault {
  Future<void> createKey(String alias);
  Future<void> deleteKey(String alias);
  Future<bool> hasKey(String alias);
  Future<Uint8List> encrypt(String alias, Uint8List plain, Uint8List aad);
  Future<Uint8List> decrypt(String alias, Uint8List blob, Uint8List aad); // throws VaultException
}

/// Atomic file storage. Real: write tmp + fsync + rename in no-backup dir. Test: map.
abstract class BlobStore {
  Future<Uint8List?> read(String name);
  Future<void> writeAtomic(String name, Uint8List bytes);
  Future<void> delete(String name);
  Future<List<String>> list(String prefix);
}

class MemoryBlobStore implements BlobStore {
  final Map<String, Uint8List> files = {};
  @override
  Future<Uint8List?> read(String n) async => files[n];
  @override
  Future<void> writeAtomic(String n, Uint8List b) async => files[n] = Uint8List.fromList(b);
  @override
  Future<void> delete(String n) async => files.remove(n);
  @override
  Future<List<String>> list(String p) async => files.keys.where((k) => k.startsWith(p)).toList();
}

class IoBlobStore implements BlobStore {
  final Directory dir; // use getApplicationSupportDirectory() on a path excluded from backup (see android-native/README)
  IoBlobStore(this.dir);
  File _f(String n) => File('${dir.path}/$n');
  @override
  Future<Uint8List?> read(String n) async => await _f(n).exists() ? await _f(n).readAsBytes() : null;
  @override
  Future<void> writeAtomic(String n, Uint8List b) async {
    final tmp = _f('$n.tmp');
    final raf = await tmp.open(mode: FileMode.write);
    await raf.writeFrom(b);
    await raf.flush(); // fsync
    await raf.close();
    await tmp.rename(_f(n).path); // atomic on POSIX
  }
  @override
  Future<void> delete(String n) async { if (await _f(n).exists()) await _f(n).delete(); }
  @override
  Future<List<String>> list(String p) async =>
      [for (final e in dir.listSync()) if (e is File) e.uri.pathSegments.last].where((n) => n.startsWith(p) && !n.endsWith('.tmp')).toList();
}

/// Production vault over the platform channel `gopay/keystore`.
class PlatformVault implements SecureVault {
  static const _ch = MethodChannel('gopay/keystore');
  @override
  Future<void> createKey(String a) async { await _ch.invokeMethod('createAesKey', {'alias': a}); }
  @override
  Future<void> deleteKey(String a) async { await _ch.invokeMethod('deleteKey', {'alias': a}); }
  @override
  Future<bool> hasKey(String a) async => (await _ch.invokeMethod<bool>('hasKey', {'alias': a})) ?? false;
  @override
  Future<Uint8List> encrypt(String a, Uint8List p, Uint8List aad) async =>
      (await _ch.invokeMethod<Uint8List>('encrypt', {'alias': a, 'data': p, 'aad': aad}))!;
  @override
  Future<Uint8List> decrypt(String a, Uint8List b, Uint8List aad) async {
    try { return (await _ch.invokeMethod<Uint8List>('decrypt', {'alias': a, 'data': b, 'aad': aad}))!; }
    on PlatformException catch (e) { throw VaultException(e.code); }
  }
}

/// Production device signer: P-256 key in StrongBox/Keystore/Secure Enclave, user authentication required for every signature.
class KeystoreSigner implements DeviceSigner {
  static const _ch = MethodChannel('gopay/keystore');
  final String alias;
  KeystoreSigner([this.alias = 'gopay.device.v1']);
  Future<Uint8List> ensureKey() async => (await _ch.invokeMethod<Uint8List>('ensureSigningKey', {'alias': alias}))!;
  @override
  Future<Uint8List> publicKey() => ensureKey();
  @override
  Future<Uint8List> sign(Uint8List message, {required String prompt}) async {
    final der = (await _ch.invokeMethod<Uint8List>('sign', {'alias': alias, 'data': message, 'prompt': prompt}))!; // shows biometric/device-credential prompt
    return derToRaw(der);
  }
  /// Play Integrity token (Android) / App Attest assertion (iOS) bound to [nonce].
  Future<String> attest(String nonce) async => (await _ch.invokeMethod<String>('attest', {'nonce': nonce}))!;
}

/// TEST ONLY: AES-GCM in software with a key table that behaves like a Keystore (no export, can be wiped).
class MemoryVault implements SecureVault {
  final Map<String, Uint8List> keys = {};
  final _rnd = Random.secure();
  @override
  Future<void> createKey(String a) async => keys[a] = Uint8List.fromList(List.generate(32, (_) => _rnd.nextInt(256)));
  @override
  Future<void> deleteKey(String a) async => keys.remove(a);
  @override
  Future<bool> hasKey(String a) async => keys.containsKey(a);
  @override
  Future<Uint8List> encrypt(String a, Uint8List p, Uint8List aad) async {
    final k = keys[a] ?? (throw VaultException('no_key'));
    final iv = Uint8List.fromList(List.generate(12, (_) => _rnd.nextInt(256)));
    final c = GCMBlockCipher(AESEngine())..init(true, AEADParameters(KeyParameter(k), 128, iv, aad));
    return Uint8List.fromList([...iv, ...c.process(p)]);
  }
  @override
  Future<Uint8List> decrypt(String a, Uint8List b, Uint8List aad) async {
    final k = keys[a] ?? (throw VaultException('no_key'));
    try {
      final c = GCMBlockCipher(AESEngine())..init(false, AEADParameters(KeyParameter(k), 128, b.sublist(0, 12), aad));
      return c.process(b.sublist(12));
    } catch (_) { throw VaultException('bad_tag'); }
  }
}
