// Clock-tamper resistance. Never goes backwards; remembers the largest time ever seen (wall or server).
// If the wall clock is found earlier than that, the wallet is flagged and refuses to sign until it syncs with the server.
import 'dart:math';

class TrustedClock {
  final int Function() wall; // unix seconds, injectable for tests
  int lastServerTime;
  int lastSeen;
  bool tampered;
  static const rollbackTolerance = 120;
  static const syncTolerance = 300;

  TrustedClock({required this.wall, this.lastServerTime = 0, this.lastSeen = 0, this.tampered = false});

  factory TrustedClock.fromJson(Map<String, Object?> j, int Function() wall) => TrustedClock(
      wall: wall, lastServerTime: (j['server'] as int?) ?? 0, lastSeen: (j['seen'] as int?) ?? 0, tampered: (j['tampered'] as bool?) ?? false);
  Map<String, Object?> toJson() => {'server': lastServerTime, 'seen': lastSeen, 'tampered': tampered};

  int now() {
    final w = wall();
    if (w + rollbackTolerance < lastSeen) tampered = true;
    final n = max(w, max(lastSeen, lastServerTime));
    lastSeen = n;
    return n;
  }

  /// Call whenever the server tells us the time (any API response).
  void onServerTime(int server) {
    final w = wall();
    lastServerTime = max(lastServerTime, server);
    lastSeen = max(lastSeen, server);
    if ((w - server).abs() <= syncTolerance) tampered = false;
  }
}
