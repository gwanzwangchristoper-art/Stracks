// Platform keystores return ECDSA signatures as ASN.1 DER; the protocol uses raw r||s (64 bytes).
import 'dart:typed_data';

Uint8List derToRaw(Uint8List der) {
  var p = 0;
  int len() {
    var l = der[p++];
    if (l & 0x80 != 0) { final n = l & 0x7f; l = 0; for (var i = 0; i < n; i++) { l = (l << 8) | der[p++]; } }
    return l;
  }
  if (der.isEmpty || der[p++] != 0x30) throw const FormatException('der: not a sequence');
  len();
  Uint8List readInt() {
    if (der[p++] != 0x02) throw const FormatException('der: not an integer');
    final l = len();
    var b = der.sublist(p, p + l);
    p += l;
    while (b.length > 1 && b[0] == 0) { b = b.sublist(1); }
    if (b.length > 32) throw const FormatException('der: integer too long');
    final out = Uint8List(32)..setRange(32 - b.length, 32, b);
    return out;
  }
  final r = readInt(), s = readInt();
  return Uint8List.fromList([...r, ...s]);
}

Uint8List rawToDer(Uint8List raw) {
  Uint8List enc(Uint8List x) {
    var i = 0;
    while (i < x.length - 1 && x[i] == 0) { i++; }
    var b = x.sublist(i);
    if (b[0] & 0x80 != 0) b = Uint8List.fromList([0, ...b]);
    return Uint8List.fromList([0x02, b.length, ...b]);
  }
  final r = enc(raw.sublist(0, 32)), s = enc(raw.sublist(32));
  return Uint8List.fromList([0x30, r.length + s.length, ...r, ...s]);
}
