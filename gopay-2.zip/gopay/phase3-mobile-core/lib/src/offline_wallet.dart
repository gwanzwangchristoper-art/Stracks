// Payer side. Order of operations for every payment (see ARCHITECTURE.md):
//   preflight -> local auth -> hardware sign -> atomic sealed commit (counter, cumulative, outbox) -> release token.
// A token that was signed but not committed is never released, so a crash can never create a double spend.
import 'dart:async';
import 'dart:math';
import 'dart:typed_data';
import 'clock.dart';
import 'crypto.dart';
import 'protocol.dart';
import 'sealed_record.dart';

class PayError implements Exception {
  final String code, message;
  PayError(this.code, this.message);
  @override
  String toString() => message;
}

class OutboxEntry {
  final String txId, receiverRef, payloadHex, tokenHex;
  final int amount, counter, createdAt, expiresAt;
  String status; // prepared | acked
  OutboxEntry({required this.txId, required this.receiverRef, required this.payloadHex, required this.tokenHex, required this.amount,
    required this.counter, required this.createdAt, required this.expiresAt, this.status = 'prepared'});
  Map<String, Object?> toJson() => {'txId': txId, 'to': receiverRef, 'payload': payloadHex, 'token': tokenHex, 'amount': amount, 'counter': counter,
    'createdAt': createdAt, 'expiresAt': expiresAt, 'status': status};
  static OutboxEntry fromJson(Map j) => OutboxEntry(txId: j['txId'] as String, receiverRef: j['to'] as String, payloadHex: j['payload'] as String,
    tokenHex: j['token'] as String, amount: j['amount'] as int, counter: j['counter'] as int, createdAt: j['createdAt'] as int,
    expiresAt: j['expiresAt'] as int, status: j['status'] as String);
}

class OfflineWallet {
  final SealedRecord rec;
  final DeviceSigner signer;
  final TrustedClock clock;
  final Random _rng;
  Future<void> _payLock = Future.value();

  String? walletId;
  Uint8List? certBlob;
  Certificate? cert;
  int counter = 0, cumulative = 0, unsynced = 0;
  bool locked = false;
  String? lockReason; // tampered | frozen | clock
  Map<String, String> issuerKeysHex = {};
  List<OutboxEntry> outbox = [];

  OfflineWallet(this.rec, this.signer, this.clock, {Random? rng}) : _rng = rng ?? Random.secure();

  Map<String, Uint8List> get issuerKeys => {for (final e in issuerKeysHex.entries) e.key: unhex(e.value)};
  int get remaining => cert == null ? 0 : cert!.spendCeiling - cumulative;

  /// Opens the sealed record. If it was restored/cloned the wallet locks (cannot sign) until online re-verification.
  Future<SealStatus> open() async {
    final s = await rec.open();
    if (s == SealStatus.tampered) { locked = true; lockReason = 'tampered'; return s; }
    if (s == SealStatus.ok) _fromJson(rec.data);
    return s;
  }

  void _fromJson(Map<String, Object?> j) {
    walletId = j['walletId'] as String?;
    final ch = j['cert'] as String?;
    if (ch != null) { certBlob = unhex(ch); cert = ParsedCert.parse(certBlob!).cert; }
    counter = j['counter'] as int? ?? 0; cumulative = j['cumulative'] as int? ?? 0; unsynced = j['unsynced'] as int? ?? 0;
    locked = j['locked'] as bool? ?? false; lockReason = j['lockReason'] as String?;
    issuerKeysHex = Map<String, String>.from((j['issuerKeys'] as Map?) ?? {});
    outbox = [for (final o in (j['outbox'] as List? ?? [])) OutboxEntry.fromJson(o as Map)];
    clock.lastServerTime = j['clockServer'] as int? ?? clock.lastServerTime;
    clock.lastSeen = j['clockSeen'] as int? ?? clock.lastSeen;
    clock.tampered = j['clockTampered'] as bool? ?? false;
  }

  Map<String, Object?> _toJson() => {
    'walletId': walletId, 'cert': certBlob == null ? null : hexOf(certBlob!), 'counter': counter, 'cumulative': cumulative, 'unsynced': unsynced,
    'locked': locked, 'lockReason': lockReason, 'issuerKeys': issuerKeysHex, 'outbox': [for (final o in outbox) o.toJson()],
    'clockServer': clock.lastServerTime, 'clockSeen': clock.lastSeen, 'clockTampered': clock.tampered,
  };
  Future<void> _save() => rec.commit(_toJson());

  /// After register / load / refresh. A new walletId starts counters at zero.
  Future<void> installCertificate(Uint8List blob, {required int serverTime, Map<String, String>? issuerKeys}) async {
    final p = ParsedCert.parse(blob);
    if (walletId != p.cert.walletId) { walletId = p.cert.walletId; counter = 0; cumulative = 0; unsynced = 0; }
    certBlob = blob; cert = p.cert;
    if (issuerKeys != null) issuerKeysHex = issuerKeys;
    clock.onServerTime(serverTime);
    if (lockReason == 'clock' && !clock.tampered) { locked = false; lockReason = null; }
    await _save();
  }

  /// Call after a successful online sync (settle upload + blocklist + certificate refresh).
  Future<void> markSynced(int serverTime) async { unsynced = 0; clock.onServerTime(serverTime); await _save(); }

  /// Apply the server blocklist. If our own wallet was frozen, stop signing.
  Future<void> applyBlocklist(Set<String> blockedWallets) async {
    if (walletId != null && blockedWallets.contains(walletId)) { locked = true; lockReason = 'frozen'; await _save(); }
  }

  void _preflight(int amount, int now) {
    if (locked) throw PayError(lockReason ?? 'locked', lockReason == 'tampered' ? 'Wallet locked for safety. Go online to fix it.' : 'Wallet locked. Go online or contact support.');
    if (clock.tampered) throw PayError('clock', 'Phone clock looks wrong. Fix the time or go online.');
    final c = cert;
    if (c == null || walletId == null) throw PayError('no_wallet', 'Load money first.');
    if (now > c.expiresAt) throw PayError('cert_expired', 'Offline wallet expired. Go online to refresh.');
    if (amount <= 0) throw PayError('bad_amount', 'Enter an amount.');
    if (amount > c.perTxMax) throw PayError('over_limit', 'Over your limit per payment.');
    if (cumulative + amount > c.spendCeiling) throw PayError('over_balance', 'Not enough in your Offline Wallet.');
    if (unsynced >= c.maxUnsynced) throw PayError('too_many_unsynced', 'Go online to sync before paying more.');
  }

  Uint8List _rand(int n) => Uint8List.fromList(List.generate(n, (_) => _rng.nextInt(256)));

  /// [authorize] shows the PIN pad / biometric and returns true on success. The hardware key also demands user authentication.
  Future<OutboxEntry> pay({required String receiverRef, required int amount, required Future<bool> Function() authorize, String currency = 'NGN'}) {
    final run = _payLock.then((_) => _pay(receiverRef, amount, authorize, currency));
    _payLock = run.then((_) {}, onError: (_) {});
    return run;
  }

  Future<OutboxEntry> _pay(String receiverRef, int amount, Future<bool> Function() authorize, String currency) async {
    _preflight(amount, clock.now());
    if (!await authorize()) throw PayError('auth_failed', 'Could not confirm. Try again.');
    final now = clock.now();
    _preflight(amount, now); // re-check after the human delay
    final c = cert!;
    final payload = Payload(txId: _rand(16), walletId: walletId!, receiverRef: receiverRef, amount: amount, counter: counter + 1,
      cumulativeSpent: cumulative + amount, createdAt: now, expiresAt: min(now + 900, c.expiresAt), nonce: _rand(8), currency: currency);
    final token = await buildToken(signer, certBlob!, payload);      // may throw if the user cancels: nothing has changed yet
    final entry = OutboxEntry(txId: hexOf(payload.txId), receiverRef: receiverRef, payloadHex: hexOf(payload.encode()), tokenHex: hexOf(token),
      amount: amount, counter: payload.counter, createdAt: now, expiresAt: payload.expiresAt);
    final prev = (counter, cumulative, unsynced, List.of(outbox));
    counter = payload.counter; cumulative = payload.cumulativeSpent; unsynced++; outbox.add(entry);
    try { await _save(); } catch (e) { (counter, cumulative, unsynced, outbox) = prev; rethrow; } // commit failed: token is discarded, never released
    return entry;
  }

  /// Same token bytes again (interrupted NFC/QR). Only until the token expires or is acknowledged.
  Uint8List? reshow(String txId) {
    final e = outbox.where((o) => o.txId == txId).firstOrNull;
    if (e == null || e.status == 'acked' || clock.now() > e.expiresAt) return null;
    return unhex(e.tokenHex);
  }

  Future<bool> acceptReceipt(Uint8List receipt) async {
    for (final e in outbox.where((o) => o.status == 'prepared')) {
      final t = ParsedToken.parse(unhex(e.tokenHex));
      if (verifyReceipt(receipt, issuerKeys, t)) { e.status = 'acked'; await _save(); return true; }
    }
    return false;
  }

  /// Receipts are kept until the server confirms settlement; entries older than [keepSec] and acked can be dropped to save space.
  Future<void> prune(int keepSec) async {
    final now = clock.now();
    outbox.removeWhere((e) => e.status == 'acked' && now - e.createdAt > keepSec);
    await _save();
  }
}
