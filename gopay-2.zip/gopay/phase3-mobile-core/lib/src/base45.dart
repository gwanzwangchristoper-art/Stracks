// RFC 9285 Base45.
import 'dart:typed_data';

const _a = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ \$%*+-./:';

String base45Encode(Uint8List b) {
  final s = StringBuffer();
  for (var i = 0; i < b.length; i += 2) {
    if (i + 1 < b.length) {
      final n = b[i] * 256 + b[i + 1];
      s..write(_a[n % 45])..write(_a[(n ~/ 45) % 45])..write(_a[n ~/ 2025]);
    } else {
      final n = b[i];
      s..write(_a[n % 45])..write(_a[n ~/ 45]);
    }
  }
  return s.toString();
}

Uint8List base45Decode(String s) {
  final v = <int>[];
  for (final c in s.split('')) {
    final i = _a.indexOf(c);
    if (i < 0) throw const FormatException('base45: bad char');
    v.add(i);
  }
  final out = <int>[];
  for (var i = 0; i < v.length; i += 3) {
    if (i + 2 < v.length) {
      final n = v[i] + v[i + 1] * 45 + v[i + 2] * 2025;
      if (n > 65535) throw const FormatException('base45: overflow');
      out..add(n >> 8)..add(n & 255);
    } else if (i + 1 < v.length) {
      final n = v[i] + v[i + 1] * 45;
      if (n > 255) throw const FormatException('base45: overflow');
      out.add(n);
    } else {
      throw const FormatException('base45: bad length');
    }
  }
  return Uint8List.fromList(out);
}
