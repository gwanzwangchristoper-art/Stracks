// Dart port of phase2-backend/src/protocol.ts. Verified against phase1-architecture/test-vectors/vectors.json.
import 'dart:typed_data';
import 'cbor.dart';
import 'crypto.dart';

const protocolVersion = 1;
final _dsCert = Uint8List.fromList('GOPAY1-CERT'.codeUnits);
final _dsToken = Uint8List.fromList('GOPAY1-TOKEN'.codeUnits);
final _dsReceipt = Uint8List.fromList('GOPAY1-RECEIPT'.codeUnits);

T _f<T>(Map<int, Object?> m, int k, {int? len}) {
  final v = m[k];
  if (v is! T) throw FormatException('field $k missing/wrong type');
  if (len != null && v is Uint8List && v.length != len) throw FormatException('field $k bad length');
  return v;
}

Map<int, Object?> _map(Object? v) {
  if (v is! Map<int, Object?>) throw const FormatException('expected map');
  return v;
}

class Certificate {
  final String walletId, attestationRef, currency, issuerKeyId;
  final Uint8List devicePubKey;
  final int spendCeiling, perTxMax, expiresAt, issuedAt, maxUnsynced;
  Certificate({required this.walletId, required this.devicePubKey, required this.attestationRef, required this.currency, required this.spendCeiling,
    required this.perTxMax, required this.expiresAt, required this.issuerKeyId, required this.issuedAt, required this.maxUnsynced});
  static Certificate decode(Uint8List b) {
    final m = _map(cborDecode(b));
    if (_f<int>(m, 1) != protocolVersion) throw const FormatException('unsupported cert version');
    return Certificate(walletId: _f(m, 2), devicePubKey: _f<Uint8List>(m, 3, len: 65), attestationRef: _f(m, 4), currency: _f(m, 5), spendCeiling: _f(m, 6),
      perTxMax: _f(m, 7), expiresAt: _f(m, 8), issuerKeyId: _f(m, 9), issuedAt: _f(m, 10), maxUnsynced: _f(m, 11));
  }
}

class ParsedCert {
  final Uint8List certBytes, sig;
  final Certificate cert;
  ParsedCert(this.certBytes, this.sig, this.cert);
  static ParsedCert parse(Uint8List blob) {
    final a = cborDecode(blob);
    if (a is! List || a.length != 2 || a[0] is! Uint8List || a[1] is! Uint8List) throw const FormatException('bad cert blob');
    return ParsedCert(a[0] as Uint8List, a[1] as Uint8List, Certificate.decode(a[0] as Uint8List));
  }
}

class Payload {
  final Uint8List txId, nonce;
  final String walletId, receiverRef, currency;
  final int amount, counter, cumulativeSpent, createdAt, expiresAt;
  Payload({required this.txId, required this.walletId, required this.receiverRef, required this.amount, required this.counter,
    required this.cumulativeSpent, required this.createdAt, required this.expiresAt, required this.nonce, required this.currency});
  Uint8List encode() => cborEncode(<int, Object?>{1: protocolVersion, 2: txId, 3: walletId, 4: receiverRef, 5: amount, 6: counter,
    7: cumulativeSpent, 8: createdAt, 9: expiresAt, 10: nonce, 11: currency});
  static Payload decode(Uint8List b) {
    final m = _map(cborDecode(b));
    if (_f<int>(m, 1) != protocolVersion) throw const FormatException('unsupported token version');
    return Payload(txId: _f<Uint8List>(m, 2, len: 16), walletId: _f(m, 3), receiverRef: _f(m, 4), amount: _f(m, 5), counter: _f(m, 6),
      cumulativeSpent: _f(m, 7), createdAt: _f(m, 8), expiresAt: _f(m, 9), nonce: _f<Uint8List>(m, 10, len: 8), currency: _f(m, 11));
  }
}

class ParsedToken {
  final Uint8List certBlob, payloadBytes, sig;
  final ParsedCert certParsed;
  final Payload payload;
  ParsedToken(this.certBlob, this.payloadBytes, this.sig, this.certParsed, this.payload);
  Certificate get cert => certParsed.cert;
  static ParsedToken parse(Uint8List b) {
    final a = cborDecode(b);
    if (a is! List || a.length != 3 || a.any((x) => x is! Uint8List)) throw const FormatException('bad token');
    final cb = a[0] as Uint8List, pb = a[1] as Uint8List, s = a[2] as Uint8List;
    return ParsedToken(cb, pb, s, ParsedCert.parse(cb), Payload.decode(pb));
  }
  bool verifyPayerSig() => p256Verify(cert.devicePubKey, cat([_dsToken, certBlob, payloadBytes]), sig);
}

/// token = CBOR[certBlob, payloadBytes, sig]. The signer is the hardware key in production.
Future<Uint8List> buildToken(DeviceSigner signer, Uint8List certBlob, Payload p, {String prompt = 'Confirm payment'}) async {
  final pb = p.encode();
  final s = await signer.sign(cat([_dsToken, certBlob, pb]), prompt: prompt);
  return cborEncode([certBlob, pb, s]);
}

class Receipt {
  final Uint8List txId;
  final String receiverWalletId;
  final int amount, receivedAt;
  Receipt(this.txId, this.receiverWalletId, this.amount, this.receivedAt);
  Uint8List encode() => cborEncode(<int, Object?>{1: protocolVersion, 2: txId, 3: receiverWalletId, 4: amount, 5: receivedAt});
}

Future<Uint8List> signReceipt(DeviceSigner signer, Uint8List receiverCertBlob, Receipt r) async {
  final rb = r.encode();
  return cborEncode([rb, await signer.sign(cat([_dsReceipt, rb]), prompt: 'Confirm receipt'), receiverCertBlob]);
}

/// Payer-side check that the receiver acknowledged this exact token.
bool verifyReceipt(Uint8List blob, Map<String, Uint8List> trustedKeys, ParsedToken token) {
  try {
    final a = cborDecode(blob);
    if (a is! List || a.length != 3) return false;
    final rb = a[0] as Uint8List, s = a[1] as Uint8List, cb = a[2] as Uint8List;
    final cp = ParsedCert.parse(cb);
    final issuer = trustedKeys[cp.cert.issuerKeyId];
    if (issuer == null || !p256Verify(issuer, cat([_dsCert, cp.certBytes]), cp.sig)) return false;
    if (!p256Verify(cp.cert.devicePubKey, cat([_dsReceipt, rb]), s)) return false;
    final m = _map(cborDecode(rb));
    return hexOf(_f<Uint8List>(m, 2, len: 16)) == hexOf(token.payload.txId) && _f<String>(m, 3) == token.payload.receiverRef &&
        cp.cert.walletId == token.payload.receiverRef && _f<int>(m, 4) == token.payload.amount;
  } catch (_) {
    return false;
  }
}

// ---- receiver pipeline (spec section 6), identical order to the TypeScript reference
class ReceiverCtx {
  final Map<String, Uint8List> trustedIssuerKeys;
  final int nowSec, maxClockSkew, myMaxAccept, pendingTotal, pendingCap;
  final Set<String> blockedWallets, blockedDeviceKeyIds, seenTxIds, seenWalletCounters;
  final String myWalletId, myCurrency;
  ReceiverCtx({required this.trustedIssuerKeys, required this.nowSec, this.maxClockSkew = 300, this.blockedWallets = const {}, this.blockedDeviceKeyIds = const {},
    required this.myWalletId, this.myCurrency = 'NGN', required this.myMaxAccept, required this.pendingTotal, required this.pendingCap,
    this.seenTxIds = const {}, this.seenWalletCounters = const {}});
}

class Check {
  final String id;
  final bool ok;
  final String? detail;
  const Check(this.id, this.ok, [this.detail]);
}

class VerifyResult {
  final bool ok;
  final List<Check> checks;
  final ParsedToken? token;
  VerifyResult(this.ok, this.checks, this.token);
  Check get last => checks.last;
}

VerifyResult verifyForReceiver(Uint8List bytes, ReceiverCtx c) {
  final checks = <Check>[];
  VerifyResult fail(String id, String d) { checks.add(Check(id, false, d)); return VerifyResult(false, checks, null); }
  void pass(String id) => checks.add(Check(id, true));
  ParsedToken t;
  try { t = ParsedToken.parse(bytes); } catch (e) { return fail('structure', e.toString()); }
  final cert = t.cert, p = t.payload;
  pass('structure');
  final issuer = c.trustedIssuerKeys[cert.issuerKeyId];
  if (issuer == null) return fail('issuer_trusted', 'unknown issuer key');
  pass('issuer_trusted');
  if (!p256Verify(issuer, cat([_dsCert, t.certParsed.certBytes]), t.certParsed.sig)) return fail('issuer_signature', 'certificate signature invalid');
  pass('issuer_signature');
  if (cert.walletId != p.walletId) return fail('cert_valid_time', 'wallet mismatch');
  if (c.nowSec > cert.expiresAt) return fail('cert_valid_time', 'certificate expired');
  if (cert.issuedAt > c.nowSec + c.maxClockSkew) return fail('cert_valid_time', 'certificate from the future');
  pass('cert_valid_time');
  if (c.blockedWallets.contains(cert.walletId) || c.blockedDeviceKeyIds.contains(keyIdOf(cert.devicePubKey))) return fail('not_blocklisted', 'payer is blocked');
  pass('not_blocklisted');
  if (!t.verifyPayerSig()) return fail('payer_signature', 'payer signature invalid');
  pass('payer_signature');
  if (p.receiverRef != c.myWalletId) return fail('bound_to_receiver', 'token is for another receiver');
  if (p.currency != c.myCurrency || cert.currency != p.currency) return fail('bound_to_receiver', 'currency mismatch');
  pass('bound_to_receiver');
  if (c.nowSec > p.expiresAt) return fail('token_valid_time', 'token expired');
  if (p.createdAt > c.nowSec + c.maxClockSkew) return fail('token_valid_time', 'token from the future');
  if (p.createdAt > p.expiresAt || p.expiresAt > cert.expiresAt + c.maxClockSkew) return fail('token_valid_time', 'bad token window');
  pass('token_valid_time');
  if (p.amount <= 0 || p.amount > cert.perTxMax) return fail('within_per_tx_max', 'amount over payer limit');
  pass('within_per_tx_max');
  if (p.counter < 1 || p.cumulativeSpent < p.amount || p.cumulativeSpent > cert.spendCeiling) return fail('within_ceiling', 'payer ceiling exceeded');
  pass('within_ceiling');
  if (c.seenTxIds.contains(hexOf(p.txId)) || c.seenWalletCounters.contains('${p.walletId}:${p.counter}')) return fail('not_seen_before', 'already received');
  pass('not_seen_before');
  if (p.amount > c.myMaxAccept) return fail('within_receiver_limits', 'over your max single payment');
  if (c.pendingTotal + p.amount > c.pendingCap) return fail('within_receiver_limits', 'pending cap reached');
  pass('within_receiver_limits');
  return VerifyResult(true, checks, t);
}
