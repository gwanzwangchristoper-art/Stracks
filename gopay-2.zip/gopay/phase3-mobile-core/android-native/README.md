# Android native setup
1. Copy `KeystorePlugin.kt` into `android/app/src/main/kotlin/com/gopay/core/` and register it in `MainActivity.configureFlutterEngine`: `flutterEngine.plugins.add(KeystorePlugin())`. `MainActivity` must extend `FlutterFragmentActivity` (needed by BiometricPrompt).
2. `build.gradle`: `minSdk 26`, dependencies `androidx.biometric:biometric:1.1.0`, `com.google.android.play:integrity:1.3.0`.
3. **Backups off** (anti-rollback needs it, and tokens must never be restored): in `AndroidManifest.xml` set
   `android:allowBackup="false" android:fullBackupContent="false" android:dataExtractionRules="@xml/no_backup"` and use `res/xml/no_backup.xml`:
   `<data-extraction-rules><cloud-backup><exclude domain="root"/><exclude domain="file"/><exclude domain="database"/><exclude domain="sharedpref"/></cloud-backup><device-transfer><exclude domain="root"/><exclude domain="file"/><exclude domain="database"/><exclude domain="sharedpref"/></device-transfer></data-extraction-rules>`
4. `FLAG_SECURE` on sensitive screens (done in Dart via `ScreenGuard`, phase5).
5. Release builds: R8/ProGuard on, `isDebuggable=false`. Certificate pinning: add the server's SPKI pins to `network_security_config.xml`.
