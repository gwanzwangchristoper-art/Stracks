package com.gopay.core

import android.content.Context
import android.os.Build
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.security.keystore.StrongBoxUnavailableException
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricManager.Authenticators.BIOMETRIC_STRONG
import androidx.biometric.BiometricManager.Authenticators.DEVICE_CREDENTIAL
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import com.google.android.play.core.integrity.IntegrityManagerFactory
import com.google.android.play.core.integrity.IntegrityTokenRequest
import io.flutter.embedding.engine.plugins.FlutterPlugin
import io.flutter.embedding.engine.plugins.activity.ActivityAware
import io.flutter.embedding.engine.plugins.activity.ActivityPluginBinding
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel
import java.security.KeyPairGenerator
import java.security.KeyStore
import java.security.PrivateKey
import java.security.Signature
import java.security.spec.ECGenParameterSpec
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * Channel "gopay/keystore". Hardware-backed (StrongBox when present, else TEE) and non-exportable.
 *  - P-256 signing key: user authentication required for EVERY signature (BiometricPrompt + CryptoObject).
 *    If biometrics are not enrolled (or API < 30) the key is created without hardware auth and the app-level PIN is the gate.
 *  - AES-256-GCM sealing keys: no user auth (background sync must read), excluded from backups by the OS, never leave the device.
 * Set PLAY_PROJECT_NUMBER to your Google Cloud project number for Play Integrity.
 */
class KeystorePlugin : FlutterPlugin, ActivityAware, MethodChannel.MethodCallHandler {
    private lateinit var ctx: Context
    private var activity: FragmentActivity? = null
    private val ks: KeyStore = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }

    override fun onAttachedToEngine(b: FlutterPlugin.FlutterPluginBinding) {
        ctx = b.applicationContext
        MethodChannel(b.binaryMessenger, "gopay/keystore").setMethodCallHandler(this)
    }
    override fun onDetachedFromEngine(b: FlutterPlugin.FlutterPluginBinding) {}
    override fun onAttachedToActivity(b: ActivityPluginBinding) { activity = b.activity as? FragmentActivity }
    override fun onDetachedFromActivityForConfigChanges() { activity = null }
    override fun onReattachedToActivityForConfigChanges(b: ActivityPluginBinding) { activity = b.activity as? FragmentActivity }
    override fun onDetachedFromActivity() { activity = null }

    override fun onMethodCall(call: MethodCall, result: MethodChannel.Result) {
        try {
            val alias = call.argument<String>("alias") ?: ""
            when (call.method) {
                "ensureSigningKey" -> result.success(ensureSigningKey(alias))
                "sign" -> sign(alias, call.argument<ByteArray>("data")!!, call.argument<String>("prompt") ?: "Confirm", result)
                "createAesKey" -> { createAesKey(alias); result.success(null) }
                "deleteKey" -> { if (ks.containsAlias(alias)) ks.deleteEntry(alias); result.success(null) }
                "hasKey" -> result.success(ks.containsAlias(alias))
                "encrypt" -> result.success(encrypt(alias, call.argument("data")!!, call.argument("aad")!!))
                "decrypt" -> result.success(decrypt(alias, call.argument("data")!!, call.argument("aad")!!))
                "attest" -> attest(call.argument<String>("nonce")!!, result)
                else -> result.notImplemented()
            }
        } catch (e: java.security.GeneralSecurityException) {
            result.error(if (ks.containsAlias(call.argument<String>("alias") ?: "") ) "bad_tag" else "no_key", e.message, null)
        } catch (e: Exception) { result.error("native_error", e.message, null) }
    }

    private fun canHardwareAuth(): Boolean =
        Build.VERSION.SDK_INT >= 30 && BiometricManager.from(ctx).canAuthenticate(BIOMETRIC_STRONG or DEVICE_CREDENTIAL) == BiometricManager.BIOMETRIC_SUCCESS

    private fun ensureSigningKey(alias: String): ByteArray {
        if (!ks.containsAlias(alias)) {
            fun spec(strongBox: Boolean): KeyGenParameterSpec {
                val b = KeyGenParameterSpec.Builder(alias, KeyProperties.PURPOSE_SIGN)
                    .setAlgorithmParameterSpec(ECGenParameterSpec("secp256r1"))
                    .setDigests(KeyProperties.DIGEST_SHA256)
                if (canHardwareAuth() && Build.VERSION.SDK_INT >= 30) b.setUserAuthenticationRequired(true).setUserAuthenticationParameters(0, KeyProperties.AUTH_BIOMETRIC_STRONG or KeyProperties.AUTH_DEVICE_CREDENTIAL)
                if (strongBox && Build.VERSION.SDK_INT >= 28) b.setIsStrongBoxBacked(true)
                return b.build()
            }
            val gen = KeyPairGenerator.getInstance(KeyProperties.KEY_ALGORITHM_EC, "AndroidKeyStore")
            try { gen.initialize(spec(true)); gen.generateKeyPair() }
            catch (e: StrongBoxUnavailableException) { gen.initialize(spec(false)); gen.generateKeyPair() }
        }
        val pub = ks.getCertificate(alias).publicKey.encoded           // X.509 SPKI; last 65 bytes are the uncompressed point
        return pub.copyOfRange(pub.size - 65, pub.size)
    }

    private fun sign(alias: String, data: ByteArray, prompt: String, result: MethodChannel.Result) {
        val key = ks.getKey(alias, null) as PrivateKey
        val sig = Signature.getInstance("SHA256withECDSA").apply { initSign(key) }
        val needsAuth = canHardwareAuth() && (try { sig.update(byteArrayOf()); false } catch (e: Exception) { true }) || keyRequiresAuth(key)
        if (!needsAuth) { sig.update(data); result.success(sig.sign()); return }
        val act = activity ?: return result.error("no_activity", "No activity", null)
        val info = BiometricPrompt.PromptInfo.Builder().setTitle(prompt).setAllowedAuthenticators(BIOMETRIC_STRONG or DEVICE_CREDENTIAL).build()
        val bp = BiometricPrompt(act, ContextCompat.getMainExecutor(ctx), object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(r: BiometricPrompt.AuthenticationResult) {
                try { val s = r.cryptoObject!!.signature!!; s.update(data); result.success(s.sign()) } catch (e: Exception) { result.error("sign_failed", e.message, null) }
            }
            override fun onAuthenticationError(code: Int, msg: CharSequence) { result.error("auth_cancelled", msg.toString(), null) }
        })
        bp.authenticate(info, BiometricPrompt.CryptoObject(sig))
    }
    private fun keyRequiresAuth(key: PrivateKey): Boolean = try {
        val f = java.security.KeyFactory.getInstance(key.algorithm, "AndroidKeyStore").getKeySpec(key, android.security.keystore.KeyInfo::class.java)
        f.isUserAuthenticationRequired
    } catch (e: Exception) { false }

    private fun createAesKey(alias: String) {
        if (ks.containsAlias(alias)) return
        fun spec(sb: Boolean): KeyGenParameterSpec {
            val b = KeyGenParameterSpec.Builder(alias, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).setKeySize(256)
            if (sb && Build.VERSION.SDK_INT >= 28) b.setIsStrongBoxBacked(true)
            return b.build()
        }
        val g = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        try { g.init(spec(true)); g.generateKey() } catch (e: StrongBoxUnavailableException) { g.init(spec(false)); g.generateKey() }
    }
    private fun encrypt(alias: String, data: ByteArray, aad: ByteArray): ByteArray {
        val c = Cipher.getInstance("AES/GCM/NoPadding").apply { init(Cipher.ENCRYPT_MODE, ks.getKey(alias, null) as SecretKey); updateAAD(aad) }
        return c.iv + c.doFinal(data)                                   // 12-byte IV || ciphertext+tag
    }
    private fun decrypt(alias: String, blob: ByteArray, aad: ByteArray): ByteArray {
        val key = ks.getKey(alias, null) as? SecretKey ?: throw java.security.GeneralSecurityException("no key")
        val c = Cipher.getInstance("AES/GCM/NoPadding").apply { init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(128, blob, 0, 12)); updateAAD(aad) }
        return c.doFinal(blob, 12, blob.size - 12)
    }

    private fun attest(nonce: String, result: MethodChannel.Result) {
        IntegrityManagerFactory.create(ctx).requestIntegrityToken(
            IntegrityTokenRequest.builder().setNonce(android.util.Base64.encodeToString(nonce.toByteArray(), android.util.Base64.URL_SAFE or android.util.Base64.NO_WRAP or android.util.Base64.NO_PADDING))
                .setCloudProjectNumber(PLAY_PROJECT_NUMBER).build())
            .addOnSuccessListener { result.success(it.token()) }
            .addOnFailureListener { result.error("attestation_failed", it.message, null) }
    }
    companion object { const val PLAY_PROJECT_NUMBER = 0L /* TODO: set from Google Cloud console */ }
}
