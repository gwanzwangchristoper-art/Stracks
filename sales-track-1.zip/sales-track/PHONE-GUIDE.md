# Build the app from your phone (no computer)

1. On GitHub make a NEW repository (+ at the top, New repository, any name, Create).
2. Add file > Upload files > choose `sales-track.zip` (do NOT unzip it) > Commit changes.
3. Add file > Create new file. In the name box type exactly `.github/workflows/build.yml`
   (typing the slashes makes the folders). Paste the text of `.github/workflows/build.yml` from this project. Commit changes.
4. Open the Actions tab. "Build Android app" starts by itself and takes about 8-15 minutes. A green tick means it worked.
5. Go back to the main page of the repository, tap Releases on the right, open the newest one, tap `SalesTrack.apk`, then open the downloaded file to install.
   Android will ask you to allow installs from your browser: allow it for this one install.

To update the app later: upload a new `sales-track.zip` with the same name (it replaces the old one). A new build starts by itself.
If nothing starts: Settings > Actions > General > choose "Allow all actions", then Actions > Build Android app > Run workflow.
