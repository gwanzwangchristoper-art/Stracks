// Guards against the phone failure "no such table: sync_conflicts": migrations must survive the SQLite plugin.
import test from 'node:test';
import assert from 'node:assert/strict';
import { DatabaseSync } from 'node:sqlite';
import { splitStatements } from '../src/db/sqlsplit.js';
import { MIGRATIONS } from '../src/db/schema.js';
import { setAdapter, openDb, q } from '../src/db/db.js';

test('splitter: comments go, quotes and trigger bodies stay intact', () => {
  const s = splitStatements(`-- lead\nCREATE TABLE a(x TEXT); -- tail\n/* block; with semicolon */ INSERT INTO a VALUES('x;y -- not a comment');
    CREATE TRIGGER t BEFORE DELETE ON a BEGIN SELECT RAISE(ABORT,'no'); END;\nDROP TABLE a`);
  assert.deepEqual(s, ['CREATE TABLE a(x TEXT)', "INSERT INTO a VALUES('x;y -- not a comment')",
    "CREATE TRIGGER t BEFORE DELETE ON a BEGIN SELECT RAISE(ABORT,'no'); END", 'DROP TABLE a']);
});
test('no migration statement contains or starts with a comment', () => {
  for (const m of MIGRATIONS) for (const st of splitStatements(m.sql)) assert.doesNotMatch(st, /--|\/\*/, `migration ${m.version}: ${st.slice(0, 60)}`);
  for (const m of MIGRATIONS) assert.doesNotMatch(m.sql, /--/, `migration ${m.version} still has a -- comment`);
});
test('nothing is lost in splitting: every CREATE/ALTER/INSERT/UPDATE in the source survives', () => {
  for (const m of MIGRATIONS) {
    const raw = (m.sql.match(/\b(CREATE|ALTER|INSERT|UPDATE)\b/gi) || []).length - (m.sql.match(/CREATE TRIGGER[^]*?END;/gi) || []).length * 0;
    const kept = splitStatements(m.sql).filter(s => /^(CREATE|ALTER|INSERT|UPDATE)\b/i.test(s)).length;
    assert.ok(kept >= 1, `migration ${m.version}`);
    assert.equal(kept, (m.sql.match(/^\s*(CREATE|ALTER|INSERT|UPDATE)\b/gim) || []).length, `migration ${m.version}`);
  }
});

// A stand-in for the phone plugin: splits on ";" and skips any piece starting with "--".
function pluginLike(mem) {
  return { async open() {}, async exec(sql) { for (const piece of sql.split(';')) { const t = piece.trim(); if (t && !t.startsWith('--')) mem.exec(t); } },
    async query(s, p = []) { return mem.prepare(s).all(...p); }, async run(s, p = []) { mem.prepare(s).run(...p); }, async tx() {} };
}
const schemaOf = (mem) => mem.prepare("SELECT type,name FROM sqlite_master WHERE name NOT LIKE 'sqlite_%' ORDER BY type,name").all().map(r => `${r.type}:${r.name}`);
const columns = (mem, t) => mem.prepare(`PRAGMA table_info(${t})`).all().map(r => r.name);

test('a fresh install through a plugin-like adapter gets exactly the schema a plain SQLite gets', async () => {
  const ref = new DatabaseSync(':memory:');
  for (const m of MIGRATIONS) for (const st of splitStatements(m.sql)) { try { ref.exec(st); } catch (e) { if (!/duplicate column|already exists/.test(e.message)) throw e; } }
  const phone = new DatabaseSync(':memory:'); setAdapter(pluginLike(phone)); await openDb();
  assert.deepEqual(schemaOf(phone).filter(x => !x.includes('schema_version')), schemaOf(ref).filter(x => !x.includes('schema_version')));
  assert.ok(schemaOf(phone).includes('table:sync_conflicts')); assert.ok(columns(phone, 'products').includes('base_json'));
  assert.ok(schemaOf(phone).some(x => x.startsWith('trigger:')));
  assert.equal(phone.prepare('SELECT MAX(version) v FROM schema_version').get().v, 9);
});
test('a phone already broken by the bug repairs itself on update (migrations 6 and 7 recorded, pieces missing)', async () => {
  const mem = new DatabaseSync(':memory:'); mem.exec('CREATE TABLE schema_version(version INTEGER PRIMARY KEY)');
  for (const m of MIGRATIONS.filter(m => m.version <= 7)) {
    // reproduce the old migration 6, where the comment-led statements were skipped
    const lost = m.version === 6 ? (s) => /sync_conflicts\(|base_json/.test(s) : () => false;
    for (const st of splitStatements(m.sql)) if (!lost(st)) mem.exec(st);
    mem.prepare('INSERT INTO schema_version VALUES(?)').run(m.version);
  }
  assert.ok(!schemaOf(mem).includes('table:sync_conflicts'));                       // the state from the phone
  mem.prepare("INSERT INTO products(id,name,quantity,sell_price,created_at,updated_at) VALUES('p','Old',7,1,'t','t')").run(); // stock with no history
  setAdapter(pluginLike(mem)); await openDb();                                      // "Could not start" used to happen here
  assert.ok(schemaOf(mem).includes('table:sync_conflicts')); assert.ok(columns(mem, 'sync_conflicts').includes('applied'));
  assert.ok(columns(mem, 'products').includes('base_json')); assert.ok(columns(mem, 'products').includes('base_version'));
  assert.equal(mem.prepare('SELECT MAX(version) v FROM schema_version').get().v, 9);
  assert.equal(mem.prepare("SELECT SUM(delta) s FROM inventory_transactions WHERE product_id='p'").get().s, 7);   // missing stock history restored
  await openDb();                                                                   // opening again is harmless
  assert.equal(mem.prepare("SELECT COUNT(*) n FROM inventory_transactions WHERE product_id='p'").get().n, 1);
});
test('a real failure is not hidden: a broken statement stops start-up with a clear message', async () => {
  const mem = new DatabaseSync(':memory:'); setAdapter({ ...pluginLike(mem), async exec(s) { if (/CREATE TABLE IF NOT EXISTS categories/.test(s)) throw new Error('disk full'); mem.exec(s); } });
  await assert.rejects(() => openDb(), /Migration 2 failed: disk full/);
});
