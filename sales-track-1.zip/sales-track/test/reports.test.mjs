import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { DatabaseSync } from 'node:sqlite';
import { setAdapter, openDb, q, run } from '../src/db/db.js';
const mem = new DatabaseSync(':memory:');
setAdapter({ async open() {}, async exec(s) { mem.exec(s); }, async query(s, p = []) { return mem.prepare(s).all(...p); }, async run(s, p = []) { mem.prepare(s).run(...p); },
  async tx(st) { mem.exec('BEGIN'); try { for (const x of st) mem.prepare(x.statement).run(...x.values); mem.exec('COMMIT'); } catch (e) { mem.exec('ROLLBACK'); throw e; } } });
const auth = await import('../src/auth/auth.js');
const { addProduct } = await import('../src/domain/products.js');
const { saveTransaction } = await import('../src/domain/sales.js');
const { confirmSale, adjustStock, lowStockCount } = await import('../src/domain/inventory.js');
const { correctSale, voidSale } = await import('../src/domain/corrections.js');
const { dashboard } = await import('../src/domain/reports.js');
const { buildReport, availableReports } = await import('../src/reports/data.js');
const { exportReport, exportBuilt } = await import('../src/reports/export.js');
const { toCSV } = await import('../src/reports/format.js');
let cola, fanta, evil;
const line = (p, n, quantity, price) => ({ productId: p.id, name: n, quantity, price, cost: p.buy_price });
const sell = async (lines) => { const s = await saveTransaction(lines); await confirmSale(s.saleId); return s.saleId; };
const rowsOf = async (k, r = { key: 'today' }) => (await buildReport(k, r)).rows;

test('setup: sales, a correction, a void, an unconfirmed sale, low stock', async () => {
  await openDb(); await auth.createAdmin({ fullName: 'Chris', username: 'chris', password: 'password123', businessName: 'Ade Stores' });
  cola = await addProduct({ name: 'Coca Cola', sellPrice: '500', buyPrice: '400', quantity: '50', threshold: '5', sku: 'CC1', category: 'Drinks' });
  fanta = await addProduct({ name: 'Fanta', sellPrice: '400', quantity: '20', threshold: '5' });            // no buying price
  evil = await addProduct({ name: '=HYPERLINK("http://x.test")', sellPrice: '100', buyPrice: '50', quantity: '10' });
  const s1 = await sell([line(cola, 'Coca Cola', 5, 500), line(fanta, 'Fanta', 2, 400)]);
  await correctSale(s1, { lines: [line(cola, 'Coca Cola', 3, 500), line(fanta, 'Fanta', 2, 400)], reason: 'Wrong quantity' });
  const s2 = await sell([line(evil, evil.name, 4, 100)]); await voidSale(s2, 'Customer cancelled');
  await sell([line(cola, 'Coca Cola', 42, 500)]);                                                             // Coca Cola falls to 5 -> low stock
  await saveTransaction([line(fanta, 'Fanta', 1, 400)]);                                                      // never confirmed
  assert.equal(await lowStockCount(), 1);
});
test('sales report matches the dashboard exactly and ignores corrected, voided and unconfirmed sales', async () => {
  const rep = await buildReport('sales', { key: 'today' }), d = await dashboard('today');
  assert.equal(rep.totals.total, d.main.revenue); assert.equal(rep.totals.n, d.main.n);
  assert.equal(rep.rows.length, 1); assert.equal(rep.totals.total, 1500 + 800 + 21000);
});
test('profit report matches the dashboard profit and says how many lines had no cost', async () => {
  const rep = await buildReport('profit', { key: 'today' }), d = await dashboard('today');
  assert.equal(rep.totals.profit, d.profit.profit); assert.equal(rep.totals.missing, d.profit.missing);
  const fantaRow = rep.rows.find(r => r.name === 'Fanta'); assert.equal(fantaRow.profit, 0); assert.equal(fantaRow.margin, null); assert.equal(fantaRow.missing, 1);
  assert.ok(rep.notes.some(n => /no buying price/.test(n)));
});
test('transaction report lists every sale with its status, and links corrections to the original', async () => {
  const rows = await rowsOf('transactions'), by = (s) => rows.filter(r => r.status === s);
  assert.ok(by('corrected').length && by('voided').length && by('calculated').length && by('confirmed').length);
  const fix = by('confirmed').find(r => r.corrects); assert.ok(fix); assert.equal(fix.reason, 'Wrong quantity');
  assert.equal(by('corrected')[0].receipt, fix.corrects);
  const rep = await buildReport('transactions', { key: 'today' });
  assert.equal(rep.totals.subtotal, (await buildReport('sales', { key: 'today' })).totals.total);   // confirmed lines add up to the sales report
});
test('inventory and low-stock reports agree with the app', async () => {
  const inv = await buildReport('inventory'), d = await dashboard('today');
  assert.equal(inv.totals.costValue, d.inv.cost_value); assert.equal(inv.totals.sellValue, d.inv.sell_value); assert.equal(inv.rows.length, d.inv.products);
  const low = await buildReport('lowstock'); assert.equal(low.rows.length, await lowStockCount());
  assert.equal(low.rows[0].name, 'Coca Cola'); assert.equal(low.rows[0].status, 'Low stock');
  await adjustStock({ productId: cola.id, delta: -5, reason: 'Damaged' });
  const out = (await buildReport('lowstock')).rows[0]; assert.equal(out.status, 'Out of stock'); assert.equal(out.short, 5);
});
test('a formula in a product name cannot run when the CSV is opened in Excel', async () => {
  const csv = toCSV(await buildReport('inventory'));
  assert.ok(csv.startsWith('\uFEFF')); assert.ok(csv.includes(`"'=HYPERLINK(""http://x.test"")"`));
  assert.ok(!/\r\n=HYPERLINK/.test(csv));
});
test('exporting makes a real file in each format and writes an audit entry', async () => {
  for (const [f, sig] of [['csv', '\uFEFF'], ['xlsx', 'PK'], ['pdf', '%PDF-']]) {
    const r = await exportReport('sales', { key: 'today' }, f);
    assert.match(r.name, new RegExp(`^sales-track_sales-report_\\d{4}-\\d{2}-\\d{2}\\.${f}$`));
    const head = typeof r.data === 'string' ? r.data.slice(0, 1) : new TextDecoder('latin1').decode(r.data.slice(0, sig.length));
    assert.equal(head, typeof r.data === 'string' ? sig : sig);
  }
  const a = await q("SELECT * FROM audit_logs WHERE action='report_exported' ORDER BY created_at"); assert.equal(a.length, 3);
  assert.equal(JSON.parse(a[0].new_value).report, 'Sales report');
  fs.mkdirSync('/tmp/out', { recursive: true });
  for (const k of ['sales', 'transactions', 'inventory', 'lowstock', 'profit', 'audit']) for (const f of ['csv', 'xlsx', 'pdf']) {
    const r = await exportReport(k, { key: 'today' }, f); fs.writeFileSync(`/tmp/out/${k}.${f}`, r.data);
  }
});
test('an empty period still gives a valid, clearly empty report', async () => {
  const rep = await buildReport('sales', { key: 'custom', from: '2001-01-01', to: '2001-01-31' });
  assert.equal(rep.rows.length, 0); assert.equal(rep.totals.total, 0);
  assert.match((await exportBuilt(rep, 'csv')).data, /^\uFEFFDate,Transactions,Items sold/);
  for (const f of ['xlsx', 'pdf']) assert.ok((await exportBuilt(rep, f)).data.length > 100);
});
test('permissions: the audit report is owner-only, and each report needs its own rights', async () => {
  const biz = (await q('SELECT id FROM businesses'))[0].id;
  await auth.addLinkedUser({ businessId: biz, businessName: 'x', memberId: crypto.randomUUID(), fullName: 'Bob', username: 'bob', password: 'password123' });
  assert.deepEqual(await availableReports(auth.currentUser()), ['sales', 'transactions', 'inventory', 'lowstock', 'profit']);   // everything except audit
  await assert.rejects(() => buildReport('audit'), /Admin permission required/);
  await run("UPDATE users SET permissions=? WHERE username='bob'", [JSON.stringify({ view_analysis: false })]); await auth.login('bob', 'password123');
  assert.deepEqual(await availableReports(auth.currentUser()), ['transactions', 'inventory', 'lowstock']);
  await assert.rejects(() => buildReport('profit'), /Admin permission required/);
  const admin = await (async () => { await auth.login('chris', 'password123'); return buildReport('profit', { key: 'today' }); })();
  await auth.login('bob', 'password123');
  await assert.rejects(() => exportBuilt(admin, 'csv'), /Admin permission required/);                                             // a report built by someone else cannot be exported
  await run("UPDATE users SET permissions=? WHERE username='bob'", [JSON.stringify({ export: false })]); await auth.login('bob', 'password123');
  assert.deepEqual(await availableReports(auth.currentUser()), []);
  await assert.rejects(() => exportReport('inventory', {}, 'csv'), /Admin permission required/);
});
test('the audit report shows who took data out, and cannot be run by anyone but the owner', async () => {
  await auth.login('chris', 'password123');
  const rows = await rowsOf('audit'); assert.ok(rows.some(r => r.action === 'report exported' && r.who === 'Chris'));
  assert.ok(rows.some(r => r.action === 'sale corrected' && r.reason === 'Wrong quantity'));
});
