// Splits a migration into single statements with all comments removed.
// Why: the phone's SQLite plugin splits multi-statement text on ";" itself and silently skips any piece that starts
// with a "--" comment. A comment before a CREATE TABLE therefore made the whole table vanish (seen on a real phone).
// Running one clean statement at a time avoids the plugin's splitting entirely. Triggers keep their inner ";".
export function splitStatements(sql) {
  const out = [], n = sql.length;
  let cur = '', i = 0, quote = null;
  while (i < n) {
    const c = sql[i], d = sql[i + 1];
    if (quote) { cur += c; if (c === quote) { if (d === quote) { cur += d; i += 2; continue; } quote = null; } i++; continue; }
    if (c === "'" || c === '"') { quote = c; cur += c; i++; continue; }
    if (c === '-' && d === '-') { while (i < n && sql[i] !== '\n') i++; continue; }                                   // -- comment
    if (c === '/' && d === '*') { i += 2; while (i < n && !(sql[i] === '*' && sql[i + 1] === '/')) i++; i += 2; cur += ' '; continue; } // /* comment */
    if (c === ';') {
      const s = cur.trim();
      if (/^create\s+(temp(orary)?\s+)?trigger\b/i.test(s) && !/\bend$/i.test(s)) { cur += c; i++; continue; }          // still inside BEGIN ... END
      if (s) out.push(s);
      cur = ''; i++; continue;
    }
    cur += c; i++;
  }
  if (cur.trim()) out.push(cur.trim());
  return out;
}
