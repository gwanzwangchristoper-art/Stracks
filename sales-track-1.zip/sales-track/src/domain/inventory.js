// INVENTORY RULE: stock is never overwritten. Every change is an append-only ledger row
// (inventory_transactions) and products.quantity is the cached running sum. Two devices
// selling offline produce two separate rows (-10, -7) that merge to -17 on sync.
import { q, uuid, now, tx, getSetting, setSetting, audit } from '../db/db.js';
import { currentUser } from '../auth/auth.js';
import { require_ } from '../auth/permissions.js';
import { detId } from '../sync/ids.js';

const SYNC = `'SYNC_PENDING'`;
export function ledgerStmts({ id, productId, delta, reason, refId = null, note = null, userId, dev, t }) {
  return [
    { statement: `INSERT INTO inventory_transactions(id,product_id,delta,reason,ref_id,note,user_id,device_id,sync_status,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,${SYNC},?,?)`,
      values: [id ?? uuid(), productId, delta, reason, refId, note, userId, dev, t, t] },
    { statement: 'UPDATE products SET quantity=quantity+? WHERE id=?', values: [delta, productId] }, // cached sum only: not synced, other devices recompute it from the ledger
  ];
}
export const auditStmt = (userId, action, oldV, newV, reason, dev, t) => ({
  statement: `INSERT INTO audit_logs(id,user_id,action,old_value,new_value,reason,device_id,sync_status,created_at,updated_at) VALUES(?,?,?,?,?,?,?,${SYNC},?,?)`,
  values: [uuid(), userId, action, JSON.stringify(oldV ?? null), JSON.stringify(newV ?? null), reason, dev, t, t] });

const allowNegative = async () => (await getSetting('negative_stock')) === 'true';
const short = (p, want) => p.quantity > 0 ? `Only ${p.quantity} units of ${p.name} available.` : `${p.name} is out of stock.`;

// Turns a 'calculated' transaction into a confirmed sale and deducts stock, all-or-nothing.
export async function confirmSale(saleId) {
  const u = currentUser(); require_(u, 'sell');
  const sale = (await q('SELECT * FROM sales WHERE id=?', [saleId]))[0];
  if (!sale) throw new Error('Sale not found.');
  if (sale.status !== 'calculated') throw new Error(`This sale is already ${sale.status}.`);
  const items = await q('SELECT * FROM sale_items WHERE sale_id=?', [saleId]);
  const need = {};
  items.forEach(i => (need[i.product_id] = (need[i.product_id] || 0) + i.quantity)); // same product may be on several lines
  const neg = await allowNegative();
  for (const [pid, qty] of Object.entries(need)) {
    const p = (await q('SELECT name,quantity FROM products WHERE id=?', [pid]))[0];
    if (!p) throw new Error('A product in this sale no longer exists.');
    if (!neg && p.quantity < qty) throw new Error(short(p, qty));
  }
  const dev = await getSetting('device_id'), t = now();
  await tx([
    // Deterministic id: if two devices confirm the same sale, their stock rows collapse into ONE (no double deduction).
    ...(await Promise.all(Object.entries(need).map(async ([pid, qty]) => ledgerStmts({ id: await detId(`sale:${saleId}:${pid}`), productId: pid, delta: -qty, reason: 'sale', refId: saleId, userId: u.id, dev, t })))).flat(),
    { statement: `UPDATE sales SET status='confirmed', sync_status=${SYNC}, updated_at=? WHERE id=?`, values: [t, saleId] },
    auditStmt(u.id, 'sale_confirmed', { status: 'calculated' }, { status: 'confirmed', sale: saleId, receipt: sale.receipt_no, total: sale.total }, null, dev, t),
  ]);
  return lowStockCheck(Object.keys(need));
}

export async function adjustStock({ productId, delta, reason, note }) {
  const u = currentUser(); require_(u, 'adjust_stock');
  delta = Number(delta);
  if (!delta || isNaN(delta)) throw new Error('Enter a quantity.');
  if (!reason) throw new Error('Choose a reason.');
  const p = (await q('SELECT name,quantity FROM products WHERE id=?', [productId]))[0];
  if (delta < 0 && !(await allowNegative()) && p.quantity + delta < 0) throw new Error(short(p));
  const dev = await getSetting('device_id'), t = now();
  await tx([...ledgerStmts({ productId, delta, reason, note, userId: u.id, dev, t }),
    auditStmt(u.id, 'stock_adjusted', { quantity: p.quantity }, { quantity: p.quantity + delta, delta }, `${reason}${note ? ': ' + note : ''}`, dev, t)]);
  return lowStockCheck([productId]);
}

// Creates one unread notification per product that has dropped to its threshold.
export async function lowStockCheck(ids) {
  const low = [];
  for (const id of ids) {
    const p = (await q('SELECT id,name,quantity,low_stock_threshold th FROM products WHERE id=?', [id]))[0];
    if (!p || !(p.th > 0) || p.quantity > p.th) continue;
    low.push(`${p.name} (${p.quantity} left)`);
    if (!(await q("SELECT 1 FROM notifications WHERE type='low_stock' AND ref_id=? AND is_read=0", [id])).length) {
      const t = now();
      await tx([{ statement: `INSERT INTO notifications(id,type,title,body,ref_id,device_id,sync_status,created_at,updated_at) VALUES(?,?,?,?,?,?,${SYNC},?,?)`,
        values: [uuid(), 'low_stock', 'Low stock', `${p.name}: ${p.quantity} left`, id, await getSetting('device_id'), t, t] }]);
    }
  }
  return low;
}

export async function updateProduct(id, f) {
  const u = currentUser(); require_(u, 'edit_products');
  const old = (await q('SELECT * FROM products WHERE id=?', [id]))[0];
  const name = (f.name || '').trim();
  if (!name) throw new Error('Enter a product name.');
  if (f.sellPrice === '' || !(Number(f.sellPrice) >= 0)) throw new Error('Enter a selling price.');
  if (f.sku && (await q('SELECT 1 FROM products WHERE sku=? AND id<>?', [f.sku.trim(), id])).length) throw new Error('That SKU is already used.');
  const next = { name, sku: f.sku?.trim() || null, barcode: f.barcode?.trim() || null, sell_price: Number(f.sellPrice),
    buy_price: f.buyPrice === '' ? null : Number(f.buyPrice), low_stock_threshold: Number(f.threshold || 0), supplier: f.supplier || null, description: f.description || null };
  const before = Object.fromEntries(Object.keys(next).map(k => [k, old[k]]));
  const dev = await getSetting('device_id'), t = now();
  // Past sales keep the price they were sold at (sale_items snapshot), so edits never rewrite history.
  await tx([{ statement: `UPDATE products SET name=?,sku=?,barcode=?,sell_price=?,buy_price=?,low_stock_threshold=?,supplier=?,description=?,sync_status=CASE WHEN sync_status='CONFLICT' THEN 'CONFLICT' ELSE 'SYNC_PENDING' END,updated_at=? WHERE id=?`,
    values: [...Object.values(next), t, id] }, auditStmt(u.id, 'product_edited', before, next, null, dev, t)]);
  return lowStockCheck([id]);
}

export async function listProducts({ text = '', lowOnly = false, offset = 0, limit = 30 }) {
  const like = `%${text.trim().toLowerCase()}%`;
  return q(`SELECT p.*, c.name category FROM products p LEFT JOIN categories c ON c.id=p.category_id
    WHERE p.active=1 AND (lower(p.name) LIKE ? OR lower(IFNULL(p.sku,'')) LIKE ? OR IFNULL(p.barcode,'')=? OR lower(IFNULL(c.name,'')) LIKE ?)
    ${lowOnly ? 'AND p.low_stock_threshold>0 AND p.quantity<=p.low_stock_threshold' : ''} ORDER BY p.name COLLATE NOCASE LIMIT ? OFFSET ?`,
    [like, like, text.trim(), like, limit, offset]);
}
export const lowStockCount = async () => (await q('SELECT COUNT(*) n FROM products WHERE active=1 AND low_stock_threshold>0 AND quantity<=low_stock_threshold'))[0].n;
export const getProduct = async (id) => (await q('SELECT p.*, c.name category FROM products p LEFT JOIN categories c ON c.id=p.category_id WHERE p.id=?', [id]))[0];
export const productLedger = (id) => q('SELECT * FROM inventory_transactions WHERE product_id=? ORDER BY created_at DESC LIMIT 15', [id]);

export async function setNegativeStock(on) {
  const u = currentUser(); require_(u, 'change_settings');
  const old = await allowNegative();
  await setSetting('negative_stock', on);
  await audit(u.id, 'setting_changed', { negative_stock: old }, { negative_stock: on });
}
export const negativeStockOn = allowNegative;
