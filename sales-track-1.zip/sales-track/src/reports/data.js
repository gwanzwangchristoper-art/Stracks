// The six business reports. Each returns the same shape so CSV, Excel and PDF can all print it:
//   { key, title, period, columns:[{key,label,kind}], rows:[{...}], totals:{...}|null, notes:[], meta }
// kinds: text | int | num | money | pct.   Only CONFIRMED sales count towards money figures;
// the transaction report lists every sale with its status so corrections stay visible.
import { q } from '../db/db.js';
import { currentUser } from '../auth/auth.js';
import { can } from '../auth/permissions.js';
import { rangeFor } from '../domain/reports.js';

const r2 = (n) => Math.round((Number(n) || 0) * 100) / 100;
const r1 = (n) => Math.round((Number(n) || 0) * 10) / 10;
const pad = (n) => String(n).padStart(2, '0');
export const localDate = (iso) => { const d = new Date(iso); return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`; };
export const localTime = (iso) => { const d = new Date(iso); return `${pad(d.getHours())}:${pad(d.getMinutes())}`; };

// What each report needs. 'admin' means the owner only.
const RULES = { sales: ['export', 'view_analysis'], transactions: ['export', 'view_history'], inventory: ['export'], lowstock: ['export'], profit: ['export', 'view_analysis'], audit: ['admin'] };
export const REPORT_TITLES = { sales: 'Sales report', transactions: 'Transaction report', inventory: 'Inventory report', lowstock: 'Low-stock report', profit: 'Profit report', audit: 'Audit report' };
export const RANGED = { sales: true, transactions: true, profit: true, audit: true, inventory: false, lowstock: false };
export const allowed = (u, k) => !!u && RULES[k].every(p => (p === 'admin' ? u.role === 'admin' : can(u, p)));
export const availableReports = (u = currentUser()) => Object.keys(RULES).filter(k => allowed(u, k));

const days = { day: "strftime('%Y-%m-%d', datetime(%c,'localtime'))" };
const dayExpr = (col) => days.day.replace('%c', col);
const periodText = (r) => { const a = localDate(r.start), b = localDate(new Date(new Date(r.end).getTime() - 1).toISOString()); return a === b ? a : `${a} to ${b}`; };
const sum = (rows, k) => rows.reduce((a, r) => a + (Number(r[k]) || 0), 0);

const BUILD = {
  async sales(r) {
    const byDay = await q(`SELECT ${dayExpr('created_at')} day, COUNT(*) n, IFNULL(SUM(total),0) total FROM sales WHERE status='confirmed' AND created_at>=? AND created_at<? GROUP BY day ORDER BY day`, [r.start, r.end]);
    const qty = Object.fromEntries((await q(`SELECT ${dayExpr('s.created_at')} day, SUM(si.quantity) qty FROM sale_items si JOIN sales s ON s.id=si.sale_id WHERE s.status='confirmed' AND s.created_at>=? AND s.created_at<? GROUP BY day`, [r.start, r.end])).map(x => [x.day, x.qty]));
    const rows = byDay.map(d => ({ day: d.day, n: d.n, qty: qty[d.day] || 0, total: r2(d.total), avg: r2(d.total / d.n) }));
    const t = { n: sum(rows, 'n'), qty: sum(rows, 'qty'), total: r2(sum(rows, 'total')) };
    return { columns: [{ key: 'day', label: 'Date', kind: 'text' }, { key: 'n', label: 'Transactions', kind: 'int' }, { key: 'qty', label: 'Items sold', kind: 'num' },
      { key: 'total', label: 'Sales total (NGN)', kind: 'money' }, { key: 'avg', label: 'Average sale (NGN)', kind: 'money' }],
      rows, totals: { day: 'Total', ...t, avg: t.n ? r2(t.total / t.n) : 0 }, notes: ['Confirmed sales only. Corrected and voided sales are left out; their corrections are included.'] };
  },
  async transactions(r) {
    const rows = (await q(`SELECT s.created_at, s.receipt_no, s.status, s.total sale_total, s.correction_reason reason, c.receipt_no corrects, u.full_name who,
        si.product_name, si.quantity, si.unit_price, si.subtotal FROM sales s JOIN sale_items si ON si.sale_id=s.id
        LEFT JOIN users u ON u.id=s.user_id LEFT JOIN sales c ON c.id=s.corrects_sale_id WHERE s.created_at>=? AND s.created_at<? ORDER BY s.created_at, s.receipt_no, si.rowid`, [r.start, r.end]))
      .map(x => ({ date: localDate(x.created_at), time: localTime(x.created_at), receipt: x.receipt_no, status: x.status, who: x.who || '', product: x.product_name, qty: x.quantity,
        price: r2(x.unit_price), subtotal: r2(x.subtotal), corrects: x.corrects || '', reason: x.reason || '' }));
    const counted = rows.filter(x => x.status === 'confirmed');
    return { columns: [{ key: 'date', label: 'Date', kind: 'text' }, { key: 'time', label: 'Time', kind: 'text' }, { key: 'receipt', label: 'Receipt', kind: 'text' }, { key: 'status', label: 'Status', kind: 'text' },
      { key: 'who', label: 'Recorded by', kind: 'text' }, { key: 'product', label: 'Product', kind: 'text' }, { key: 'qty', label: 'Quantity', kind: 'num' }, { key: 'price', label: 'Unit price (NGN)', kind: 'money' },
      { key: 'subtotal', label: 'Subtotal (NGN)', kind: 'money' }, { key: 'corrects', label: 'Corrects', kind: 'text' }, { key: 'reason', label: 'Reason', kind: 'text' }],
      rows, totals: { date: 'Confirmed sales total', subtotal: r2(sum(counted, 'subtotal')) }, notes: ['Every sale is listed with its status. The total counts confirmed lines only.'] };
  },
  async inventory() {
    const rows = (await q(`SELECT p.*, c.name category FROM products p LEFT JOIN categories c ON c.id=p.category_id WHERE p.active=1 ORDER BY p.name COLLATE NOCASE`)).map(p => ({
      name: p.name, sku: p.sku || '', barcode: p.barcode || '', category: p.category || '', supplier: p.supplier || '', stock: p.quantity, buy: p.buy_price == null ? null : r2(p.buy_price), sell: r2(p.sell_price),
      costValue: p.buy_price == null ? null : r2(p.quantity * p.buy_price), sellValue: r2(p.quantity * p.sell_price), threshold: p.low_stock_threshold || 0,
      status: p.quantity <= 0 ? 'Out of stock' : p.low_stock_threshold > 0 && p.quantity <= p.low_stock_threshold ? 'Low stock' : 'OK' }));
    return { columns: [{ key: 'name', label: 'Product', kind: 'text' }, { key: 'sku', label: 'SKU', kind: 'text' }, { key: 'barcode', label: 'Barcode', kind: 'text' }, { key: 'category', label: 'Category', kind: 'text' },
      { key: 'supplier', label: 'Supplier', kind: 'text' }, { key: 'stock', label: 'Stock', kind: 'num' }, { key: 'buy', label: 'Buying price (NGN)', kind: 'money' }, { key: 'sell', label: 'Selling price (NGN)', kind: 'money' },
      { key: 'costValue', label: 'Stock value at cost (NGN)', kind: 'money' }, { key: 'sellValue', label: 'Stock value at selling price (NGN)', kind: 'money' }, { key: 'threshold', label: 'Low-stock alert at', kind: 'num' }, { key: 'status', label: 'Status', kind: 'text' }],
      rows, totals: { name: 'Total', stock: sum(rows, 'stock'), costValue: r2(sum(rows, 'costValue')), sellValue: r2(sum(rows, 'sellValue')) },
      notes: ['Stock value at cost leaves out products with no buying price.'], asOf: true };
  },
  async lowstock() {
    const rows = (await q(`SELECT p.*, c.name category FROM products p LEFT JOIN categories c ON c.id=p.category_id
      WHERE p.active=1 AND p.low_stock_threshold>0 AND p.quantity<=p.low_stock_threshold ORDER BY (p.quantity - p.low_stock_threshold), p.name COLLATE NOCASE`)).map(p => ({
      name: p.name, sku: p.sku || '', category: p.category || '', supplier: p.supplier || '', stock: p.quantity, threshold: p.low_stock_threshold, short: Math.max(0, p.low_stock_threshold - p.quantity),
      buy: p.buy_price == null ? null : r2(p.buy_price), status: p.quantity <= 0 ? 'Out of stock' : 'Low stock' }));
    return { columns: [{ key: 'name', label: 'Product', kind: 'text' }, { key: 'sku', label: 'SKU', kind: 'text' }, { key: 'category', label: 'Category', kind: 'text' }, { key: 'supplier', label: 'Supplier', kind: 'text' },
      { key: 'stock', label: 'Stock', kind: 'num' }, { key: 'threshold', label: 'Alert at', kind: 'num' }, { key: 'short', label: 'Below alert by', kind: 'num' }, { key: 'buy', label: 'Buying price (NGN)', kind: 'money' }, { key: 'status', label: 'Status', kind: 'text' }],
      rows, totals: { name: `${rows.length} product${rows.length === 1 ? '' : 's'}` }, notes: ['Most urgent first.'], asOf: true };
  },
  async profit(r) {
    // cost = the buying price saved on the sale line, or the product's current buying price for older sales
    const lines = await q(`SELECT si.product_id pid, si.product_name name, si.quantity qty, si.subtotal rev, COALESCE(si.unit_cost, p.buy_price) cost
      FROM sale_items si JOIN sales s ON s.id=si.sale_id LEFT JOIN products p ON p.id=si.product_id WHERE s.status='confirmed' AND s.created_at>=? AND s.created_at<?`, [r.start, r.end]);
    const m = new Map();
    for (const l of lines) {
      const k = l.pid || l.name, x = m.get(k) || { name: l.name, qty: 0, revenue: 0, knownRev: 0, cost: 0, missing: 0 };
      x.qty += l.qty; x.revenue += l.rev;
      if (l.cost == null) x.missing += 1; else { x.knownRev += l.rev; x.cost += l.qty * l.cost; }
      m.set(k, x);
    }
    const rows = [...m.values()].map(x => ({ name: x.name, qty: x.qty, revenue: r2(x.revenue), cost: r2(x.cost), profit: r2(x.knownRev - x.cost), margin: x.knownRev ? r1(((x.knownRev - x.cost) / x.knownRev) * 100) : null, missing: x.missing }))
      .sort((a, b) => b.profit - a.profit);
    const known = [...m.values()].reduce((a, x) => a + x.knownRev, 0), cost = sum(rows, 'cost'), missing = sum(rows, 'missing');
    return { columns: [{ key: 'name', label: 'Product', kind: 'text' }, { key: 'qty', label: 'Quantity sold', kind: 'num' }, { key: 'revenue', label: 'Sales (NGN)', kind: 'money' }, { key: 'cost', label: 'Cost (NGN)', kind: 'money' },
      { key: 'profit', label: 'Gross profit (NGN)', kind: 'money' }, { key: 'margin', label: 'Margin (%)', kind: 'pct' }, { key: 'missing', label: 'Lines with no buying price', kind: 'int' }],
      rows, totals: { name: 'Total', qty: sum(rows, 'qty'), revenue: r2(sum(rows, 'revenue')), cost: r2(cost), profit: r2(known - cost), margin: known ? r1(((known - cost) / known) * 100) : null, missing },
      notes: ['Gross profit = sales minus buying cost, for sold lines that have a buying price.', missing ? `${missing} sold line${missing === 1 ? '' : 's'} had no buying price and ${missing === 1 ? 'is' : 'are'} left out of profit.` : 'Every sold line had a buying price.'] };
  },
  async audit(r) {
    const plain = (v) => { if (!v || v === 'null') return ''; try { const o = JSON.parse(v); return typeof o === 'object' && o ? Object.entries(o).map(([k, x]) => `${k}: ${Array.isArray(x) ? x.join(', ') : x}`).join('; ') : String(o); } catch { return v; } };
    const rows = (await q(`SELECT a.*, u.full_name who, d.name device FROM audit_logs a LEFT JOIN users u ON u.id=a.user_id LEFT JOIN devices d ON d.id=a.device_id WHERE a.created_at>=? AND a.created_at<? ORDER BY a.created_at`, [r.start, r.end]))
      .map(a => ({ date: localDate(a.created_at), time: localTime(a.created_at), who: a.who || '', device: a.device || '', action: a.action.replace(/_/g, ' '), reason: a.reason || '', before: plain(a.old_value), after: plain(a.new_value) }));
    return { columns: [{ key: 'date', label: 'Date', kind: 'text' }, { key: 'time', label: 'Time', kind: 'text' }, { key: 'who', label: 'User', kind: 'text' }, { key: 'device', label: 'Device', kind: 'text' },
      { key: 'action', label: 'Action', kind: 'text' }, { key: 'reason', label: 'Reason', kind: 'text' }, { key: 'before', label: 'Before', kind: 'text' }, { key: 'after', label: 'After', kind: 'text' }],
      rows, totals: null, notes: [`${rows.length} record${rows.length === 1 ? '' : 's'}. Audit records cannot be edited or deleted.`] };
  },
};

// range = { key:'today'|'yesterday'|'week'|'month'|'custom', from, to }
export async function buildReport(key, range = { key: 'month' }) {
  const u = currentUser();
  if (!BUILD[key]) throw new Error('Unknown report.');
  if (!allowed(u, key)) throw new Error('Admin permission required.');
  const r = RANGED[key] ? rangeFor(range.key || 'month', range.from, range.to) : { start: '0000', end: '9999' };
  const rep = await BUILD[key](r);
  const biz = (await q('SELECT name FROM businesses LIMIT 1'))[0];
  const gen = new Date().toISOString();
  return { key, title: REPORT_TITLES[key], period: RANGED[key] ? periodText(r) : `As at ${localDate(gen)}`, ...rep,
    meta: { business: biz?.name || '', generatedBy: u.full_name, generatedAt: gen } };
}
