import { availableReports, buildReport, REPORT_TITLES, RANGED } from '../reports/data.js';
import { exportBuilt, FORMATS } from '../reports/export.js';
import { shareFile } from '../reports/share.js';
import { currentUser } from '../auth/auth.js';
import { money } from '../domain/calculator.js';
const $ = (id) => document.getElementById(id);
const esc = (s) => String(s ?? '').replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const RANGES = [['today', 'Today'], ['yesterday', 'Yesterday'], ['week', 'This week'], ['month', 'This month'], ['custom', 'Custom']];
let st = { key: '', range: 'month', from: '', to: '' }, rep = null;

export async function renderExports(host, back) {
  const avail = availableReports(currentUser());
  if (!avail.includes(st.key)) st.key = avail[0];
  host.innerHTML = `<h2>Reports and export</h2><label>Report</label>
  <select id="x_r">${avail.map(k => `<option value="${k}" ${k === st.key ? 'selected' : ''}>${REPORT_TITLES[k]}</option>`).join('')}</select>
  <div id="x_range" ${RANGED[st.key] ? '' : 'hidden'}><div class="chips">${RANGES.map(([k, l]) => `<button data-k="${k}" class="${st.range === k ? 'on' : ''}">${l}</button>`).join('')}</div>
  ${st.range === 'custom' ? `<div class="two"><input id="x_f" type="date" value="${st.from}"><input id="x_t" type="date" value="${st.to}"></div>` : ''}</div>
  <div id="x_prev"><p class="sub">Loading…</p></div><div class="err" id="x_err"></div>
  <div class="three">${Object.entries(FORMATS).map(([k, f]) => `<button class="btn" data-f="${k}" disabled>${f.label}</button>`).join('')}</div>
  <p class="sub">Saved through your phone's share menu: choose Google Drive, Files, WhatsApp or email.</p><button class="btn alt" id="bk">Back</button>`;
  $('bk').onclick = back;
  $('x_r').onchange = (e) => { st.key = e.target.value; renderExports(host, back); };
  host.querySelectorAll('#x_range .chips button').forEach(b => (b.onclick = () => { st.range = b.dataset.k; renderExports(host, back); }));
  $('x_f')?.addEventListener('change', (e) => { st.from = e.target.value; preview(); }); $('x_t')?.addEventListener('change', (e) => { st.to = e.target.value; preview(); });
  host.querySelectorAll('[data-f]').forEach(b => (b.onclick = async () => {
    b.disabled = true; $('x_err').textContent = '';
    try { const f = await exportBuilt(rep, b.dataset.f); const r = await shareFile(f.name, f.data, f.mime); $('x_err').textContent = ''; $('x_prev').insertAdjacentHTML('afterbegin', `<p class="ok">${r === 'cancelled' ? 'Cancelled.' : `${esc(f.name)} is ready (${f.rows} rows).`}</p>`); }
    catch (e) { $('x_err').textContent = e.message; } finally { b.disabled = false; }
  }));
  preview();
}

async function preview() {
  rep = null; host_buttons(true);
  try {
    rep = await buildReport(st.key, { key: st.range, from: st.from, to: st.to });
    const cols = rep.columns.slice(0, 4), show = (r, c) => (r[c.key] == null ? '' : c.kind === 'money' ? money(r[c.key]) : r[c.key]);
    $('x_prev').innerHTML = `<div class="row"><b>${esc(rep.title)}</b><br><small>${esc(rep.period)} · ${rep.rows.length} row${rep.rows.length === 1 ? '' : 's'}</small>
      ${rep.rows.slice(0, 5).map(r => `<div class="ln">${cols.map(c => `<span>${esc(show(r, c))}</span>`).join('')}</div>`).join('') || '<p class="sub">Nothing in this period.</p>'}
      ${rep.totals ? `<div class="ln"><b>${esc(rep.totals[rep.columns[0].key] ?? 'Total')}</b><b>${rep.totals.total != null ? money(rep.totals.total) : rep.totals.profit != null ? money(rep.totals.profit) : ''}</b></div>` : ''}
      ${rep.rows.length > 5 ? `<small>Showing 5 of ${rep.rows.length}. The file has them all.</small>` : ''}</div>`;
    host_buttons(false);
  } catch (e) { $('x_prev').innerHTML = `<div class="err">${esc(e.message)}</div>`; }
}
const host_buttons = (off) => document.querySelectorAll('[data-f]').forEach(b => (b.disabled = off));
