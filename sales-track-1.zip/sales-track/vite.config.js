// Relative paths, so the built app loads from the phone's local web view.
export default { base: './', build: { target: 'es2020', chunkSizeWarningLimit: 1200 } };
